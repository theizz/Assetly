/* ASSETLY front-end — talks to the Express API in server.js */
const $ = (s, e = document) => e.querySelector(s), app = $('#app'), modal = $('#modal');
const CATS = ['Computer', 'Furniture', 'Laboratory Equipment', 'Electrical', 'Audio/Visual', 'Sports', 'Other'];
const STAT = ['Good', 'Needs Repair', 'Under Repair', 'Damaged'];
const DEF_ST = ['Open', 'In Progress', 'Resolved'], UPD_ST = ['Open', 'Recorded'];
const pc = s => s.split(' ')[0].replace('In', 'Progress');
const pill = s => `<span class="pill ${pc(s)}">${s}</span>`;
const TK = { get: () => localStorage.getItem('as_token'), set: v => v ? localStorage.setItem('as_token', v) : localStorage.removeItem('as_token') };
async function api(path, method = 'GET', body) {
  const h = {}; if (TK.get()) h.Authorization = 'Bearer ' + TK.get(); let b = body;
  if (body && !(body instanceof FormData)) { h['Content-Type'] = 'application/json'; b = JSON.stringify(body) }
  const r = await fetch('/api' + path, { method, headers: h, body: b }), j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || 'Request failed'); return j
}
let S = { user: null, page: 'dashboard', view: 'login', err: '', q: '' }, C = { assets: [], tickets: [], log: [] };
const assets = () => C.assets, tickets = () => C.tickets;
async function refresh() { C = await api('/data') }
function toast(m) { const t = $('#toast'); t.textContent = m; t.style.display = 'block'; setTimeout(() => t.style.display = 'none', 2800) }
const isAdmin = () => S.user.role.includes('Admin');

/* ---------- AUTH ---------- */
function authView() {
  const v = S.view, F = {
    login: `<h2>Welcome back</h2><p class="sub">Log in to manage or report campus assets.</p>
  <label>Email<input name="email" type="email" required></label><label>Password<input name="pass" type="password" required></label>
  <button class="btn" style="width:100%">Log in</button><p class="sub" style="margin-top:14px"><button type="button" class="link" data-v="forgot">Forgot password?</button> · <button type="button" class="link" data-v="signup">Teacher sign up</button></p>`,
    signup: `<h2>Create teacher account</h2><p class="sub">Report asset updates and defects for your rooms.</p>
  <label>Full name<input name="name" required></label><label>Email<input name="email" type="email" required></label><label>Password (min 6)<input name="pass" type="password" minlength="6" required></label>
  <button class="btn" style="width:100%">Sign up</button><p class="sub" style="margin-top:14px"><button type="button" class="link" data-v="login">Back to log in</button></p>`,
    forgot: `<h2>Reset password</h2><p class="sub">Step 1: enter your email to get a reset code. Step 2: enter the code and a new password.</p>
  <label>Email<input name="email" type="email" required></label><label>Reset code<input name="code" inputmode="numeric"></label><label>New password<input name="pass" type="password" minlength="6"></label>
  <button class="btn" style="width:100%">Continue</button><p class="sub" style="margin-top:14px"><button type="button" class="link" data-v="login">Back to log in</button></p>`}[v];
  app.innerHTML = `<div class="auth"><section class="hero"><h1>Assetly</h1><div><p style="font-size:20px;margin-bottom:18px;color:#fff">One place to track, maintain, and understand every asset on campus.</p><div class="tags"><span>Asset records</span><span>Maintenance tickets</span><span>AI analytics</span></div></div><p style="font-size:13px">Property Office · [School Name]</p></section>
 <section class="formwrap"><form class="form" id="af">${S.err ? `<div class="err">${S.err}</div>` : ''}${F}</form></section></div>`;
  app.querySelectorAll('[data-v]').forEach(b => b.onclick = () => { S.view = b.dataset.v; S.err = ''; authView() });
  $('#af').onsubmit = async e => {
    e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
    try {
      const r = await api(v === 'forgot' && f.code ? '/reset' : '/' + v, 'POST', f);
      if (v === 'login') { TK.set(r.token); S.user = r.user; S.page = isAdmin() ? 'dashboard' : 'report'; S.err = ''; await refresh(); render() }
      else if (v === 'forgot' && !f.code) toast(r.message);
      else { S.view = 'login'; S.err = ''; authView(); toast(r.message) }
    } catch (x) { S.err = x.message; authView() }
  }
}
function logout() { TK.set(null); S.user = null; S.view = 'login'; authView() }

/* ---------- SHELL ---------- */
function render() {
  if (!S.user) return authView();
  const nav = isAdmin() ? [['dashboard', 'Dashboard'], ['assets', 'Assets'], ['tickets', 'Tickets'], ['trash', 'Trash']] : [['report', 'Report & My Tickets']];
  app.innerHTML = `<div class="shell"><aside><div class="brand">Assets<b>ly</b></div>${nav.map(([k, l]) => `<button class="nav ${S.page === k ? 'on' : ''}" data-p="${k}">${l}</button>`).join('')}
 <button class="nav" id="lo">Log out</button><div class="me"><div class="av">${S.user.name[0]}</div><div><b>${S.user.name}</b><small>${S.user.role}</small></div></div></aside><main id="main"></main></div>`;
  app.querySelectorAll('[data-p]').forEach(b => b.onclick = async () => { S.page = b.dataset.p; S.q = ''; await refresh(); render() }); $('#lo').onclick = logout;
  ({ dashboard, assets: assetsPage, tickets: ticketsPage, trash, report })[S.page]();
}
const kpi = (n, l, c) => `<div class="card kpi" style="--c:${c}"><b>${n}</b><span>${l}</span></div>`;
const bars = (o) => { const m = Math.max(1, ...Object.values(o)); return Object.entries(o).map(([k, v]) => `<div class="bar"><span>${k}</span><i style="width:${v / m * 100}%"></i><b>${v}</b></div>`).join('') || '<p class="empty">No data yet.</p>' };
const count = (arr, f) => arr.reduce((o, x) => (o[f(x)] = (o[f(x)] || 0) + 1, o), {});

/* ---------- ADMIN: DASHBOARD ---------- */
function dashboard() {
  const A = assets().filter(a => !a.del), T = tickets(), byS = count(A, a => a.status), byC = count(A, a => a.cat), byB = count(A, a => a.bld);
  const open = T.filter(t => t.status === 'Open').length, col = { Good: '#2e9e6b', 'Needs Repair': '#f2a541', 'Under Repair': '#3b78d8', Damaged: '#d64545' };
  let acc = 0; const grad = STAT.map(s => { const p = (byS[s] || 0) / (A.length || 1) * 100, r = `${col[s]} ${acc}% ${acc + p}%`; acc += p; return r }).join(',');
  const worst = Object.entries(count(A.filter(a => a.status !== 'Good'), a => a.bld)).sort((a, b) => b[1] - a[1])[0];
  const insight = worst ? `${worst[0]} has the most assets needing attention (${worst[1]}). Consider scheduling maintenance there first.` : 'All assets are in good condition.';
  $('#main').innerHTML = `<header><h2>Dashboard</h2></header>
 <div class="grid kpis">${kpi(A.length, 'Total assets', '#0e2238')}${STAT.map(s => kpi(byS[s] || 0, s, col[s])).join('')}${kpi(open, 'Open tickets', '#f2a541')}</div>
 <div class="grid two"><div class="card"><h3>Asset condition</h3><br><div class="donut" style="background:conic-gradient(${grad || '#e1e7ee 0 100%'})"></div><p style="text-align:center;font-size:13px;margin-top:10px">${STAT.map(s => `<span style="color:${col[s]}">●</span> ${s}`).join(' &nbsp;')}</p></div>
 <div class="card"><h3>Assets by category</h3>${bars(byC)}<h3 style="margin-top:14px">By building</h3>${bars(byB)}</div></div>
 <div class="insight card" style="margin-bottom:16px"><b>AI insight:</b> ${insight}</div>
 <div class="grid two"><div class="card"><h3>Ask Assetly AI</h3><div class="chat" id="chat"><div class="msg">Hi! Try: "how many assets need repair?", "assets in Comp Lab 1", or "open tickets".</div></div>
 <form class="row" id="cf"><input id="cq" placeholder="Ask about your assets…" required><button class="btn">Ask</button></form></div>
 <div class="card"><h3>Activity log</h3><ul class="log">${C.log.slice(0, 8).map(l => `<li>${l.m}<br><small>${l.t}</small></li>`).join('')}</ul></div></div>`;
  $('#cf').onsubmit = async e => {
    e.preventDefault(); const q = $('#cq').value, c = $('#chat'), add = (u, h) => { const d = document.createElement('div'); d.className = 'msg' + (u ? ' u' : ''); u ? d.textContent = h : d.innerHTML = h; c.append(d); c.scrollTop = 1e5 };
    add(1, q); e.target.reset(); try { add(0, (await api('/ai', 'POST', { q })).answer) } catch (x) { add(0, x.message) }
  };
}

/* ---------- ADMIN: ASSETS ---------- */
function assetsPage() {
  const A = assets().filter(a => !a.del && (a.name + a.room + a.bld + a.cat + a.id).toLowerCase().includes(S.q.toLowerCase()));
  $('#main').innerHTML = `<header><h2>Assets</h2><div class="row"><input id="sq" placeholder="Search assets…" value="${S.q}" style="width:220px;margin:0"><button class="btn" id="add">+ Add asset</button></div></header>
 <div class="card tw"><table><thead><tr><th>ID</th><th>Name</th><th>Category</th><th>Location</th><th>Status</th><th></th></tr></thead><tbody>
 ${A.map(a => `<tr class="click" data-id="${a.id}"><td>${a.id}</td><td>${a.name}</td><td>${a.cat}</td><td>${a.bld} · ${a.room}</td><td>${pill(a.status)}</td>
 <td><button class="btn ghost sm" data-e="${a.id}">Edit</button> <button class="btn red sm" data-d="${a.id}">Delete</button></td></tr>`).join('') || '<tr><td colspan="6" class="empty">No assets found. Add your first asset.</td></tr>'}</tbody></table></div>`;
  $('#sq').oninput = e => { S.q = e.target.value; assetsPage(); $('#sq').focus() }; $('#add').onclick = () => assetForm();
  document.querySelectorAll('[data-id]').forEach(r => r.onclick = () => assetDetail(r.dataset.id));
  document.querySelectorAll('[data-e]').forEach(b => b.onclick = e => { e.stopPropagation(); assetForm(b.dataset.e) });
  document.querySelectorAll('[data-d]').forEach(b => b.onclick = async e => { e.stopPropagation(); const a = assets().find(x => x.id === b.dataset.d); if (confirm(`Move "${a.name}" to Trash?`)) { await api('/assets/' + a.id, 'DELETE'); await refresh(); assetsPage() } });
}
function assetDetail(id) {
  const a = assets().find(x => x.id === id);
  modal.innerHTML = `<h2>${a.name}</h2><p class="sub">${a.id} · ${pill(a.status)}</p><br><div class="cols"><p><b>Category</b><br>${a.cat}</p><p><b>Location</b><br>${a.bld}, ${a.room}</p><p><b>Condition</b><br>${a.cond}</p><p><b>Date acquired</b><br>${a.date}</p></div><p><b>Notes</b><br>${a.notes || '—'}</p><br>
 <p><b>Related tickets</b></p>${tickets().filter(t => t.asset.toLowerCase() === a.name.toLowerCase()).map(t => `<p>${t.type === 'defect' ? 'Defect' : 'Update'} · ${pill(t.status)} · ${t.date}</p>`).join('') || '<p class="sub">None</p>'}<br><button class="btn ghost" onclick="modal.close()">Close</button>`; modal.showModal()
}
function assetForm(id) {
  const a = id ? assets().find(x => x.id === id) : { name: '', cat: CATS[0], bld: '', room: '', status: 'Good', cond: 'Good', date: '', notes: '' };
  const o = (L, v) => L.map(x => `<option ${x === v ? 'selected' : ''}>${x}</option>`).join('');
  modal.innerHTML = `<h2>${id ? 'Edit' : 'Add'} asset</h2><br><form id="mf"><div class="cols"><label>Name<input name="name" value="${a.name}" required></label><label>Category<select name="cat">${o(CATS, a.cat)}</select></label>
 <label>Building<input name="bld" value="${a.bld}" required></label><label>Room / Lab<input name="room" value="${a.room}" required></label>
 <label>Status<select name="status">${o(STAT, a.status)}</select></label><label>Condition<select name="cond">${o(['Good', 'Fair', 'Poor'], a.cond)}</select></label>
 <label>Date acquired<input type="date" name="date" value="${a.date}"></label></div><label>Notes<textarea name="notes">${a.notes}</textarea></label>
 <div class="row"><button class="btn">Save</button><button type="button" class="btn ghost" onclick="modal.close()">Cancel</button></div></form>`; modal.showModal();
  $('#mf').onsubmit = async e => { e.preventDefault(); try { await api('/assets' + (id ? '/' + id : ''), id ? 'PUT' : 'POST', Object.fromEntries(new FormData(e.target))); await refresh(); modal.close(); assetsPage(); toast('Asset saved') } catch (x) { toast(x.message) } }
}

/* ---------- ADMIN: TICKETS ---------- */
function ticketsPage() {
  const T = tickets();
  $('#main').innerHTML = `<header><h2>Tickets</h2></header><div class="card tw"><table><thead><tr><th>Type</th><th>Asset</th><th>Location</th><th>Reported by</th><th>Notes</th><th>Files</th><th>Status</th></tr></thead><tbody>
 ${T.map(t => `<tr><td>${t.type === 'defect' ? 'Defect' : 'Update: ' + t.action}</td><td>${t.asset}</td><td>${t.bld} · ${t.room}</td><td>${t.by}<br><small>${t.date}</small></td><td>${t.notes || '—'}</td><td><small>${t.files.map((f, i) => `<a href="/files/${f}?token=${TK.get()}" target="_blank">${['School ID', 'Photo'][i]}</a>`).join('<br>')}</small></td>
 <td><select data-t="${t.id}" style="margin:0">${(t.type === 'defect' ? DEF_ST : UPD_ST).map(s => `<option ${s === t.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td></tr>`).join('') || '<tr><td colspan="7" class="empty">No tickets yet. Teacher reports will appear here.</td></tr>'}</tbody></table></div>`;
  document.querySelectorAll('[data-t]').forEach(s => s.onchange = async () => { try { await api('/tickets/' + s.dataset.t, 'PATCH', { status: s.value }); await refresh(); toast('Status updated') } catch (x) { toast(x.message) } })
}

/* ---------- ADMIN: TRASH ---------- */
function trash() {
  const A = assets().filter(a => a.del);
  $('#main').innerHTML = `<header><h2>Trash</h2></header><div class="card tw"><table><thead><tr><th>ID</th><th>Name</th><th>Location</th><th>Deleted</th><th></th></tr></thead><tbody>
 ${A.map(a => `<tr><td>${a.id}</td><td>${a.name}</td><td>${a.bld} · ${a.room}</td><td>${a.delAt || ''}</td><td><button class="btn sm" data-r="${a.id}">Restore</button></td></tr>`).join('') || '<tr><td colspan="5" class="empty">Trash is empty.</td></tr>'}</tbody></table></div>`;
  document.querySelectorAll('[data-r]').forEach(b => b.onclick = async () => { await api('/assets/' + b.dataset.r + '/restore', 'POST'); await refresh(); trash(); toast('Asset restored') })
}

/* ---------- TEACHER ---------- */
function report() {
  const mine = tickets().filter(t => t.byId === S.user.id), c = s => mine.filter(t => t.status === s).length;
  $('#main').innerHTML = `<header><h2>Hello, ${S.user.name.split(' ')[0]}</h2></header>
 <div class="grid kpis">${kpi(mine.length, 'My reports', '#0e2238')}${kpi(c('Open'), 'Open', '#f2a541')}${kpi(c('In Progress'), 'In progress', '#3b78d8')}${kpi(c('Resolved') + c('Recorded'), 'Resolved / Recorded', '#2e9e6b')}</div>
 <div class="grid two" style="grid-template-columns:1.1fr 1fr"><div class="card"><h3>New report</h3><br><div class="seg"><button class="btn" id="t1" type="button">Report a defect</button><button class="btn ghost" id="t2" type="button">Report an update</button></div><form id="rf"></form></div>
 <div class="card"><h3>Recently reported</h3><br>${mine.slice(0, 8).map(t => `<p><b>${t.asset}</b> ${pill(t.status)}<br><small>${t.type === 'defect' ? 'Defect' : 'Update: ' + t.action} · ${t.date}</small></p><hr style="border:0;border-top:1px solid var(--line);margin:8px 0">`).join('') || '<p class="empty">No reports yet.</p>'}</div></div>`;
  let type = 'defect'; const form = () => {
    const d = type === 'defect';
    $('#t1').className = 'btn' + (d ? '' : ' ghost'); $('#t2').className = 'btn' + (d ? ' ghost' : '');
    $('#rf').innerHTML = `<label>Asset name<input name="asset" required></label><div class="cols"><label>Building<input name="bld" required></label><label>Room / Lab<input name="room" required></label></div>
  <div class="cols"><label>Category<select name="cat">${CATS.map(x => `<option>${x}</option>`).join('')}</select></label>${d ? '' : `<label>What changed?<select name="action"><option>Added</option><option>Removed</option><option>Moved</option></select></label>`}</div>
  <label>Notes ${d ? '(required — describe the problem)' : '(optional)'}<textarea name="notes" ${d ? 'required' : ''}></textarea></label>
  <label>School ID photo<input type="file" name="id" accept="image/*" required></label>${d ? '<label>Photo of the broken asset<input type="file" name="photo" accept="image/*" required></label>' : ''}
  <button class="btn">Submit report</button>`};
  form(); $('#t1').onclick = () => { type = 'defect'; form() }; $('#t2').onclick = () => { type = 'update'; form() };
  $('#rf').onsubmit = async e => { e.preventDefault(); const fd = new FormData(e.target); fd.append('type', type); try { await api('/tickets', 'POST', fd); await refresh(); toast('Report submitted'); report() } catch (x) { toast(x.message) } }
}

(async () => { if (TK.get()) { try { S.user = (await api('/me')).user; S.page = isAdmin() ? 'dashboard' : 'report'; await refresh(); return render() } catch { TK.set(null) } } authView() })();
