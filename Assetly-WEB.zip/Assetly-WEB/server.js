const express = require('express'), Database = require('better-sqlite3'), bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken'), multer = require('multer'), path = require('path'), fs = require('fs'), crypto = require('crypto');
const { PORT = 3000, JWT_SECRET = 'dev-secret-change-me', ADMIN_EMAIL = 'admin@assetly.edu', ADMIN_PASSWORD = 'admin123', DB_FILE = 'assetly.db' } = process.env;
const UP = path.join(__dirname, 'uploads'); fs.mkdirSync(UP, { recursive: true });
const db = new Database(path.join(__dirname, DB_FILE)); db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,email TEXT UNIQUE,pass TEXT,role TEXT);
CREATE TABLE IF NOT EXISTS assets(n INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE,name,cat,bld,room,status,cond,date,notes,del INTEGER DEFAULT 0,delAt);
CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY AUTOINCREMENT,type,asset,bld,room,cat,action,notes,files,status,"by",byId INTEGER,date);
CREATE TABLE IF NOT EXISTS log(id INTEGER PRIMARY KEY AUTOINCREMENT,t,m);`);
const CATS = ['Computer', 'Furniture', 'Laboratory Equipment', 'Electrical', 'Audio/Visual', 'Sports', 'Other'], STAT = ['Good', 'Needs Repair', 'Under Repair', 'Damaged'];
const esc = s => String(s ?? '').trim().replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); // stored escaped so the UI can render safely
const now = () => new Date().toLocaleString(), log = m => db.prepare('INSERT INTO log(t,m) VALUES(?,?)').run(now(), m);
if (!db.prepare("SELECT 1 FROM users WHERE role='Main Admin'").get()) {
    db.prepare('INSERT INTO users(name,email,pass,role) VALUES(?,?,?,?)').run('Juan Cruz', ADMIN_EMAIL, bcrypt.hashSync(ADMIN_PASSWORD, 10), 'Main Admin');
    [['Desktop PC #1', 'Computer', 'Main Bldg', 'Comp Lab 1', 'Good'], ['Projector', 'Audio/Visual', 'Main Bldg', 'Room 204', 'Needs Repair'], ['Microscope', 'Laboratory Equipment', 'Science Bldg', 'Sci Lab', 'Under Repair'], ['Teacher Desk', 'Furniture', 'Main Bldg', 'Room 101', 'Good'], ['Old Monitor', 'Computer', 'Main Bldg', 'Comp Lab 1', 'Damaged']]
        .forEach((a, i) => db.prepare('INSERT INTO assets(id,name,cat,bld,room,status,cond,date,notes) VALUES(?,?,?,?,?,?,?,?,?)').run('A-00' + (i + 1), ...a, 'Good', '2024-01-01', 'Sample record'));
}
const app = express(); app.use(express.json()); app.use(express.static(path.join(__dirname, 'public')));
const auth = roles => (req, res, next) => {
    try { req.user = jwt.verify((req.headers.authorization || '').slice(7) || req.query.token, JWT_SECRET) } catch { return res.status(401).json({ error: 'Please log in again.' }) }
    if (roles && !roles.some(r => req.user.role.includes(r))) return res.status(403).json({ error: 'Not allowed.' }); next()
};
const admin = auth(['Admin']);
/* ---- auth ---- */
app.post('/api/signup', (req, res) => {
    const name = esc(req.body.name), email = esc(req.body.email).toLowerCase(), pass = String(req.body.pass || '');
    if (!name || !/^\S+@\S+\.\S+$/.test(email) || pass.length < 6) return res.status(400).json({ error: 'Enter a name, a valid email, and a password of 6+ characters.' });
    if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email)) return res.status(400).json({ error: 'That email is already registered.' });
    db.prepare('INSERT INTO users(name,email,pass,role) VALUES(?,?,?,?)').run(name, email, bcrypt.hashSync(pass, 10), 'Teacher'); log(`New teacher registered: ${name}`); res.json({ message: 'Account created. You can log in now.' })
});
app.post('/api/login', (req, res) => {
    const u = db.prepare('SELECT * FROM users WHERE email=?').get(esc(req.body.email).toLowerCase());
    if (!u || !bcrypt.compareSync(String(req.body.pass || ''), u.pass)) return res.status(401).json({ error: 'Email or password is incorrect.' });
    const user = { id: u.id, name: u.name, role: u.role }; res.json({ token: jwt.sign(user, JWT_SECRET, { expiresIn: '8h' }), user })
});
app.get('/api/me', auth(), (req, res) => res.json({ user: { id: req.user.id, name: req.user.name, role: req.user.role } }));
const resets = new Map();
app.post('/api/forgot', (req, res) => {
    const email = esc(req.body.email).toLowerCase();
    if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email)) { const code = String(crypto.randomInt(100000, 999999)); resets.set(email, { code, exp: Date.now() + 9e5 }); console.log(`[RESET CODE] ${email}: ${code} (replace with an email service in production)`) }
    res.json({ message: 'If that email is registered, a reset code was generated. In development, read it from the server console.' })
});
app.post('/api/reset', (req, res) => {
    const email = esc(req.body.email).toLowerCase(), r = resets.get(email), pass = String(req.body.pass || '');
    if (!r || r.code !== String(req.body.code).trim() || r.exp < Date.now() || pass.length < 6) return res.status(400).json({ error: 'Invalid or expired code, or password is shorter than 6 characters.' });
    db.prepare('UPDATE users SET pass=? WHERE email=?').run(bcrypt.hashSync(pass, 10), email); resets.delete(email); res.json({ message: 'Password updated.' })
});
/* ---- data ---- */
app.get('/api/data', auth(), (req, res) => {
    const isA = req.user.role.includes('Admin');
    const T = (isA ? db.prepare('SELECT * FROM tickets ORDER BY id DESC').all() : db.prepare('SELECT * FROM tickets WHERE byId=? ORDER BY id DESC').all(req.user.id)).map(t => ({ ...t, files: JSON.parse(t.files) }));
    res.json({ assets: isA ? db.prepare('SELECT * FROM assets ORDER BY n').all() : [], tickets: T, log: isA ? db.prepare('SELECT t,m FROM log ORDER BY id DESC LIMIT 50').all() : [] })
});
const AF = b => { const o = { name: esc(b.name), cat: CATS.includes(b.cat) ? b.cat : 'Other', bld: esc(b.bld), room: esc(b.room), status: STAT.includes(b.status) ? b.status : 'Good', cond: ['Good', 'Fair', 'Poor'].includes(b.cond) ? b.cond : 'Good', date: esc(b.date), notes: esc(b.notes) }; return o.name && o.bld && o.room ? o : null };
app.post('/api/assets', admin, (req, res) => {
    const o = AF(req.body); if (!o) return res.status(400).json({ error: 'Name, building and room are required.' });
    db.transaction(() => { const n = db.prepare('SELECT COALESCE(MAX(n),0)+1 n FROM assets').get().n; db.prepare('INSERT INTO assets(n,id,name,cat,bld,room,status,cond,date,notes) VALUES(@n,@id,@name,@cat,@bld,@room,@status,@cond,@date,@notes)').run({ n, id: 'A-' + String(n).padStart(3, '0'), ...o }) })();
    log(`${req.user.name} added ${o.name}`); res.json({ ok: 1 })
});
app.put('/api/assets/:id', admin, (req, res) => {
    const o = AF(req.body); if (!o) return res.status(400).json({ error: 'Name, building and room are required.' });
    db.prepare('UPDATE assets SET name=@name,cat=@cat,bld=@bld,room=@room,status=@status,cond=@cond,date=@date,notes=@notes WHERE id=@id').run({ ...o, id: req.params.id }); log(`${req.user.name} updated ${o.name}`); res.json({ ok: 1 })
});
app.delete('/api/assets/:id', admin, (req, res) => { db.prepare('UPDATE assets SET del=1,delAt=? WHERE id=?').run(now(), req.params.id); log(`${req.user.name} moved ${req.params.id} to Trash`); res.json({ ok: 1 }) });
app.post('/api/assets/:id/restore', admin, (req, res) => { db.prepare('UPDATE assets SET del=0,delAt=NULL WHERE id=?').run(req.params.id); log(`${req.user.name} restored ${req.params.id}`); res.json({ ok: 1 }) });
/* ---- tickets ---- */
const EXT = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif' };
const up = multer({ storage: multer.diskStorage({ destination: UP, filename: (q, f, cb) => cb(null, crypto.randomBytes(12).toString('hex') + EXT[f.mimetype]) }), limits: { fileSize: 5e6 }, fileFilter: (q, f, cb) => cb(EXT[f.mimetype] ? null : new Error('Only JPG, PNG, WEBP or GIF images up to 5 MB are allowed.'), !!EXT[f.mimetype]) });
app.post('/api/tickets', auth(['Teacher']), up.fields([{ name: 'id', maxCount: 1 }, { name: 'photo', maxCount: 1 }]), (req, res) => {
    const b = req.body, type = b.type === 'update' ? 'update' : 'defect', f = req.files || {};
    const asset = esc(b.asset), bld = esc(b.bld), room = esc(b.room), notes = esc(b.notes);
    if (!asset || !bld || !room || !f.id || (type === 'defect' && (!notes || !f.photo))) { Object.values(f).flat().forEach(x => fs.unlink(x.path, () => { })); return res.status(400).json({ error: 'Complete all required fields and attach the required photos.' }) }
    const files = [f.id[0].filename, ...(type === 'defect' ? [f.photo[0].filename] : [])], action = type === 'update' ? (['Added', 'Removed', 'Moved'].includes(b.action) ? b.action : 'Added') : '';
    db.prepare('INSERT INTO tickets(type,asset,bld,room,cat,action,notes,files,status,"by",byId,date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(type, asset, bld, room, CATS.includes(b.cat) ? b.cat : 'Other', action, notes, JSON.stringify(files), 'Open', req.user.name, req.user.id, now());
    log(`${req.user.name} submitted a ${type} ticket for ${asset}`); res.json({ ok: 1 })
});
app.patch('/api/tickets/:id', admin, (req, res) => {
    const t = db.prepare('SELECT * FROM tickets WHERE id=?').get(req.params.id);
    if (!t || !(t.type === 'defect' ? ['Open', 'In Progress', 'Resolved'] : ['Open', 'Recorded']).includes(req.body.status)) return res.status(400).json({ error: 'Invalid status for this ticket.' });
    db.prepare('UPDATE tickets SET status=? WHERE id=?').run(req.body.status, t.id); log(`${req.user.name} set ${t.asset} ticket to ${req.body.status}`); res.json({ ok: 1 })
});
app.get('/files/:name', admin, (req, res) => res.sendFile(path.join(UP, path.basename(req.params.name))));
/* ---- Assetly AI: uses Claude if ANTHROPIC_API_KEY is set, otherwise simple rules ---- */
app.post('/api/ai', admin, async (req, res) => {
    const q = String(req.body.q || '').slice(0, 500), A = db.prepare('SELECT id,name,cat,bld,room,status,cond FROM assets WHERE del=0').all(), T = db.prepare('SELECT type,asset,bld,room,status FROM tickets').all();
    if (process.env.ANTHROPIC_API_KEY) {
        try {
            const r = await fetch('https://api.anthropic.com/v1/messages', {
                method: 'POST', headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
                body: JSON.stringify({ model: process.env.AI_MODEL || 'claude-sonnet-4-6', max_tokens: 500, system: 'You are Assetly AI for a school property office. Answer briefly using only this data: ' + JSON.stringify({ assets: A.slice(0, 300), tickets: T.slice(0, 300) }), messages: [{ role: 'user', content: q }] })
            });
            const j = await r.json(); if (r.ok) return res.json({ answer: esc(j.content?.[0]?.text).replace(/\n/g, '<br>') })
        } catch { }
    }
    const l = q.toLowerCase(), bad = A.filter(a => a.status !== 'Good'), hit = A.filter(a => [a.room, a.bld, a.cat].some(x => l.includes(x.toLowerCase())));
    res.json({ answer: /repair|broken|damag/.test(l) ? `${bad.length} assets need attention: ` + bad.map(a => `${a.name} (${a.status})`).join(', ') : /ticket/.test(l) ? `${T.filter(t => t.status === 'Open').length} open tickets out of ${T.length}.` : hit.length ? hit.map(a => `${a.name} — ${a.room} (${a.status})`).join('<br>') : /how many|total/.test(l) ? `There are ${A.length} active assets.` : 'I can answer questions about asset counts, conditions, locations, and tickets.' })
});
app.use((err, req, res, next) => res.status(400).json({ error: err.message }));
app.listen(PORT, () => console.log(`Assetly running at http://localhost:${PORT}`));
