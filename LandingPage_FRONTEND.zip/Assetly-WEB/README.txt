Neue Montreal font files go in this folder.

Neue Montreal is made by Pangram Pangram (pangrampangram.com). It is not on
Google Fonts, so download it from their site and follow its license.

Copy these files here (use .woff2, .otf or .ttf - any one format is enough):

  NeueMontreal-Light
  NeueMontreal-Regular
  NeueMontreal-Medium
  NeueMontreal-Bold

Example: fonts/NeueMontreal-Regular.otf

If your files are named differently, rename them or edit the
@font-face part at the top of stylesheet.css.
Until the files are added, the site uses Helvetica Neue / Arial instead.
