<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Assetly - Password changed</title>
<link rel="stylesheet" href="stylesheet.css?v=<?php echo filemtime(__DIR__ . '/stylesheet.css'); ?>">
</head>

<body>

<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="check" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></symbol>
</svg>

<div class="simple">
  <header class="topbar">
    <img src="images/menu-logo.png" alt="" height="34">
    <span>Assetly</span>
  </header>
  <main>
    <div class="card-box done">
      <div class="big-check"><svg class="i"><use href="#check"/></svg></div>
      <h2>Password changed!</h2>
      <p class="subtitle">Your password has been changed successfully!</p>
      <a href="#" class="btn btn-fill btn-link">Back to log in</a>
    </div>
  </main>
</div>

</body>
</html>
