<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Assetly - Set new password</title>
  <link rel="stylesheet" href="stylesheet.css?v=<?php echo filemtime(__DIR__ . '/stylesheet.css'); ?>">
</head>

<body>

  <svg width="0" height="0" style="position:absolute" aria-hidden="true">
    <symbol id="lock" viewBox="0 0 24 24">
      <rect x="4" y="11" width="16" height="10" rx="2" />
      <path d="M8 11V7a4 4 0 0 1 8 0v4" />
    </symbol>
    <symbol id="check" viewBox="0 0 24 24">
      <path d="M5 12.5l4.5 4.5L19 7.5" />
    </symbol>
    <symbol id="eye" viewBox="0 0 24 24">
      <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z" />
      <circle cx="12" cy="12" r="3" />
    </symbol>
    <symbol id="back" viewBox="0 0 24 24">
      <path d="m15 6-6 6 6 6" />
    </symbol>
  </svg>

  <div class="simple">
    <header class="topbar">
      <img src="images/menu-logo.png" alt="" height="34">
      <span>Assetly</span>
    </header>
    <main>
      <div class="card-box">
        <div class="icon-badge"><svg class="i">
            <use href="#lock" />
          </svg></div>
        <span class="pill">Step 3 of 3</span>
        <h2>Set new password</h2>
        <p class="subtitle">Choose a strong password you haven’t used before.</p>
        <form method="post">
          <label for="newpassword">New password:</label>
          <div class="field">
            <input type="password" id="newpassword" name="newpassword" placeholder="Enter new password">
            <button type="button" class="eye" id="eye1" aria-label="Show password">
              <svg class="i">
                <use href="#eye" />
              </svg>
            </button>
          </div>
          <label for="confirmpassword">Confirm password:</label>
          <div class="field">
            <input type="password" id="confirmpassword" name="confirmpassword" placeholder="Re-enter new password">
            <button type="button" class="eye" id="eye2" aria-label="Show password">
              <svg class="i">
                <use href="#eye" />
              </svg>
            </button>
          </div>
          <div class="rules">
            <p class="rule" id="rule-length">
              <span class="tick"><svg class="i">
                  <use href="#check" />
                </svg></span>
              At least 8 characters
            </p>
            <p class="rule" id="rule-number">
              <span class="tick"><svg class="i">
                  <use href="#check" />
                </svg></span>
              Contains a number
            </p>
            <p class="rule" id="rule-symbol">
              <span class="tick"><svg class="i">
                  <use href="#check" />
                </svg></span>
              Contains a symbol
            </p>
          </div>
          <button type="submit" class="btn btn-fill">Save password</button>
        </form>
        <a href="#" class="back"><svg class="i">
            <use href="#back" />
          </svg> Back to log in</a>
      </div>
    </main>
  </div>

  <script>
    // show / hide password
    function setupEye(buttonId, inputId) {
      var button = document.getElementById(buttonId);
      var input = document.getElementById(inputId);

      button.onclick = function() {
        if (input.type === "password") {
          input.type = "text";
        } else {
          input.type = "password";
        }
      };
    }

    setupEye("eye1", "newpassword");
    setupEye("eye2", "confirmpassword");

    // password guide
    var newPassword = document.getElementById("newpassword");
    var ruleLength = document.getElementById("rule-length");
    var ruleNumber = document.getElementById("rule-number");
    var ruleSymbol = document.getElementById("rule-symbol");

    // adds the class "ok" if done is true, removes it if false
    function mark(rule, done) {
      if (done) {
        rule.classList.add("ok");
      } else {
        rule.classList.remove("ok");
      }
    }

    // runs every time the user types in the password box
    newPassword.oninput = function() {
      var text = newPassword.value;

      mark(ruleLength, text.length >= 8);
      mark(ruleNumber, /[0-9]/.test(text));
      mark(ruleSymbol, /[^A-Za-z0-9\s]/.test(text));
    };

    // front-end for now; stops the form from reloading the page
    // FOR BACKEND LATER !! remove this shi so the code is sent to the server
    document.querySelector("form").onsubmit = function(e) {
      e.preventDefault();
    };
  </script>

</body>

</html>