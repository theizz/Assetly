<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Assetly - Check your email</title>
  <link rel="stylesheet" href="stylesheet.css?v=<?php echo filemtime(__DIR__ . '/stylesheet.css'); ?>">
</head>

<body>

  <svg width="0" height="0" style="position:absolute" aria-hidden="true">
    <symbol id="shield" viewBox="0 0 24 24">
      <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
      <path d="m9 12 2 2 4-4" />
    </symbol>
    <symbol id="clock" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </symbol>
  </svg>

  <div class="simple">
    <header class="topbar">
      <img src="images/menu-logo.png" alt="" height="34">
      <span>Assetly</span>
    </header>
    <main>
      <div class="card-box">
        <div class="icon-badge"><svg class="i">
            <use href="#shield" />
          </svg></div>
        <span class="pill">Step 2 of 3</span>
        <h2>Check your email</h2>
        <p class="subtitle">Enter the 6-digit code to continue.</p>
        <p class="info">If the email is registered, a verification code was sent. It expires in 15 minutes.</p>
        <form method="post">
          <div class="otp">
            <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 1">
            <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 2">
            <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 3">
            <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 4">
            <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 5">
            <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 6">
          </div>
          <p class="expire"><svg class="i">
              <use href="#clock" />
            </svg> Code expires in <span id="expires">15:00</span></p>
          <button type="submit" class="btn btn-fill">Verify code</button>
        </form>
        <p class="resend" id="resend"></p>
        <hr class="line">
        <p class="links"><a href="#">Change email</a> <span>·</span> <a href="#">Back to log in</a></p>
      </div>
    </main>
  </div>

  <script>
    // 6 code boxes
    var boxes = document.querySelectorAll(".otp input");
    boxes[0].focus();

    // gives every box its behavior (box number i)
    function setupBox(i) {
      var box = boxes[i];

      // jumps to the next box after typing a number, ok? hell yeah
      box.oninput = function() {
        box.value = box.value.replace(/[^0-9]/g, ""); // numbers only
        if (box.value !== "" && i < 5) {
          boxes[i + 1].focus();
        }
      };

      // backspace on an empty box goes back to the previous box
      box.onkeydown = function(e) {
        if (e.key === "Backspace" && box.value === "" && i > 0) {
          boxes[i - 1].focus();
        }
      };
    }

    for (var i = 0; i < boxes.length; i++) {
      setupBox(i);
    }

    // pasting a full code fills all the boxes at once
    boxes[0].onpaste = function(e) {
      e.preventDefault();
      var code = e.clipboardData.getData("text").replace(/[^0-9]/g, "");
      for (var j = 0; j < code.length && j < 6; j++) {
        boxes[j].value = code[j];
      }
    };

    // timers
    var expiresIn = 15 * 60; // code lasts 15 minutes (counted in seconds)
    var resendIn = 30; // wait 30 seconds before asking for a new code

    var expiresText = document.getElementById("expires");
    var resendText = document.getElementById("resend");

    // turns seconds into minutes:seconds  (ex: 75 becomes 1:15)
    function showTime(seconds) {
      var minutes = Math.floor(seconds / 60);
      var rest = seconds % 60;
      if (rest < 10) {
        rest = "0" + rest;
      }
      return minutes + ":" + rest;
    }

    // shows "Resend code in 0:30", or the resend link when the wait is over
    function updateResend() {
      if (resendIn > 0) {
        resendText.innerHTML = "Didn't receive the code? Resend in <b>" + showTime(resendIn) + "</b>";
      } else {
        resendText.innerHTML = "Didn't receive the code? <a href='#' id='again'>Resend code</a>";
        document.getElementById("again").onclick = resendCode;
      }
    }

    function resendCode(e) {
      e.preventDefault();
      // FOR BACKEND LATER !! ask the server to send a new code here
      expiresIn = 15 * 60;
      resendIn = 30;
      updateResend();
    }

    // runs every 1 second
    setInterval(function() {
      if (expiresIn > 0) {
        expiresIn = expiresIn - 1;
      }
      if (resendIn > 0) {
        resendIn = resendIn - 1;
      }
      expiresText.textContent = showTime(expiresIn);
      updateResend();
    }, 1000);

    updateResend();

    // front-end for now; stops the form from reloading the page
    // FOR BACKEND LATER !! remove this shi so the code is sent to the server
    document.querySelector("form").onsubmit = function(e) {
      e.preventDefault();
    };
  </script>

</body>

</html>