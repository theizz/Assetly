<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Assetly - Sign up</title>
  <link rel="stylesheet" href="stylesheet.css?v=<?php echo filemtime(__DIR__ . '/stylesheet.css'); ?>">
</head>

<body>

  <!-- ICONS (ignore niyo lang to, for icon drawings yan) -->
  <svg width="0" height="0" style="position:absolute" aria-hidden="true">
    <symbol id="users" viewBox="0 0 24 24">
      <circle cx="9" cy="8" r="3.5" />
      <path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6" />
      <circle cx="17" cy="9" r="2.5" />
      <path d="M17 14c2.7 0 4.5 1.8 4.5 4.5" />
    </symbol>
    <symbol id="wrench" viewBox="0 0 24 24">
      <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
    </symbol>
    <symbol id="check" viewBox="0 0 24 24">
      <path d="M5 12.5l4.5 4.5L19 7.5" />
    </symbol>
    <symbol id="shield" viewBox="0 0 24 24">
      <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
      <path d="m9 12 2 2 4-4" />
    </symbol>
    <symbol id="chart" viewBox="0 0 24 24">
      <path d="M5 20v-6M11 20V9M17 20V4" />
    </symbol>
    <symbol id="layers" viewBox="0 0 24 24">
      <path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5" />
    </symbol>
    <symbol id="clock" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </symbol>
    <symbol id="eye" viewBox="0 0 24 24">
      <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z" />
      <circle cx="12" cy="12" r="3" />
    </symbol>
  </svg>

  <div class="page">

    <!-- ========== LEFT SIDE ========== -->
    <section class="left">
      <h1>
        Every school asset,<br>
        <span class="title">Assetly</span> <span class="records">records them.</span>
      </h1>
      <p class="subtitle">Management, reports and maintenance in one place.</p>

      <div class="stage-wrap">
        <div class="stage">

          <!-- orbit -->
          <div class="orbit">
            <div class="circle-big"></div>
            <div class="circle-small"></div>

            <div class="center"><img src="images/app-icon.png" alt="Assetly logo" width="64" height="64"></div>

            <div class="ring">
              <div class="dot d1"><span><svg class="i">
                    <use href="#users" />
                  </svg></span></div>
              <div class="dot d2"><span><svg class="i">
                    <use href="#wrench" />
                  </svg></span></div>
              <div class="dot d3"><span><svg class="i">
                    <use href="#check" />
                  </svg></span></div>
              <div class="dot d4"><span><svg class="i">
                    <use href="#shield" />
                  </svg></span></div>
              <div class="dot d5"><span><svg class="i">
                    <use href="#chart" />
                  </svg></span></div>
            </div>
          </div>

          <!-- card 1: total assets -->
          <div class="card card-total">
            <div class="card-head">
              <span class="icon-circle"><svg class="i">
                  <use href="#layers" />
                </svg></span>
              Total Assets
            </div>
            <p class="big-number">1,025</p>
            <p class="small-text">Across 6 buildings</p>
          </div>

          <!-- card 2: reports reviewed -->
          <div class="card card-reports">
            <div class="card-head">
              <span class="icon-circle"><svg class="i">
                  <use href="#check" />
                </svg></span>
              Reports reviewed
            </div>
            <div class="mini-box">
              <div class="mini-row">
                <span class="small-text">This week</span>
                <b>18 of 30</b>
              </div>
              <div class="bar">
                <div class="bar-fill"></div>
              </div>
            </div>
          </div>

          <!-- card 3: recent activity -->
          <div class="card card-recent">
            <div class="card-head">
              <span class="icon-circle"><svg class="i">
                  <use href="#clock" />
                </svg></span>
              Recent Activity
            </div>
            <div class="tabs">
              <span>Daily</span>
              <span class="active">Weekly</span>
              <span>Yearly</span>
            </div>
            <div class="row">
              <div>
                <p>Projector, Castelo room 202</p>
                <p class="small-text">October 21, 2026</p>
              </div>
              <span class="badge moved">Moved</span>
            </div>
            <div class="row">
              <div>
                <p>Teacher’s table</p>
                <p class="small-text">October 19, 2026</p>
              </div>
              <span class="badge defect">Defect</span>
            </div>
          </div>

          <!-- card 4: update successful -->
          <div class="card card-toast">
            <span class="icon-circle"><svg class="i">
                <use href="#check" />
              </svg></span>
            <div>
              <p class="toast-title">Update successful</p>
              <p class="small-text">Asus Monitor has change location</p>
            </div>
          </div>

        </div>
      </div>
    </section>

    <!-- ========== RIGHT SIDE: SIGN UP ========== -->
    <section class="right">
      <div class="login-box2">
        <div class="steps">
          <span class="step active"><b class="num">1</b> Input details</span>
          <span class="step"><b class="num">2</b> Verify email</span>
          <span class="step"><b class="num">3</b> Approval</span>
        </div>
        <h2>Create your account</h2>
        <p class="subtitle">Fill in your details. The property custodian will approve your access.</p>

        <form action="Login.html" method="post">

          <!-- first name + last name side by side -->
          <div class="bundle">
            <div class="name-box">
              <label for="firstname">First Name:</label>
              <div class="field">
                <input type="text" id="firstname" name="firstname" placeholder="Ex. John Carl">
              </div>
            </div>

            <div class="name-box">
              <label for="lastname">Last Name:</label>
              <div class="field">
                <input type="text" id="lastname" name="lastname" placeholder="Ex. Rodriguez">
              </div>
            </div>
          </div>

          <label for="email">Email:</label>
          <div class="field">
            <input type="email" id="email" name="email" placeholder="name@school.edu">
          </div>

          <!-- password fields (left) + guide (right) -->
          <div class="password-area">

            <div class="password-fields">
              <label for="createpassword">Password:</label>
              <div class="field">
                <input type="password" id="createpassword" name="createpassword" placeholder="Create password">
                <button type="button" class="eye" id="eye1" aria-label="Show password">
                  <svg class="i">
                    <use href="#eye" />
                  </svg>
                </button>
              </div>

              <label for="confirmpassword">Confirm Password:</label>
              <div class="field">
                <input type="password" id="confirmpassword" name="confirmpassword" placeholder="Re-type your password">
                <button type="button" class="eye" id="eye2" aria-label="Show password">
                  <svg class="i">
                    <use href="#eye" />
                  </svg>
                </button>
              </div>
            </div>

            <!-- guide -->
            <div class="guide">
              <p class="guide-title">Password must have:</p>

              <p class="rule" id="rule-length">
                <span class="tick"><svg class="i">
                    <use href="#check" />
                  </svg></span>
                At least 8 characters
              </p>
              <p class="rule" id="rule-number">
                <span class="tick"><svg class="i">
                    <use href="#check" />
                  </svg></span>
                Contains a number
              </p>
              <p class="rule" id="rule-symbol">
                <span class="tick"><svg class="i">
                    <use href="#check" />
                  </svg></span>
                Contains a symbol
              </p>
            </div>

          </div>

          <button type="submit" class="btn btn-fill">Create account</button>
        </form>

        <p class="note">We’ll email a verification code that expires in 15 minutes.</p>

        <hr class="line">

        <p class="note">Already have an account? <a href="Login.php">Log in</a></p>
      </div>
    </section>

  </div>

  <script>
    // show / hide password
    function setupEye(buttonId, inputId) {
      var button = document.getElementById(buttonId);
      var input = document.getElementById(inputId);

      button.onclick = function() {
        if (input.type === "password") {
          input.type = "text";
        } else {
          input.type = "password";
        }
      };
    }

    setupEye("eye1", "createpassword");
    setupEye("eye2", "confirmpassword");

    // password guide: turns green when the rule is done -----
    var createPassword = document.getElementById("createpassword");
    var ruleLength = document.getElementById("rule-length");
    var ruleNumber = document.getElementById("rule-number");
    var ruleSymbol = document.getElementById("rule-symbol");

    // adds the class "ok" if done is true, removes it if false
    function mark(rule, done) {
      if (done) {
        rule.classList.add("ok");
      } else {
        rule.classList.remove("ok");
      }
    }

    // runs every time the user types in the password box
    createPassword.oninput = function() {
      var text = createPassword.value;

      mark(ruleLength, text.length >= 8);
      mark(ruleNumber, /[0-9]/.test(text));
      mark(ruleSymbol, /[^A-Za-z0-9\s]/.test(text));
    };
  </script>

</body>

</html>