<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Assetly - Forgot password</title>
  <link rel="stylesheet" href="stylesheet.css?v=<?php echo filemtime(__DIR__ . '/stylesheet.css'); ?>">
</head>

<body>

  <svg width="0" height="0" style="position:absolute" aria-hidden="true">
    <symbol id="mail" viewBox="0 0 24 24">
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="m3 7 9 6 9-6" />
    </symbol>
    <symbol id="back" viewBox="0 0 24 24">
      <path d="m15 6-6 6 6 6" />
    </symbol>
  </svg>

  <div class="simple">
    <header class="topbar">
      <img src="images/menu-logo.png" alt="" height="34">
      <span>Assetly</span>
    </header>
    <main>
      <div class="card-box">
        <div class="icon-badge"><svg class="i">
            <use href="#mail" />
          </svg></div>
        <span class="pill">Step 1 of 3</span>
        <h2>Forgot password?</h2>
        <p class="subtitle">Enter the email you registered with and we’ll send you a 6-digit code to reset your password.</p>
        <form method="post">
          <label for="email">Email:</label>
          <div class="field">
            <input type="email" id="email" name="email" placeholder="name@school.edu" required>
          </div>
          <button type="submit" class="btn btn-fill">Send email</button>
        </form>
        <a href="#" class="back"><svg class="i">
            <use href="#back" />
          </svg> Back to log in</a>
      </div>
    </main>
  </div>

  <script>
    // stops the form from reloading the page
    document.querySelector("form").onsubmit = function(e) {
      e.preventDefault();
    };
  </script>

</body>

</html>