<?php
$pageTitle   = 'Dashboard';
$pageSub     = 'What needs your attention across assets, update reports and defect tickets.';
$active      = 'dashboard';
$pageScripts = ['dashboard.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="grid grid-main dash">
  <!-- left column: KPIs, two charts side by side, activity log -->
  <div class="stack">
    <section class="kpi-row" id="kpiRow"></section>

    <div class="grid grid-2">
      <section class="card">
        <div class="card-h"><div><h2>Assets by building</h2><p>Units per building.</p></div></div>
        <div class="card-b"><div class="bars" id="bldgBars"></div></div>
      </section>

      <section class="card">
        <div class="card-h">
          <div><h2>Assets by category</h2><p>Units in each category.</p></div>
          <a class="link" href="custodian_assets.php">View <svg class="i i-sm"><use href="#i-arrow-right"/></svg></a>
        </div>
        <div class="card-b"><div class="bars" id="catBars"></div></div>
      </section>
    </div>

    <section class="card">
      <div class="card-h"><div><h2>Activity log</h2><p>A quick overview of recorded actions.</p></div></div>
      <div class="card-b flush">
        <div class="table-wrap">
          <table class="table compact" id="activityTable">
            <thead><tr><th>When</th><th>Event</th><th>User</th><th>Details</th></tr></thead>
            <tbody></tbody>
          </table>
        </div>
      </div>
    </section>
  </div>

  <!-- right rail -->
  <aside class="stack">
    <section class="card">
      <div class="card-h"><div><h2>Needs your attention</h2><p>Pending items across your modules.</p></div></div>
      <div class="card-b"><div class="attn" id="attnList"></div></div>
    </section>

    <section class="card">
      <div class="card-h"><div><h2>AI recommendations</h2><p>Insights on assets that need action.</p></div></div>
      <div class="card-b">
        <div class="reco" id="recoList"></div>
        <div class="reco-foot">
          <svg class="i i-sm"><use href="#i-sparkles"/></svg>
          <span>AI-assisted. Double-check the details before acting; they may be incomplete.</span>
        </div>
      </div>
    </section>
  </aside>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
