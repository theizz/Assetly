/* add / edit asset page: fills selects, keeps a live summary, confirms before saving */
(function () {
  const A = window.Assetly,
    DB = window.DB;
  const form = A.qs("#assetForm");
  const editId = new URLSearchParams(location.search).get("edit");
  const editing = editId ? DB.assets.find((a) => a.id === editId) : null;

  /* populate selects */
  const opt = (sel, items) => {
    const el = A.qs(sel);
    items.forEach((i) =>
      el.insertAdjacentHTML("beforeend", `<option>${A.esc(i)}</option>`),
    );
  };
  opt("#f-category", DB.categories);
  opt("#f-fund", DB.fundSources);
  opt("#f-condition", DB.conditions);
  opt("#f-building", DB.buildings);
  opt("#f-fundcode", DB.fundCodes);

  /* edit mode */
  if (editing) {
    document.title = "Edit asset · Assetly";
    A.qs("h1").textContent = "Edit asset";
    A.qs("#crumbNow").textContent = "Edit " + editing.id;
    A.qs("#formHeading").textContent = `Edit ${editing.name}`;
    A.qs("#saveLabel").textContent = "Update asset";
    form.name.value = editing.name;
    form.category.value = editing.category;
    form.fundSource.value = editing.fundSource;
    form.condition.value = editing.condition;
    form.qty.value = editing.qty;
    form.dateAcquired.value = editing.dateAcquired;
    form.unitValue.value = editing.unitValue;
    form.building.value = editing.building;
    form.room.value = editing.room;
    form.fundCode.value = editing.fundCode || "";
    form.propertyNo.value = editing.propertyNo || "";
    form.description.value = editing.description || "";
  }

  /* coming from a delivery's Post button: ?from=DLV-..&item=0&name=..&category=..&qty=..
     name, category and quantity are filled in; the rest is entered here */
  const params = new URLSearchParams(location.search);
  const fromId = params.get("from");
  const fromDelivery = !editing && fromId ? DB.deliveries.find((d) => d.id === fromId) : null;
  const fromItem = fromDelivery ? Number(params.get("item")) : null;
  if (fromDelivery) {
    const nm = params.get("name") || "";
    const cat = params.get("category") || "";
    const qn = Math.max(1, Number(params.get("qty")) || 1);
    form.name.value = nm;
    if (DB.categories.includes(cat)) form.category.value = cat;
    form.qty.value = qn;
    A.qs("#deliveryNote").hidden = false;
    A.qs("#deliveryNoteText").innerHTML =
      `Posting from delivery <strong>${A.esc(fromDelivery.ref)}</strong> (${A.esc(fromDelivery.id)}). ` +
      `Name, category and quantity were filled in from the count — complete the remaining details, then save.`;
    A.qs("#crumbRoot").textContent = "Deliveries";
    A.qs("#crumbRoot").href = "custodian_deliveries.php?open=" + encodeURIComponent(fromDelivery.id);
    A.qs("#formHeading").textContent = "Post delivered item to inventory";
    A.qs("a.btn-secondary.btn-block").href =
      "custodian_deliveries.php?open=" + encodeURIComponent(fromDelivery.id);
    /* these come from the delivery too, so they save a step */
    if (fromDelivery.fundSource && DB.fundSources.includes(fromDelivery.fundSource)) form.fundSource.value = fromDelivery.fundSource;
    if (fromDelivery.fundCode && DB.fundCodes.includes(fromDelivery.fundCode)) form.fundCode.value = fromDelivery.fundCode;
    form.dateAcquired.value = fromDelivery.dateDelivered;
    const it = fromDelivery.items[fromItem];
    if (it && it.unitValue) form.unitValue.value = it.unitValue;
  }

  /* live summary */
  function refresh() {
    const d = Object.fromEntries(new FormData(form));
    const qty = Math.max(1, Number(d.qty) || 1);
    const val = Number(d.unitValue) || 0;
    const rowsOut = [
      ["Asset name", d.name || "—"],
      ["Category", d.category || "—"],
      ["Condition", d.condition ? A.conditionChip(d.condition) : "—"],
      ["Quantity", A.int(qty)],
      ["Unit value", val ? A.money(val) : "—"],
      ["Total value", val ? A.money(val * qty) : "—"],
      ["Fund source", d.fundSource || "—"],
      [
        "Location",
        d.building ? `${d.building}${d.room ? " · " + d.room : ""}` : "—",
      ],
      ["Date acquired", d.dateAcquired ? A.date(d.dateAcquired) : "—"],
    ];
    A.qs("#summary").innerHTML = rowsOut
      .map(([k, v]) => `<div><span>${k}</span><span>${v}</span></div>`)
      .join("");

    const wrap = A.qs("#unitPreviewWrap");
    if (qty > 1) {
      wrap.hidden = false;
      const base = editing ? Number(editing.id.replace(/\D/g, "")) : 0;
      const ids = Array.from({ length: Math.min(qty, 8) }, (_, i) =>
        editing
          ? editing.units[i] || `AST-${String(base + i).padStart(5, "0")}`
          : `AST-·····`,
      );
      A.qs("#unitPreview").innerHTML =
        ids.map((u) => `<span class="tag mono">${u}</span>`).join("") +
        (qty > 8 ? `<span class="tag">+${qty - 8} more</span>` : "");
    } else wrap.hidden = true;
  }
  form.addEventListener("input", refresh);
  refresh();

  /* submit → confirm → toast → back to list */
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!A.validate(form)) {
      A.toast("Please complete the required fields.", "bad");
      A.qs(".field.is-invalid .input, .field.is-invalid .select")?.focus();
      return;
    }
    const qty = Math.max(1, Number(form.qty.value) || 1);
    const ok = await A.confirm({
      title: editing ? "Update this asset?" : "Save this asset?",
      text: editing
        ? "Your changes will be saved and logged in the activity history."
        : `This will create ${qty} asset record${qty > 1 ? "s" : ""} and log the action.`,
      okLabel: editing ? "Confirm and update" : "Confirm and save",
      tone: "good",
    });
    if (!ok) return;
    A.toast(
      editing ? "Asset updated." : `${qty} asset${qty > 1 ? "s" : ""} saved.`,
    );
    if (fromDelivery) {
      /* remember this line as posted so the delivery shows it as done */
      try {
        const key = "assetly.postedItems";
        const list = new Set(JSON.parse(sessionStorage.getItem(key) || "[]"));
        list.add(fromDelivery.id + ":" + fromItem);
        sessionStorage.setItem(key, JSON.stringify([...list]));
      } catch (err) {}
      setTimeout(() => (location.href = "custodian_deliveries.php?open=" + encodeURIComponent(fromDelivery.id)), 700);
      return;
    }
    setTimeout(() => (location.href = "custodian_assets.php"), 700);
  });
})();
