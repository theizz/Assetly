<?php
$pageTitle   = 'Deliveries';
$pageSub     = 'Log an incoming delivery, count what actually arrived, then post it into the inventory.';
$active      = 'deliveries';
$pageScripts = ['deliveries.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <div class="kpi-row" style="flex:1" id="dlvKpis"></div>
  <div class="actions">
    <button class="btn btn-primary" id="logBtn" type="button"><svg class="i"><use href="#i-plus"/></svg> Log delivery</button>
  </div>
</div>

<!-- workflow explainer -->
<section class="card">
  <div class="card-b" style="padding-bottom:16px">
    <div class="steps" style="max-width:640px">
      <div class="step is-done"><span class="n"><svg class="i i-sm"><use href="#i-check"/></svg></span> Log delivery</div>
      <span class="step-line"></span>
      <div class="step is-done"><span class="n"><svg class="i i-sm"><use href="#i-check"/></svg></span> Count actual</div>
      <span class="step-line"></span>
      <div class="step is-done"><span class="n"><svg class="i i-sm"><use href="#i-check"/></svg></span> Post to inventory</div>
    </div>
    <p class="muted" style="margin-top:10px;font-size:13px;max-width:720px">Log records the delivery note and expected quantities. Count captures what physically arrived — including shortages and damage — so delivered and actual figures always match the paperwork. Each item has its own Post button that opens the Add asset form with the name, category and quantity already filled in.</p>
  </div>
</section>

<section class="card">
  <div class="card-b" style="padding-bottom:0">
    <div class="toolbar">
      <div class="input-icon grow">
        <svg class="i"><use href="#i-search"/></svg>
        <input class="input" id="q" type="search" placeholder="Search by document no., source or supplier">
      </div>
      <select class="select" id="fStatus"><option value="">All stages</option><option>Logged</option><option>Counted</option><option>Posted</option></select>
      <select class="select" id="fSource"><option value="">All sources</option></select>
    </div>
  </div>
  <div class="card-b flush" style="margin-top:12px">
    <div class="table-wrap">
      <table class="table" id="dlvTable">
        <thead><tr>
          <th>Document no.</th><th>Source</th><th>Date delivered</th>
          <th class="text-right">Delivered</th><th class="text-right">Actual</th><th class="text-right">Variance</th>
          <th>Stage</th><th class="actions">Actions</th>
        </tr></thead>
        <tbody id="dlvBody"></tbody>
      </table>
    </div>
    <div class="table-foot" id="dlvFoot"></div>
  </div>
</section>

<!-- delivery drawer: log / count / post all happen here, driven by stage -->
<div class="drawer-backdrop" id="dlvDrawer" hidden>
  <div class="drawer wide" role="dialog" aria-modal="true" aria-labelledby="dlvTitle">
    <div class="drawer-h">
      <div><h2 id="dlvTitle">Delivery</h2><div class="sub" id="dlvSub"></div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="drawer-b" id="dlvBodyDrawer"></div>
    <div class="drawer-f" id="dlvFootDrawer"></div>
  </div>
</div>

<!-- log new delivery modal -->
<div class="modal-backdrop" id="logModal" hidden>
  <div class="modal modal-xl" role="dialog" aria-modal="true" aria-labelledby="logTitle">
    <div class="modal-h">
      <div><h2 id="logTitle">Log a new delivery</h2><div class="sub">Record the delivery note and the items expected. You'll count the actual arrivals next.</div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <form class="modal-b" id="logForm" novalidate>
      <div class="form-grid cols-3">
        <div class="field">
          <label class="req" for="l-source">Delivery source</label>
          <select class="select" id="l-source" name="source" data-required><option value="">Choose source</option></select>
          <span class="error">Choose a source.</span>
        </div>
        <div class="field">
          <label class="req" for="l-ref"><span id="l-refLabel">Document no.</span></label>
          <input class="input" id="l-ref" name="ref" data-required placeholder="e.g. IAR-2026-0142">
          <span class="error">Enter the document number.</span>
        </div>
        <div class="field">
          <label class="req" for="l-date">Date delivered</label>
          <input class="input" id="l-date" name="dateDelivered" type="date" data-required>
          <span class="error">Enter the delivery date.</span>
        </div>
        <div class="field span-2">
          <label for="l-supplier">Supplier / sender</label>
          <input class="input" id="l-supplier" name="supplier" placeholder="e.g. SDO Quezon City">
        </div>
        <div class="field">
          <label class="req" for="l-fund">Fund source</label>
          <select class="select" id="l-fund" name="fundSource" data-required><option value="">Choose fund source</option></select>
          <span class="error">Choose a fund source.</span>
        </div>
      </div>

      <div class="note warn" id="donationNote" hidden>
        <svg class="i"><use href="#i-alert"/></svg>
        <div><strong>Donation</strong> — a signed Deed of Donation must be filed before these items count as school property. You can log and count now; the deed can be marked received before posting.</div>
      </div>

      <div>
        <div class="section-title">Items expected</div>
        <div class="line-items" style="margin-top:10px">
          <table class="table">
            <thead><tr><th>Item name</th><th class="w-cat">Category</th><th class="w-qty text-right">Expected qty</th><th class="w-val text-right">Unit value</th><th class="w-act"></th></tr></thead>
            <tbody id="logItems"></tbody>
          </table>
          <div class="line-items-foot">
            <button class="btn btn-sm btn-ghost" id="addItem" type="button"><svg class="i"><use href="#i-plus"/></svg> Add item</button>
            <span class="muted">Total value: <strong id="logTotal">₱0.00</strong></span>
          </div>
        </div>
      </div>

      <div class="field">
        <label for="l-notes">Notes <span class="muted">(optional)</span></label>
        <textarea class="textarea" id="l-notes" name="notes" placeholder="Anything the receiving staff should know"></textarea>
      </div>
    </form>
    <div class="modal-f">
      <span class="left" id="logHint"></span>
      <button class="btn btn-secondary" data-close type="button">Cancel</button>
      <button class="btn btn-primary" id="logSave" type="submit" form="logForm"><svg class="i"><use href="#i-truck"/></svg> Log delivery</button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
