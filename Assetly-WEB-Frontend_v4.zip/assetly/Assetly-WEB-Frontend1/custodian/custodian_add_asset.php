<?php
$pageTitle   = 'Add asset';
$active      = 'assets';
$pageScripts = ['add_asset.js'];
// edit mode is signalled by ?edit=<id>; the JS reads it and prefills from the mock DB.
include __DIR__ . '/includes/header.php';
?>

<div class="crumbs">
  <a href="custodian_assets.php" id="crumbRoot">Assets</a>
  <svg class="i i-sm"><use href="#i-chevron-right"/></svg>
  <strong id="crumbNow">Add asset</strong>
</div>

<div class="note info prefill-note" id="deliveryNote" hidden>
  <svg class="i"><use href="#i-truck"/></svg>
  <div id="deliveryNoteText"></div>
</div>

<form class="add-layout" id="assetForm" novalidate>
  <section class="card">
    <div class="card-h"><div><h2 id="formHeading">Enter the asset's information</h2><p>Fields marked * are required.</p></div></div>
    <div class="card-b">
      <div class="form-grid">
        <div class="field span-2">
          <label class="req" for="f-name">Asset name</label>
          <input class="input" id="f-name" name="name" data-required placeholder="e.g. Brother DCP-T720DW Printer">
          <span class="error">Asset name is required.</span>
        </div>

        <div class="field">
          <label class="req" for="f-category">Category</label>
          <select class="select" id="f-category" name="category" data-required><option value="">Choose category</option></select>
          <span class="error">Choose a category.</span>
        </div>
        <div class="field">
          <label class="req" for="f-fund">Fund source</label>
          <select class="select" id="f-fund" name="fundSource" data-required><option value="">Choose fund source</option></select>
          <span class="error">Choose a fund source.</span>
        </div>

        <div class="field">
          <label class="req" for="f-condition">Condition</label>
          <select class="select" id="f-condition" name="condition" data-required><option value="">Choose condition</option></select>
          <span class="error">Choose a condition.</span>
        </div>
        <div class="field">
          <label class="req" for="f-qty">Quantity</label>
          <input class="input num" id="f-qty" name="qty" type="number" min="1" value="1" data-required>
          <span class="hint">More than one unit? Each gets its own ID automatically.</span>
        </div>

        <div class="field">
          <label for="f-date">Date acquired</label>
          <input class="input" id="f-date" name="dateAcquired" type="date">
        </div>
        <div class="field">
          <label for="f-value">Unit value (₱)</label>
          <div class="input-prefix"><span>₱</span><input class="input num" id="f-value" name="unitValue" type="number" min="0" step="0.01" placeholder="0.00"></div>
        </div>

        <div class="field">
          <label class="req" for="f-building">Building</label>
          <select class="select" id="f-building" name="building" data-required><option value="">Choose building</option></select>
          <span class="error">Choose a building.</span>
        </div>
        <div class="field">
          <label for="f-room">Room</label>
          <input class="input" id="f-room" name="room" placeholder="e.g. 204 or Stockroom A">
        </div>

        <div class="field">
          <label for="f-fundcode">Fund code <span class="muted">(DepEd, optional)</span></label>
          <select class="select" id="f-fundcode" name="fundCode"><option value="">None</option></select>
        </div>
        <div class="field">
          <label for="f-propno">Property number <span class="muted">(optional)</span></label>
          <input class="input" id="f-propno" name="propertyNo" placeholder="e.g. 2024-05-0231">
        </div>

        <div class="field span-2">
          <label for="f-desc">Description <span class="muted">(optional)</span></label>
          <textarea class="textarea" id="f-desc" name="description" placeholder="Brief summary, serial numbers, or condition notes"></textarea>
        </div>
      </div>
    </div>
  </section>

  <!-- live summary rail -->
  <aside>
    <section class="card sticky">
      <div class="card-h"><div><h2>Asset summary</h2></div></div>
      <div class="card-b">
        <div class="summary-list" id="summary"></div>

        <div id="unitPreviewWrap" hidden style="margin-top:14px">
          <div class="section-title">Unit IDs to be created</div>
          <div class="unit-preview" id="unitPreview" style="margin-top:8px"></div>
        </div>

        <div class="note info" style="margin-top:14px">
          <svg class="i"><use href="#i-info"/></svg>
          <div>
            <strong>Before you save</strong>
            <ul>
              <li>You can edit any detail after saving.</li>
              <li>Quantity above 1 creates one ID per unit — open any from the Assets table.</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="card-f" style="flex-direction:column;gap:8px;align-items:stretch;border-top:1px solid var(--line)">
        <button class="btn btn-primary btn-block" id="saveBtn" type="submit"><svg class="i"><use href="#i-check"/></svg> <span id="saveLabel">Save asset</span></button>
        <a class="btn btn-secondary btn-block" href="custodian_assets.php">Cancel</a>
      </div>
    </section>
  </aside>
</form>

<?php include __DIR__ . '/includes/footer.php'; ?>
