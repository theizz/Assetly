# Assetly — Web Frontend

Frontend only (HTML / CSS / JS served as `.php`). No backend, database, or sessions yet.
The three parts below are **independent** and **not linked to each other yet**.

```
landing/     Public pages: Login, Signup, VerifyEmail, EmailVerified,
             ForgotPassword, ForgotVerify, NewPassword, PasswordChanged
             (stylesheet.css, fonts/, images/)
custodian/   Property Custodian interface: Dashboard, Assets (with the
             Deliveries and Physical count pages under the Assets
             sidebar dropdown), Add asset,
             Update reports, Defect tickets, Trash
             (includes/, assets/css, assets/js, assets/img)
teacher/     Teacher interface: Home, My assets, Physical count,
             Report update, Report defect, My reports
             (includes/, assets/css, assets/js, assets/img)
```

## Design system (shared by all three, based on the Teacher interface)

| | Value |
|---|---|
| UI / body font | **Poppins** (Google Fonts) |
| Page titles / big headings | **Neue Montreal** (files in each part's `fonts/` folder; licensed from Pangram Pangram) |
| Canvas / card | `#F1F3FC` background, `#F8F9FE` cards, 16px radius, soft shadow, no borders |
| Brand blue / navy | `#4361E8` buttons, `#4D7CF3` active nav pill, `#2B3A8F` page titles |
| Wordmark gradient | `#4A4FE2 → #2F7BDD → #0FB0D6` (the "Assetly" name everywhere) |
| Sidebar | 212px, `#F8F9FF`, blue nav text, solid blue pill when active, red count badges, user block + Log out at the bottom |
| Status chips | Pending = yellow, Approved/Resolved/Verified = green, Rejected = red, In progress/Submitted = blue |

The values are written as CSS variables at the top of `teacher/assets/css/teacher.css` and
`custodian/assets/css/custodian.css` (same names and values), and noted at the top of
`landing/stylesheet.css`. Change them in both app stylesheets to keep them in step.

## Run locally

```bash
php -S 127.0.0.1:8000
```

- Landing: http://127.0.0.1:8000/landing/Login.php
- Custodian: http://127.0.0.1:8000/custodian/custodian_dashboard.php
- Teacher: http://127.0.0.1:8000/teacher/teacher_home.php

## Not connected yet (to do when wiring the backend)

- Login submits nowhere real (`action="Login.html"`); it does not open either dashboard.
- Both "Log out" links point to their own placeholder `logout.php`, not back to `landing/Login.php`.
- The landing pages' "Back to log in", "Forgot password" and "Sign up" links are mostly `#` placeholders.
- Teacher reports and physical counts are not sent to the custodian side (mock data on each side).
  The record shapes already match, so the same tables can serve both
  (teacher Physical count → custodian Assets → Physical count).
- Each part has its own stylesheet and copies of the Assetly logo; they share no files.

See `custodian/README.md` and `teacher/README.md` for data shapes and wiring notes.
