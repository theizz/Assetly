/* My reports: two tabs (update reports / maintenance tickets), status filter, detail panel. */
(function () {
  const T = window.T, D = window.TDB, { qs, qsa, esc, date, dateTime, chip } = T;
  const STATUSES = { updates: ['Pending', 'Approved', 'Rejected'], tickets: ['Pending', 'Acknowledged', 'In progress', 'Resolved', 'Rejected'] };
  const sorted = (arr) => [...arr].sort((a, b) => b.submittedAt.localeCompare(a.submittedAt));
  const data = { updates: sorted(D.reports), tickets: sorted(D.tickets) };
  let tab = T.params.get('tab') === 'tickets' ? 'tickets' : 'updates';
  let selected = T.params.get('id');

  qs('#cUpdates').textContent = data.updates.length; qs('#cTickets').textContent = data.tickets.length;
  const title = (r) => tab === 'updates' ? `${r.type} · ${r.assetName}` : `${r.defectType} · ${r.assetName}`;

  function setTab(t) {
    tab = t;
    qsa('.tab').forEach((b) => { const on = b.dataset.tab === t; b.classList.toggle('is-active', on); b.setAttribute('aria-selected', on); });
    qs('#fStatus').innerHTML = '<option value="">All statuses</option>' + STATUSES[t].map((s) => `<option>${s}</option>`).join('');
    renderList();
  }

  function renderList() {
    const f = qs('#fStatus').value;
    const rows = data[tab].filter((r) => !f || r.status === f);
    if (selected && !rows.some((r) => r.id === selected)) selected = null;
    qs('#list').innerHTML = rows.map((r) => `
      <button class="ritem${r.id === selected ? ' is-selected' : ''}" type="button" role="option" aria-selected="${r.id === selected}" data-id="${r.id}">
        <span><strong>${esc(title(r))}</strong><small>${date(r.submittedAt)} · ${r.id}</small></span>
        ${chip(r.status)}
      </button>`).join('') || `<div class="empty"><strong>No reports</strong>Nothing matches this status.</div>`;
    renderDetail();
  }

  function renderDetail() {
    const r = data[tab].find((x) => x.id === selected);
    if (!r) {
      qs('#detail').innerHTML = `<div class="detail-empty"><span class="ic"><svg class="i i-lg"><use href="#i-file"/></svg></span><strong>Select a report</strong><span>Choose a report from the list to see its details, status,<br>and any reason from the Property Custodian.</span></div>`;
      return;
    }
    const rows = tab === 'updates' ? [
      ['Report no.', r.id], ['Update type', r.type], ['Category', r.category], ['Quantity', r.qty],
      ['Building', r.building.replace(' Building', '')], ['Room', r.room],
      r.type === 'Relocation' ? ['Move to', `${r.newBuilding.replace(' Building', '')} · ${r.newRoom}`] : null,
      r.type === 'Add' ? ['Asset source', r.source] : null,
      r.photo ? ['Photo', r.photo] : null
    ] : [
      ['Ticket no.', r.id], ['Category', r.category], ['Quantity', r.qty],
      ['Status', r.outcome || r.status], ['Building', r.building.replace(' Building', '')], ['Room', r.room],
      ['Person responsible', r.personResponsible || '-----'], ['Role', r.personRole],
      r.photo ? ['Photo', r.photo] : null
    ];
    const tone = r.status === 'Rejected' ? 'bad' : (['Approved', 'Resolved'].includes(r.status) ? 'good' : 'info');
    const reason = r.reason ? `<div class="reason ${tone}"><b>${r.status === 'Rejected' ? 'Reason' : 'Custodian note'}:</b> ${esc(r.reason)}</div>`
      : (r.status === 'Pending' ? `<div class="reason info"><b>Waiting for review.</b> The Property Custodian has been notified.</div>` : '');
    const hist = r.history || [];
    const last = hist.length - 1;
    const steps = hist.map((h, i) => {
      const cls = h.status === 'Rejected' ? 'bad' : (i === last && !['Resolved', 'Approved'].includes(h.status) ? 'now' : 'done');
      return `<li class="${cls}"><strong>${esc(h.status)}</strong><small>${dateTime(h.at)}${h.note ? ' · ' + esc(h.note) : ''}</small></li>`;
    }).join('');
    qs('#detail').innerHTML = `
      <div class="card detail" aria-live="polite">
        <div class="detail-h"><h2>${esc(title(r))}</h2>${chip(r.status)}</div>
        <dl class="kv">${rows.filter(Boolean).map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>
        ${r.description ? `<p class="desc-box">${esc(r.description)}</p>` : ''}
        ${reason}
        <ul class="timeline">${steps}</ul>
      </div>`;
  }

  qsa('.tab').forEach((b) => b.addEventListener('click', () => { if (b.dataset.tab !== tab) { selected = null; setTab(b.dataset.tab); } }));
  qs('#fStatus').addEventListener('change', renderList);
  qs('#list').addEventListener('click', (e) => {
    const b = e.target.closest('.ritem'); if (!b) return;
    selected = b.dataset.id; renderList();
    if (window.innerWidth <= 1180) qs('#detail').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  setTab(tab);
})();
