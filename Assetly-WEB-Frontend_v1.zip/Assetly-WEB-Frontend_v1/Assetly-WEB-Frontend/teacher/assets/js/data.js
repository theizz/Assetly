/* =========================================================================
   Assetly · Mock data for the Teacher interface.
   Every page reads from window.TDB. Replace with fetch() calls to your PHP
   endpoints later. Shapes mirror the custodian side (custodian/assets/js/data.js)
   so update reports and defect tickets land in the same records.
   ========================================================================= */
window.TDB = (function () {

  const me = { id: 'T-0112', name: 'Jose Mari Chan', initials: 'JC', role: 'Teacher', department: 'Science', advisory: 'Grade 9 - Sampaguita' };

  const categories = [
    'Furniture & Fixtures', 'Electronics & Appliances', 'Computer Lab Equipment', 'Science Lab Equipment',
    'TVL & Caregiving Equipment', 'SPA & Arts Equipment', 'Sports Equipment', 'Maintenance & Facility Tools', 'Books & Learning Materials'
  ];
  const buildings = ['Vargas Building', 'Castelo Building', 'Bautista Building', 'TVL Building', 'Library', 'Admin Building', 'Storage Room'];
  const conditions = ['Operational', 'Under maintenance', 'Damaged', 'Missing', 'For disposal'];
  const updateTypes = ['Add', 'Relocation', 'Delete', 'Other'];
  const assetSources = ['Division Office', 'DepEd Central Office', 'LGU / School Board (SEF)', 'Purchased (MOOE)', 'Donation', 'Other'];
  const responsibleRoles = ['Student', 'Teacher', 'Non-teaching staff', 'Visitor', 'Unknown', 'Wear and tear (no one)'];
  const defectTypes = ['Broken', 'Not working', 'Overheating', 'Missing parts', 'Leaking', 'Electrical problem', 'Cleaning / maintenance', 'Other'];

  /* Rooms this teacher is accountable for (assigned by the custodian). */
  const rooms = [
    { building: 'Castelo Building', room: '204', role: 'Adviser - Grade 9 Sampaguita' },
    { building: 'Castelo Building', room: '301', role: 'Science subject room' }
  ];

  /* Assigned asset shape: id, name, category, qty, building, room, condition, propertyNo, assignedAt */
  const assets = [
    { id: 'AST-00048', name: 'Projector (Epson EB-E01)',   category: 'Electronics & Appliances', qty: 1,  building: 'Castelo Building', room: '301', condition: 'Under maintenance', propertyNo: '2022-05-0410', assignedAt: '2022-11-04' },
    { id: 'AST-00301', name: 'Armchair, student',          category: 'Furniture & Fixtures',     qty: 45, building: 'Castelo Building', room: '204', condition: 'Operational',       propertyNo: '',             assignedAt: '2025-06-02' },
    { id: 'AST-00346', name: "Teacher's Table with drawers", category: 'Furniture & Fixtures',   qty: 1,  building: 'Castelo Building', room: '204', condition: 'Operational',       propertyNo: '',             assignedAt: '2025-06-02' },
    { id: 'AST-00347', name: 'Whiteboard 4x8 ft',          category: 'Furniture & Fixtures',     qty: 1,  building: 'Castelo Building', room: '204', condition: 'Operational',       propertyNo: '',             assignedAt: '2025-06-02' },
    { id: 'AST-00348', name: 'Electric Fan, wall-mounted', category: 'Electronics & Appliances', qty: 4,  building: 'Castelo Building', room: '204', condition: 'Operational',       propertyNo: '',             assignedAt: '2025-06-02' },
    { id: 'AST-00352', name: 'Smart TV 50"',               category: 'Electronics & Appliances', qty: 1,  building: 'Castelo Building', room: '204', condition: 'Operational',       propertyNo: '2025-05-0117', assignedAt: '2025-08-20' },
    { id: 'AST-00360', name: 'Compound Microscope',        category: 'Science Lab Equipment',    qty: 6,  building: 'Castelo Building', room: '301', condition: 'Operational',       propertyNo: '2021-05-0388', assignedAt: '2024-06-10' },
    { id: 'AST-00366', name: 'Science Activity Kit (Grade 9)', category: 'Science Lab Equipment', qty: 20, building: 'Castelo Building', room: '301', condition: 'Operational',     propertyNo: '',             assignedAt: '2025-09-15' },
    { id: 'AST-00386', name: 'Lab Stool, steel',           category: 'Furniture & Fixtures',     qty: 24, building: 'Castelo Building', room: '301', condition: 'Operational',       propertyNo: '',             assignedAt: '2024-06-10' },
    { id: 'AST-00410', name: 'Fire Extinguisher 10 lbs',   category: 'Maintenance & Facility Tools', qty: 1, building: 'Castelo Building', room: '301', condition: 'Operational',   propertyNo: '',             assignedAt: '2025-07-08' },
    { id: 'AST-00411', name: 'CPU (Desktop unit)',         category: 'Computer Lab Equipment',   qty: 1,  building: 'Castelo Building', room: '301', condition: 'For disposal',      propertyNo: '2017-05-0091', assignedAt: '2017-08-01' }
  ];

  /* Update report shape (same as custodian `reports`) + history[]:
     id, type 'Add'|'Relocation'|'Delete'|'Other', assetName, category, qty, building, room,
     newBuilding, newRoom (relocation), source (add), description, photo,
     submittedAt, status 'Pending'|'Approved'|'Rejected', reason, history[{status, at, note}] */
  const reports = [
    { id: 'UR-0241', type: 'Relocation', assetName: 'Projector (Epson EB-E01)', category: 'Electronics & Appliances', qty: 1, building: 'Castelo Building', room: '301', newBuilding: 'Castelo Building', newRoom: '204', description: 'Room 301 is being repainted this week; moving the projector to 204 for the Grade 9 classes.', photo: '', submittedAt: '2026-11-12T08:40:00', status: 'Pending',
      history: [ { status: 'Submitted', at: '2026-11-12T08:40:00' } ] },
    { id: 'UR-0229', type: 'Relocation', assetName: 'Armchair, student', category: 'Furniture & Fixtures', qty: 5, building: 'Castelo Building', room: '204', newBuilding: 'Castelo Building', newRoom: '205', description: 'Lent 5 armchairs to Room 205 for the quarterly exam.', photo: '', submittedAt: '2026-10-21T09:00:00', status: 'Rejected', reason: 'Temporary transfers for exams do not need a relocation. Please return the chairs to 204 after the exam week.',
      history: [ { status: 'Submitted', at: '2026-10-21T09:00:00' }, { status: 'Reviewed by Property Custodian', at: '2026-10-22T09:00:00' }, { status: 'Rejected', at: '2026-10-22T09:05:00' } ] },
    { id: 'UR-0226', type: 'Add', assetName: 'Science Activity Kit (Grade 9)', category: 'Science Lab Equipment', qty: 20, building: 'Castelo Building', room: '301', source: 'Division Office', description: 'Kits delivered by the Division Office and handed to me for the Grade 9 science classes.', photo: 'science-kits.jpg', submittedAt: '2026-09-16T10:20:00', status: 'Approved', reason: 'Recorded under DLV-2026-008. Property numbers will follow.',
      history: [ { status: 'Submitted', at: '2026-09-16T10:20:00' }, { status: 'Reviewed by Property Custodian', at: '2026-09-17T08:30:00' }, { status: 'Approved', at: '2026-09-17T08:35:00' } ] },
    { id: 'UR-0219', type: 'Other', assetName: 'Electric Fan, wall-mounted', category: 'Electronics & Appliances', qty: 4, building: 'Castelo Building', room: '204', description: 'Records show 3 fans but there are 4 mounted in the room.', photo: '', submittedAt: '2026-08-04T13:10:00', status: 'Approved', reason: 'Quantity corrected to 4.',
      history: [ { status: 'Submitted', at: '2026-08-04T13:10:00' }, { status: 'Reviewed by Property Custodian', at: '2026-08-05T09:00:00' }, { status: 'Approved', at: '2026-08-05T09:02:00' } ] }
  ];

  /* Defect ticket shape (same as custodian `tickets`):
     id, assetId, assetName, category, qty, building, room, defectType, description,
     personResponsible, personRole, photo, submittedAt,
     status 'Pending'|'Acknowledged'|'In progress'|'Resolved'|'Rejected', outcome, reason, history[] */
  const tickets = [
    { id: 'DT-0218', assetId: 'AST-00048', assetName: 'Projector (Epson EB-E01)', category: 'Electronics & Appliances', qty: 1, building: 'Castelo Building', room: '301', defectType: 'Overheating', description: 'Shuts off after about 20 minutes of use. Fan is very loud.', personResponsible: '', personRole: 'Wear and tear (no one)', photo: 'projector-301.jpg', submittedAt: '2026-11-08T16:05:00', status: 'In progress',
      history: [ { status: 'Submitted', at: '2026-11-08T16:05:00' }, { status: 'Acknowledged', at: '2026-11-09T08:15:00', note: 'Pulled out for checking.' }, { status: 'In progress', at: '2026-11-10T10:00:00', note: 'Sent to the supplier technician.' } ] },
    { id: 'DT-0212', assetId: 'AST-00301', assetName: 'Armchair, student', category: 'Furniture & Fixtures', qty: 1, building: 'Castelo Building', room: '204', defectType: 'Broken', description: 'Writing board snapped off.', personResponsible: '', personRole: 'Student', photo: '', submittedAt: '2026-10-21T07:45:00', status: 'Pending',
      history: [ { status: 'Submitted', at: '2026-10-21T07:45:00' } ] },
    { id: 'DT-0209', assetId: 'AST-00411', assetName: 'CPU (Desktop unit)', category: 'Computer Lab Equipment', qty: 1, building: 'Castelo Building', room: '301', defectType: 'Overheating', description: 'Turns off by itself; burning smell from the power supply.', personResponsible: '', personRole: 'Wear and tear (no one)', photo: 'cpu.jpg', submittedAt: '2026-10-22T09:00:00', status: 'Rejected', outcome: 'Disposed', reason: 'Unit is beyond economical repair. It has been tagged for disposal; a replacement request was forwarded.',
      history: [ { status: 'Submitted', at: '2026-10-22T09:00:00' }, { status: 'Reviewed by Property Custodian', at: '2026-10-23T09:00:00' }, { status: 'Rejected', at: '2026-10-23T09:00:00' } ] },
    { id: 'DT-0201', assetId: 'AST-00348', assetName: 'Electric Fan, wall-mounted', category: 'Electronics & Appliances', qty: 1, building: 'Castelo Building', room: '204', defectType: 'Cleaning / maintenance', description: 'Blades very dusty, wobbling at high speed.', personResponsible: '', personRole: 'Wear and tear (no one)', photo: '', submittedAt: '2026-10-02T11:30:00', status: 'Resolved', reason: 'Cleaned and tightened by the utility staff.',
      history: [ { status: 'Submitted', at: '2026-10-02T11:30:00' }, { status: 'Acknowledged', at: '2026-10-02T14:00:00' }, { status: 'In progress', at: '2026-10-03T08:00:00' }, { status: 'Resolved', at: '2026-10-03T15:20:00' } ] }
  ];

  /* Physical count. The custodian opens a period (semi-annual: June and December);
     each teacher counts the assets assigned to their rooms and submits.
     Count line shape: { assetId, onRecord, found (number|null), condition, remarks }
     Submission status: 'Not started' | 'Draft' | 'Submitted' | 'Verified' | 'Returned' */
  const countPeriod = { id: 'PC-2026-12', period: 'December 2026', opensAt: '2026-11-03', dueAt: '2026-12-15', openedBy: 'Zaida M. Padullo',
    instructions: 'Count every item physically in each room. Enter what you actually see, not what is on record. Note anything damaged, missing, or not on the list.' };

  const pastCounts = [
    { id: 'PC-2026-06', period: 'June 2026',     submittedAt: '2026-06-26T15:10:00', status: 'Verified', onRecord: 105, found: 103, missing: 2, verifiedBy: 'Zaida M. Padullo', note: '2 armchairs missing from 204; written off after investigation.' },
    { id: 'PC-2025-12', period: 'December 2025', submittedAt: '2025-12-12T10:40:00', status: 'Verified', onRecord: 98,  found: 98,  missing: 0, verifiedBy: 'Zaida M. Padullo', note: 'Complete.' }
  ];

  return { me, categories, buildings, conditions, updateTypes, assetSources, responsibleRoles, defectTypes, rooms, assets, reports, tickets, countPeriod, pastCounts };
})();
