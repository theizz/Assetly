/* Report update: Add / Relocation / Delete / Other, with a review step. */
(function () {
  const T = window.T, D = window.TDB, { qs, esc } = T;
  const form = qs('#updateForm');
  const fill = (sel, items) => items.forEach((v) => qs(sel).insertAdjacentHTML('beforeend', `<option>${esc(v)}</option>`));
  fill('#u-category', D.categories); fill('#u-building', D.buildings); fill('#u-newBuilding', D.buildings);
  fill('#u-type', D.updateTypes); fill('#u-source', D.assetSources);
  qs('#myAssetList').innerHTML = D.assets.map((a) => `<option value="${esc(a.name)}">${esc(a.id)} · ${esc(a.building)} ${esc(a.room)}</option>`).join('');

  const HINTS = {
    Add: 'Add: a new item arrived in your room. Say who delivered it and attach a photo if you can.',
    Relocation: 'Relocation: the item moved to another room. Give the reason for the move.',
    Delete: 'Delete: the item should be removed from your list (returned, lost, beyond repair). Explain why.',
    Other: 'Other: anything else, such as a wrong quantity or name on record.'
  };
  function syncType() {
    const t = qs('#u-type').value;
    qs('#sourceField').hidden = t !== 'Add';
    qs('#newBuildingField').hidden = qs('#newRoomField').hidden = t !== 'Relocation';
    qs('#typeHint').textContent = HINTS[t] || '';
  }
  qs('#u-type').addEventListener('change', syncType);

  /* Picking one of my assets fills category / location. */
  function prefill(a) {
    qs('#u-name').value = a.name; qs('#u-category').value = a.category;
    qs('#u-building').value = a.building; qs('#u-room').value = a.room;
    if (!qs('#u-qty').value) qs('#u-qty').value = a.qty;
  }
  qs('#u-name').addEventListener('change', () => { const a = D.assets.find((x) => x.name === qs('#u-name').value); if (a) prefill(a); });
  const fromQ = T.assetFromQuery();
  if (fromQ) { prefill(fromQ); const t = T.params.get('type'); if (t && D.updateTypes.includes(t)) qs('#u-type').value = t; }
  syncType();

  const photo = T.dropzone(qs('#dz'));
  let pending = null;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!T.validate(form)) { T.toast('Please complete the highlighted fields.', 'bad'); return; }
    const t = qs('#u-type').value;
    pending = {
      type: t, assetName: qs('#u-name').value.trim(), category: qs('#u-category').value, qty: Number(qs('#u-qty').value),
      building: qs('#u-building').value, room: qs('#u-room').value.trim(),
      source: t === 'Add' ? qs('#u-source').value : '', newBuilding: t === 'Relocation' ? qs('#u-newBuilding').value : '', newRoom: t === 'Relocation' ? qs('#u-newRoom').value.trim() : '',
      description: qs('#u-desc').value.trim()
    };
    if (t === 'Relocation' && pending.newBuilding === pending.building && pending.newRoom === pending.room) {
      qs('#newRoomField').classList.add('has-error'); T.toast('The new location is the same as the current one.', 'bad'); return;
    }
    qs('#reviewBody').innerHTML = T.reviewHTML([
      ['Asset name', pending.assetName], ['Category', pending.category],
      ['Building', pending.building.replace(' Building', '')], ['Room', pending.room],
      ['Quantity', pending.qty], ['Update type', pending.type],
      t === 'Add' ? ['Asset source', pending.source] : null,
      t === 'Relocation' ? ['Move to', `${pending.newBuilding.replace(' Building', '')} · Room ${pending.newRoom}`] : null,
      ['Description', pending.description, true]
    ], photo.get());
    T.open('reviewModal');
  });

  qs('#reviewCancel').addEventListener('click', () => { T.close('reviewModal'); });
  qs('#reviewConfirm').addEventListener('click', () => {
    // Backend: POST pending (+ photo) to your update-report endpoint here.
    T.close('reviewModal');
    T.toast(`Update report submitted (${pending.type}: ${pending.assetName}). Status: Pending.`);
    form.reset(); photo.reset(); syncType(); pending = null;
  });
})();
