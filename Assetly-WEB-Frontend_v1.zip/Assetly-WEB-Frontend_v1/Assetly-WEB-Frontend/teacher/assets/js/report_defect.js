/* Report defect: creates a maintenance ticket after a review step. */
(function () {
  const T = window.T, D = window.TDB, { qs, esc } = T;
  const form = qs('#defectForm');
  const fill = (sel, items) => items.forEach((v) => qs(sel).insertAdjacentHTML('beforeend', `<option>${esc(v)}</option>`));
  fill('#d-category', D.categories); fill('#d-building', D.buildings); fill('#d-role', D.responsibleRoles);
  qs('#myAssetList').innerHTML = D.assets.map((a) => `<option value="${esc(a.name)}">${esc(a.id)} · ${esc(a.building)} ${esc(a.room)}</option>`).join('');
  qs('#defectTypeList').innerHTML = D.defectTypes.map((t) => `<option value="${esc(t)}">`).join('');

  let assetId = null;
  function prefill(a) {
    assetId = a.id;
    qs('#d-name').value = a.name; qs('#d-category').value = a.category;
    qs('#d-building').value = a.building; qs('#d-room').value = a.room;
    if (!qs('#d-qty').value) qs('#d-qty').value = 1;
  }
  qs('#d-name').addEventListener('change', () => { const a = D.assets.find((x) => x.name === qs('#d-name').value); assetId = null; if (a) prefill(a); });
  const fromQ = T.assetFromQuery(); if (fromQ) prefill(fromQ);

  const photo = T.dropzone(qs('#dz'));
  let pending = null;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!T.validate(form)) { T.toast('Please complete the highlighted fields.', 'bad'); return; }
    pending = {
      assetId, assetName: qs('#d-name').value.trim(), category: qs('#d-category').value, qty: Number(qs('#d-qty').value),
      building: qs('#d-building').value, room: qs('#d-room').value.trim(), defectType: qs('#d-type').value.trim(),
      personResponsible: qs('#d-person').value.trim(), personRole: qs('#d-role').value, description: qs('#d-desc').value.trim()
    };
    qs('#reviewBody').innerHTML = T.reviewHTML([
      ['Asset name', pending.assetName], ['Category', pending.category],
      ['Building', pending.building.replace(' Building', '')], ['Room', pending.room],
      ['Quantity', pending.qty], ['Defect type', pending.defectType],
      ['Person Responsible', pending.personResponsible], ['Role of the person responsible', pending.personRole],
      ['Description', pending.description, true]
    ], photo.get());
    T.open('reviewModal');
  });

  qs('#reviewCancel').addEventListener('click', () => T.close('reviewModal'));
  qs('#reviewConfirm').addEventListener('click', () => {
    // Backend: POST pending (+ photo) to your defect-ticket endpoint here.
    T.close('reviewModal');
    T.toast(`Defect report submitted for ${pending.assetName}. You can track it in My reports.`);
    form.reset(); photo.reset(); assetId = null; pending = null;
  });
})();
