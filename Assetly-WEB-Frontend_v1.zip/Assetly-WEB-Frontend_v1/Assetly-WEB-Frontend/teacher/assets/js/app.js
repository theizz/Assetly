/* Assetly · Teacher interface shared helpers (window.T). */
window.T = (function () {
  const qs = (s, r = document) => r.querySelector(s);
  const qsa = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const date = (iso) => { if (!iso) return '—'; const d = new Date(iso.length === 10 ? iso + 'T00:00:00' : iso); return `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`; };
  const time = (iso) => { const d = new Date(iso); let h = d.getHours(); const m = String(d.getMinutes()).padStart(2, '0'); const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12; return `${h}:${m} ${ap}`; };
  const dateTime = (iso) => iso ? `${date(iso)}, ${time(iso)}` : '—';
  const int = (n) => Number(n || 0).toLocaleString('en-PH');
  /* "Today" for the demo, so countdowns are stable. Use new Date() in production. */
  const TODAY = new Date('2026-11-16T09:00:00');
  const daysUntil = (iso) => Math.ceil((new Date(iso + 'T23:59:59') - TODAY) / 86400000);

  const STATUS_TONE = { Pending: 'pending', Approved: 'good', Resolved: 'good', Verified: 'good', Rejected: 'bad', Returned: 'bad', Acknowledged: 'info', 'In progress': 'info', Submitted: 'info', Draft: 'warn', 'Not started': 'neutral' };
  const chip = (status) => `<span class="chip ${STATUS_TONE[status] || 'neutral'}">${esc(status)}</span>`;
  const COND_TONE = { Operational: 'good', 'Under maintenance': 'info', Damaged: 'bad', Missing: 'bad', 'For disposal': 'warn' };
  const condChip = (c) => `<span class="chip ${COND_TONE[c] || 'neutral'}">${esc(c)}</span>`;

  function toast(msg, tone) {
    const el = document.createElement('div');
    el.className = 'toast' + (tone === 'bad' ? ' bad' : '');
    el.innerHTML = `<svg class="i"><use href="#${tone === 'bad' ? 'i-alert' : 'i-check'}"/></svg><span>${esc(msg)}</span>`;
    qs('#toastStack').appendChild(el);
    setTimeout(() => el.remove(), 3600);
  }

  /* Modals: any element with [data-close] inside closes it; Esc and backdrop click too. */
  let lastFocus = null;
  function open(id) {
    const m = typeof id === 'string' ? qs('#' + id) : id;
    lastFocus = document.activeElement; m.hidden = false;
    const f = qs('button:not([disabled]), [href], input, select, textarea', m); if (f) f.focus();
  }
  function close(id) {
    const m = typeof id === 'string' ? qs('#' + id) : id; m.hidden = true;
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  document.addEventListener('click', (e) => {
    const c = e.target.closest('[data-close]'); if (c) { close(c.closest('.modal-backdrop')); return; }
    if (e.target.classList && e.target.classList.contains('modal-backdrop')) close(e.target);
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') qsa('.modal-backdrop:not([hidden])').forEach(close); });

  /* Required-field validation: [data-required] inside .field */
  function validate(form) {
    let ok = true, first = null;
    qsa('[data-required]', form).forEach((el) => {
      if (el.closest('[hidden]')) { el.closest('.field').classList.remove('has-error'); return; }
      const bad = !String(el.value).trim() || (el.type === 'number' && Number(el.value) < Number(el.min || 0));
      el.closest('.field').classList.toggle('has-error', bad);
      if (bad) { ok = false; first = first || el; }
    });
    if (first) first.focus();
    return ok;
  }
  document.addEventListener('input', (e) => { const f = e.target.closest('.field.has-error'); if (f && String(e.target.value).trim()) f.classList.remove('has-error'); });

  /* Photo dropzone with preview. Returns a getter for the chosen file. */
  function dropzone(root) {
    const input = qs('input[type=file]', root), inner = qs('.dz-inner', root);
    const blank = inner.innerHTML; let file = null;
    const show = (f) => {
      if (!f) return; if (!/^image\//.test(f.type)) { toast('Please choose an image file.', 'bad'); return; }
      if (f.size > 5 * 1024 * 1024) { toast('Photo must be 5 MB or smaller.', 'bad'); return; }
      file = f; const url = URL.createObjectURL(f);
      inner.innerHTML = `<img src="${url}" alt="Selected photo preview"><span class="fname">${esc(f.name)}</span>`;
      const rm = root.parentElement.querySelector('.remove'); if (rm) rm.hidden = false;
    };
    ['dragenter', 'dragover'].forEach((ev) => root.addEventListener(ev, (e) => { e.preventDefault(); root.classList.add('is-over'); }));
    ['dragleave', 'drop'].forEach((ev) => root.addEventListener(ev, (e) => { e.preventDefault(); root.classList.remove('is-over'); }));
    root.addEventListener('drop', (e) => show(e.dataTransfer.files[0]));
    input.addEventListener('change', () => show(input.files[0]));
    const reset = () => { file = null; input.value = ''; inner.innerHTML = blank; const rm = root.parentElement.querySelector('.remove'); if (rm) rm.hidden = true; };
    const rm = root.parentElement.querySelector('.remove'); if (rm) rm.addEventListener('click', reset);
    return { get: () => file, reset };
  }

  /* Review modal body: rows = [[label, value, span2?], ...] */
  function reviewHTML(rows, photo) {
    return rows.filter((r) => r).map(([l, v, wide]) => `<div${wide ? ' class="span-2"' : ''}><dt>${esc(l)}</dt><dd>${v === '' || v == null ? '-----' : esc(v)}</dd></div>`).join('') +
      `<div class="span-2"><dt>Photo</dt><dd class="photo">${photo ? `<img src="${URL.createObjectURL(photo)}" alt="">${esc(photo.name)}` : '<span><svg class="i"><use href="#i-camera"/></svg></span> No photo attached'}</dd></div>`;
  }

  const params = new URLSearchParams(location.search);
  const store = {
    get(k) { try { return JSON.parse(localStorage.getItem('assetly.t.' + k)); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem('assetly.t.' + k, JSON.stringify(v)); return true; } catch (e) { return false; } },
    del(k) { try { localStorage.removeItem('assetly.t.' + k); } catch (e) { /* ignore */ } }
  };

  /* Prefill a report form from ?asset=AST-xxxxx (used by My assets). */
  function assetFromQuery() { const id = params.get('asset'); return id ? (window.TDB.assets.find((a) => a.id === id) || null) : null; }

  /* Shell */
  document.addEventListener('DOMContentLoaded', () => {
    const t = qs('#navToggle'), s = qs('#scrim');
    if (t) t.addEventListener('click', () => document.body.classList.toggle('nav-open'));
    if (s) s.addEventListener('click', () => document.body.classList.remove('nav-open'));
  });

  return { qs, qsa, esc, date, time, dateTime, int, TODAY, daysUntil, chip, condChip, toast, open, close, validate, dropzone, reviewHTML, params, store, assetFromQuery };
})();
