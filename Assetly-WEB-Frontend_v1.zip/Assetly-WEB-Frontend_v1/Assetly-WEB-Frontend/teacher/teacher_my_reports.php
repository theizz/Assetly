<?php
$pageTitle   = 'My reports';
$active      = 'reports';
$pageScripts = ['my_reports.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <h1>My reports</h1>
  <p>Select a report to see its details and status.</p>
</div>

<div class="tabs" role="tablist">
  <button class="tab is-active" role="tab" type="button" data-tab="updates" aria-selected="true"><svg class="i"><use href="#i-file-check"/></svg> Submitted Report Updates <span class="count" id="cUpdates"></span></button>
  <button class="tab" role="tab" type="button" data-tab="tickets" aria-selected="false"><svg class="i"><use href="#i-ticket"/></svg> Submitted Maintenance Tickets <span class="count" id="cTickets"></span></button>
</div>

<select class="select select-sm" id="fStatus" aria-label="Filter by status"><option value="">All statuses</option></select>

<div class="split">
  <div class="rlist" id="list" role="listbox" aria-label="Reports"></div>
  <div id="detail">
    <div class="detail-empty">
      <span class="ic"><svg class="i i-lg"><use href="#i-file"/></svg></span>
      <strong>Select a report</strong>
      <span>Choose a report from the list to see its details, status,<br>and any reason from the Property Custodian.</span>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
