<?php
$pageTitle   = 'Report update';
$active      = 'update';
$pageScripts = ['report_update.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <h1>Report Update</h1>
  <p>Report an asset update to Property Custodian.</p>
</div>

<div class="form-layout">
  <form class="card card-b" id="updateForm" novalidate style="padding:28px 30px 24px">
    <div class="form-grid">
      <div class="field span-2">
        <label class="req" for="u-name">Asset name:</label>
        <input class="input" id="u-name" list="myAssetList" placeholder="Enter asset name" data-required autocomplete="off">
        <datalist id="myAssetList"></datalist>
        <span class="error">Enter the asset name.</span>
      </div>
      <div class="field">
        <label class="req" for="u-category">Category:</label>
        <select class="select" id="u-category" data-required><option value="">Select category</option></select>
        <span class="error">Choose a category.</span>
      </div>
      <div class="field">
        <label class="req" for="u-qty">Quantity:</label>
        <input class="input" id="u-qty" type="number" min="1" step="1" placeholder="Enter quantity" data-required>
        <span class="error">Enter a quantity of at least 1.</span>
      </div>
      <div class="field">
        <label class="req" for="u-building">Building:</label>
        <select class="select" id="u-building" data-required><option value="">Select building</option></select>
        <span class="error">Choose a building.</span>
      </div>
      <div class="field">
        <label class="req" for="u-room">Room:</label>
        <input class="input" id="u-room" placeholder="Enter room number" data-required>
        <span class="error">Enter the room.</span>
      </div>
      <div class="field">
        <label class="req" for="u-type">Update type:</label>
        <select class="select" id="u-type" data-required><option value="">Select update type</option></select>
        <span class="error">Choose an update type.</span>
      </div>
      <!-- Add: where the asset came from -->
      <div class="field" id="sourceField" hidden>
        <label class="req" for="u-source">Asset source:</label>
        <select class="select" id="u-source" data-required><option value="">Select source</option></select>
        <span class="error">Choose where the asset came from.</span>
      </div>
      <!-- Relocation: where it is going -->
      <div class="field" id="newBuildingField" hidden>
        <label class="req" for="u-newBuilding">Move to building:</label>
        <select class="select" id="u-newBuilding" data-required><option value="">Select building</option></select>
        <span class="error">Choose the new building.</span>
      </div>
      <div class="field" id="newRoomField" hidden>
        <label class="req" for="u-newRoom">Move to room:</label>
        <input class="input" id="u-newRoom" placeholder="Enter new room number" data-required>
        <span class="error">Enter the new room.</span>
      </div>
      <div class="field span-2">
        <label class="req" for="u-desc">Description:</label>
        <textarea class="textarea" id="u-desc" placeholder="Describe what is the update..." data-required></textarea>
        <span class="error">Describe the update.</span>
        <span class="hint" id="typeHint"></span>
      </div>
    </div>
    <div class="form-actions">
      <a class="btn btn-outline" href="teacher_home.php">Cancel</a>
      <button class="btn btn-primary btn-lg" type="submit">Submit report update</button>
    </div>
  </form>

  <aside>
    <div class="card photo-card">
      <span class="label">Photo:</span>
      <label class="dropzone" id="dz">
        <input type="file" accept="image/*" aria-label="Upload a photo">
        <span class="dz-inner"><svg class="i i-lg" style="color:var(--navy)"><use href="#i-camera"/></svg><span>Drop a photo here or <b>browse</b></span></span>
      </label>
      <button class="btn btn-ghost btn-sm remove" type="button" hidden><svg class="i"><use href="#i-x"/></svg> Remove photo</button>
    </div>
    <div class="card next">
      <h3>What happens next</h3>
      <ol>
        <li><strong>Saved as pending</strong><small>Your report is recorded</small></li>
        <li><strong>Custodian notified</strong><small>They review your report</small></li>
        <li><strong>Report update</strong><small>You will receive a response to your report</small></li>
      </ol>
    </div>
  </aside>
</div>

<!-- Review before submit -->
<div class="modal-backdrop" id="reviewModal" hidden>
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="reviewTitle">
    <div class="modal-h">
      <span class="ic"><svg class="i"><use href="#i-check"/></svg></span>
      <div><h2 id="reviewTitle">Review your update report</h2><p>Please check your answers before submitting.</p></div>
    </div>
    <dl class="review" id="reviewBody"></dl>
    <p class="modal-note">The custodian will be notified.</p>
    <div class="modal-f">
      <button class="btn btn-ghost" type="button" id="reviewCancel">Cancel</button>
      <button class="btn btn-outline-brand" type="button" data-close>Edit answers</button>
      <button class="btn btn-primary btn-lg" type="button" id="reviewConfirm">Confirm and submit</button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
