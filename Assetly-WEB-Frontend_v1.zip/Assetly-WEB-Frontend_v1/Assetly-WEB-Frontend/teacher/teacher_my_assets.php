<?php
$pageTitle   = 'My assets';
$active      = 'assets';
$pageScripts = ['my_assets.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <h1>My assets</h1>
  <p>Items in the rooms assigned to you. You are accountable for these during the physical count.</p>
</div>

<div class="stack">
  <div class="grid-4" id="kpis"></div>

  <section class="card">
    <div class="card-b" style="padding-bottom:6px">
      <div class="toolbar">
        <div class="search grow">
          <svg class="i"><use href="#i-search"/></svg>
          <input class="input" id="q" type="search" placeholder="Search by asset name, ID or property number" aria-label="Search assets">
        </div>
        <select class="select select-sm" id="fRoom" aria-label="Filter by room"><option value="">All my rooms</option></select>
        <select class="select select-sm" id="fCond" aria-label="Filter by condition"><option value="">All conditions</option></select>
      </div>
    </div>
    <div class="card-b" style="padding-top:8px">
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Asset</th><th>Category</th><th class="text-right">Qty</th><th>Location</th><th>Condition</th><th>Open reports</th><th class="text-right">Actions</th></tr></thead>
          <tbody id="body"></tbody>
        </table>
      </div>
      <p class="hint" style="margin:14px 0 0">Something here is wrong or missing? Use <b>Report update</b>. Broken? Use <b>Report defect</b>. Your list changes only after the custodian approves a report.</p>
    </div>
  </section>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
