<?php
$pageTitle   = 'Physical count';
$active      = 'count';
$pageScripts = ['physical_count.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <h1>Physical Count</h1>
  <p>Count the assets in your assigned rooms and submit the result to the Property Custodian.</p>
</div>

<div class="stack">
  <!-- Period + progress -->
  <section class="card count-head">
    <div>
      <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
        <h2 id="periodTitle">Semi-annual physical count</h2>
        <span id="statusChip"></span>
      </div>
      <div class="meta" id="periodMeta"></div>
      <div class="progress" aria-hidden="true"><span id="progBar" style="width:0"></span></div>
      <div class="progress-l"><span id="progText"></span><span id="savedText"></span></div>
    </div>
    <div class="toolbar" id="headActions">
      <button class="btn btn-outline" type="button" id="printBtn"><svg class="i"><use href="#i-printer"/></svg> Print count sheet</button>
    </div>
  </section>

  <div class="locked-note" id="instructions"><svg class="i"><use href="#i-info"/></svg><span id="instrText"></span></div>
  <div class="locked-note" id="lockedNote" hidden style="background:var(--good-bg);color:#1F4D22"><svg class="i"><use href="#i-check"/></svg><span id="lockedText"></span></div>

  <div class="stat-row" id="stats"></div>

  <!-- Count sheet -->
  <section class="card">
    <div class="card-h">
      <h2>Count sheet</h2>
      <div class="toolbar">
        <select class="select select-sm" id="fRoom" aria-label="Filter by room"><option value="">All my rooms</option></select>
        <label class="check" style="align-items:center"><input type="checkbox" id="onlyOpen"> Show uncounted only</label>
      </div>
    </div>
    <div class="card-b" style="padding-top:14px">
      <div class="table-wrap">
        <table class="table count-table">
          <thead><tr>
            <th>Asset</th><th class="text-right">On record</th><th>Found</th><th class="text-right">Variance</th><th>Condition</th><th>Remarks</th>
          </tr></thead>
          <tbody id="sheet"></tbody>
        </table>
      </div>
    </div>
  </section>

  <!-- Found items that are not on record -->
  <section class="card">
    <div class="card-h">
      <div><h2>Items found but not on your list</h2><p class="hint" style="margin:2px 0 0">Anything in your rooms that is not on record (e.g. donated, borrowed, or left by another class).</p></div>
      <button class="btn btn-soft" type="button" id="addExtra"><svg class="i"><use href="#i-plus"/></svg> Add item</button>
    </div>
    <div class="card-b" style="padding-top:14px">
      <div class="table-wrap">
        <table class="table count-table">
          <thead><tr><th>Item name</th><th>Qty</th><th>Room</th><th>Remarks</th><th></th></tr></thead>
          <tbody id="extras"></tbody>
        </table>
      </div>
    </div>
    <div class="count-foot">
      <span class="hint" id="submitHint"></span>
      <div class="toolbar">
        <button class="btn btn-outline" type="button" id="saveBtn"><svg class="i"><use href="#i-save"/></svg> Save draft</button>
        <button class="btn btn-primary btn-lg" type="button" id="submitBtn"><svg class="i"><use href="#i-send"/></svg> Submit to custodian</button>
      </div>
    </div>
  </section>

  <!-- History -->
  <section class="card">
    <div class="card-h"><h2>Past counts</h2></div>
    <div class="card-b" style="padding-top:12px">
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Period</th><th>Submitted</th><th class="text-right">On record</th><th class="text-right">Found</th><th class="text-right">Missing</th><th>Status</th><th>Custodian note</th></tr></thead>
          <tbody id="history"></tbody>
        </table>
      </div>
    </div>
  </section>
</div>

<!-- Review + certify before submitting -->
<div class="modal-backdrop" id="submitModal" hidden>
  <div class="modal lg" role="dialog" aria-modal="true" aria-labelledby="submitTitle">
    <div class="modal-h">
      <span class="ic"><svg class="i"><use href="#i-clipboard"/></svg></span>
      <div><h2 id="submitTitle">Review your physical count</h2><p>Please check the totals and differences before submitting.</p></div>
    </div>
    <dl class="review" id="submitSummary"></dl>
    <div id="submitDiffs" style="margin-top:14px"></div>
    <label class="check" style="margin-top:16px"><input type="checkbox" id="certify"> I certify that I physically counted the items listed above in my assigned rooms, and that this count is true and correct.</label>
    <p class="modal-note">The custodian will be notified and will verify your count.</p>
    <div class="modal-f">
      <button class="btn btn-ghost" type="button" data-close>Cancel</button>
      <button class="btn btn-outline-brand" type="button" data-close>Edit count</button>
      <button class="btn btn-primary btn-lg" type="button" id="confirmSubmit" disabled>Confirm and submit</button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
