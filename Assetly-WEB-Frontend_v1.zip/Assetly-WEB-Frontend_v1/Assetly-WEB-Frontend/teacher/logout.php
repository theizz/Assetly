<?php
// Placeholder. Wire to your session teardown, then redirect to the landing Login page.
// session_start(); session_destroy(); header('Location: ../landing/Login.php'); exit;
echo 'Logged out (placeholder).';
