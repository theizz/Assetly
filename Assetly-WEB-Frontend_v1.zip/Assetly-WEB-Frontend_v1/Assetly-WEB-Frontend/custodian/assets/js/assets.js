/* Assets page — unit-level tracking (Model B).
   Each asset record is a "bundle"; every physical unit under it is independently
   editable (location, condition, property no). The table groups units by bundle,
   expands to show units, supports per-unit edit and "Edit selected" bulk edit.
   Shared fields (name, category, value, fund source) are edited via Edit asset. */
(function () {
  const A = window.Assetly, DB = window.DB;

  /* Build editable per-unit data on each record once (demo-mutable). */
  const records = DB.assets.map((r) => ({
    ...r,
    unitData: r.units.map((uid, i) => ({
      unitId: uid, building: r.building, room: r.room,
      condition: r.condition, propertyNo: i === 0 ? (r.propertyNo || '') : ''
    }))
  }));
  const recordById = (id) => records.find((r) => r.id === id);
  const allUnits = () => records.flatMap((r) => r.unitData);

  let sortKey = 'id', sortDir = 'asc', page = 1;
  const perPage = 10;
  const expanded = new Set();
  const selected = new Set();   // unitIds
  let viewRows = [];            // filtered records for current render

  /* KPIs — counted per unit so divergence is reflected. */
  function renderKpis() {
    const u = allUnits();
    const by = (c) => u.filter((x) => x.condition === c).length;
    A.qs('#assetKpis').innerHTML = [
      { v: u.length, l: 'Total', ic: 'brand', icon: 'i-layers' },
      { v: by('Operational'), l: 'Operational', ic: 'good', icon: 'i-check-circle' },
      { v: by('Under maintenance'), l: 'Maintenance', ic: 'warn', icon: 'i-wrench' },
      { v: by('For disposal'), l: 'For disposal', ic: 'bad', icon: 'i-trash' }
    ].map((k) => `<div class="kpi"><div><div class="v num">${A.int(k.v)}</div><div class="l">${k.l}</div></div><div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div></div>`).join('');
  }

  /* Populate filter + modal selects */
  const fill = (sel, items, withBlank) => { const el = A.qs(sel); if (withBlank) {} items.forEach((i) => el.insertAdjacentHTML('beforeend', `<option>${A.esc(i)}</option>`)); };
  fill('#fBuilding', DB.buildings); fill('#fCategory', DB.categories); fill('#fCondition', DB.conditions); fill('#fFund', DB.fundSources);
  fill('#u-building', DB.buildings); fill('#u-condition', DB.conditions);
  fill('#be-building', DB.buildings); fill('#be-condition', DB.conditions);

  /* Units of a record that pass the active unit-level filters (building, condition). */
  function unitsOf(r) {
    const fb = A.qs('#fBuilding').value, fcon = A.qs('#fCondition').value;
    return r.unitData.filter((u) => (!fb || u.building === fb) && (!fcon || u.condition === fcon));
  }

  function apply() {
    const q = A.qs('#q').value.trim().toLowerCase();
    const fc = A.qs('#fCategory').value, ff = A.qs('#fFund').value;
    viewRows = records.filter((r) => {
      if (fc && r.category !== fc) return false;
      if (ff && r.fundSource !== ff) return false;
      if (q && !(r.name.toLowerCase().includes(q) || r.id.toLowerCase().includes(q) ||
                 (r.propertyNo || '').toLowerCase().includes(q) || r.units.some((u) => u.toLowerCase().includes(q)))) return false;
      return unitsOf(r).length > 0;
    });
    viewRows = A.sortBy(viewRows, sortKey === 'qty' ? 'qty' : sortKey, sortDir);
    page = 1; render();
  }

  function locSummary(units) {
    const set = [...new Set(units.map((u) => `${u.building} · Room ${u.room}`))];
    return set.length === 1 ? A.esc(set[0]) : `<span class="muted">${set.length} locations</span>`;
  }
  function condSummary(units) {
    const set = [...new Set(units.map((u) => u.condition))];
    if (set.length === 1) return A.conditionChip(set[0]);
    const counts = set.map((c) => `${units.filter((u) => u.condition === c).length} ${c}`).join(', ');
    return `<span class="tag" title="${A.esc(counts)}">Mixed (${set.length})</span>`;
  }

  function render() {
    const body = A.qs('#assetBody');
    const slice = viewRows.slice((page - 1) * perPage, page * perPage);
    if (!slice.length) {
      body.innerHTML = `<tr><td colspan="11"><div class="empty"><svg class="i"><use href="#i-search"/></svg><strong>No assets match your filters</strong>Try clearing the search or a filter.</div></td></tr>`;
    } else {
      body.innerHTML = slice.map((r) => {
        const units = unitsOf(r);
        const multi = r.units.length > 1;
        const isExp = expanded.has(r.id);
        const allSel = units.length > 0 && units.every((u) => selected.has(u.unitId));
        const someSel = units.some((u) => selected.has(u.unitId));
        const groupRow = `
          <tr class="group-row" data-group="${r.id}">
            <td class="check"><input type="checkbox" data-group-cb="${r.id}" ${allSel ? 'checked' : ''} aria-label="Select all units of ${A.esc(r.name)}"></td>
            <td><span class="id-cell">
              ${multi ? `<button class="icon-btn sm expander" data-expand="${r.id}" aria-label="${isExp ? 'Collapse' : 'Expand'}"><svg class="i i-sm" style="transition:transform .15s;${isExp ? 'transform:rotate(90deg)' : ''}"><use href="#i-chevron-right"/></svg></button>` : ''}
              <span class="id num">${r.id}</span>${multi ? `<span class="tag mono">×${r.units.length}</span>` : ''}</span></td>
            <td class="cell-main">${A.esc(r.name)}${r.openTickets ? ` <span class="tag" style="background:var(--bad-bg);color:var(--bad)">${r.openTickets} open</span>` : ''}</td>
            <td>${A.esc(r.category)}</td>
            <td class="text-right num">${units.length}</td>
            <td>${locSummary(units)}</td>
            <td class="num">${A.date(r.dateAcquired)}</td>
            <td class="text-right num">${A.money(r.unitValue)}</td>
            <td><span class="tag">${A.esc(r.fundSource)}</span></td>
            <td>${condSummary(units)}</td>
            <td class="actions"><div class="row-actions">
              <button class="icon-btn sm brand" data-view="${r.id}" aria-label="View"><svg class="i"><use href="#i-eye"/></svg></button>
              <a class="icon-btn sm brand" href="custodian_add_asset.php?edit=${r.id}" aria-label="Edit shared details"><svg class="i"><use href="#i-pencil"/></svg></a>
              <button class="icon-btn sm danger" data-del-group="${r.id}" aria-label="Move bundle to trash"><svg class="i"><use href="#i-trash"/></svg></button>
            </div></td>
          </tr>`;
        let unitRows = '';
        if (multi && isExp) {
          unitRows = units.map((u) => `
            <tr class="unit-row" data-unit-row="${u.unitId}">
              <td class="check"><input type="checkbox" data-unit-cb="${u.unitId}" ${selected.has(u.unitId) ? 'checked' : ''} aria-label="Select ${u.unitId}"></td>
              <td><span class="id num unit-id">${u.unitId}</span></td>
              <td class="muted">— unit —</td>
              <td></td>
              <td class="text-right num">1</td>
              <td>${A.esc(u.building)}<span class="cell-sub">Room ${A.esc(u.room)}</span></td>
              <td></td>
              <td></td>
              <td></td>
              <td>${A.conditionChip(u.condition)}</td>
              <td class="actions"><div class="row-actions">
                <button class="icon-btn sm brand" data-edit-unit="${u.unitId}" aria-label="Edit unit"><svg class="i"><use href="#i-pencil"/></svg></button>
                <button class="icon-btn sm danger" data-del-unit="${u.unitId}" aria-label="Move unit to trash"><svg class="i"><use href="#i-trash"/></svg></button>
              </div></td>
            </tr>`).join('');
        }
        return groupRow + unitRows;
      }).join('');
    }
    A.pager({ el: A.qs('#assetFoot'), total: viewRows.length, page, perPage, onPage: (p) => { page = p; render(); } });
    syncHeader();
    A.qsa('#assetTable thead th.sortable').forEach((th) => {
      th.classList.remove('sorted-asc', 'sorted-desc');
      if (th.dataset.sort === sortKey) th.classList.add(sortDir === 'asc' ? 'sorted-asc' : 'sorted-desc');
    });
  }

  /* Selection */
  function syncHeader() {
    const head = A.qs('#assetTable thead input[type=checkbox]');
    const all = viewRows.flatMap((r) => unitsOf(r).map((u) => u.unitId));
    const chosen = all.filter((id) => selected.has(id));
    head.checked = all.length > 0 && chosen.length === all.length;
    head.indeterminate = chosen.length > 0 && chosen.length < all.length;
    A.qs('#bulkCount').textContent = selected.size;
    A.qs('#bulkLabel').textContent = (selected.size === 1 ? 'unit' : 'units') + ' selected';
    A.qs('#bulkbar').classList.toggle('is-visible', selected.size > 0);
  }
  A.qs('#assetTable thead input[type=checkbox]').addEventListener('change', (e) => {
    const all = viewRows.flatMap((r) => unitsOf(r).map((u) => u.unitId));
    if (e.target.checked) all.forEach((id) => selected.add(id)); else all.forEach((id) => selected.delete(id));
    render();
  });
  A.qs('#assetBody').addEventListener('change', (e) => {
    const g = e.target.closest('[data-group-cb]'), u = e.target.closest('[data-unit-cb]');
    if (g) {
      const r = recordById(g.dataset.groupCb);
      unitsOf(r).forEach((x) => e.target.checked ? selected.add(x.unitId) : selected.delete(x.unitId));
      render();
    } else if (u) {
      e.target.checked ? selected.add(u.dataset.unitCb) : selected.delete(u.dataset.unitCb);
      render();
    }
  });

  /* Row actions */
  A.qs('#assetBody').addEventListener('click', async (e) => {
    const exp = e.target.closest('[data-expand]');
    const view = e.target.closest('[data-view]');
    const editUnit = e.target.closest('[data-edit-unit]');
    const delGroup = e.target.closest('[data-del-group]');
    const delUnit = e.target.closest('[data-del-unit]');
    if (exp) { const id = exp.dataset.expand; expanded.has(id) ? expanded.delete(id) : expanded.add(id); render(); return; }
    if (view) return openView(view.dataset.view);
    if (editUnit) return openUnitEdit(editUnit.dataset.editUnit);
    if (delGroup) {
      const r = recordById(delGroup.dataset.delGroup);
      const ok = await A.confirm({ title: 'Move this bundle to trash?', text: `“${r.name}” (${r.units.length} unit${r.units.length > 1 ? 's' : ''}) will be moved to trash. You can restore it later.`, okLabel: 'Move to trash', tone: 'bad' });
      if (ok) A.toast('Bundle moved to trash.');
    }
    if (delUnit) {
      const ok = await A.confirm({ title: 'Move this unit to trash?', text: `Unit ${delUnit.dataset.delUnit} will be moved to trash separately from its bundle.`, okLabel: 'Move to trash', tone: 'bad' });
      if (ok) A.toast('Unit moved to trash.');
    }
  });

  /* Sorting */
  A.qsa('#assetTable thead th.sortable').forEach((th) => th.addEventListener('click', () => {
    const k = th.dataset.sort;
    if (sortKey === k) sortDir = sortDir === 'asc' ? 'desc' : 'asc'; else { sortKey = k; sortDir = 'asc'; }
    apply();
  }));
  ['#q', '#fBuilding', '#fCategory', '#fCondition', '#fFund'].forEach((s) => A.qs(s).addEventListener('input', () => { apply(); }));

  /* View drawer — shows the bundle with a per-unit breakdown */
  function openView(id) {
    const r = recordById(id);
    A.qs('#viewTitle').textContent = r.name;
    A.qs('#viewSub').textContent = `${r.id}${r.units.length > 1 ? ` · ${r.units.length} units` : ''}`;
    A.qs('#viewEdit').href = 'custodian_add_asset.php?edit=' + r.id;
    const tickets = DB.tickets.filter((t) => t.assetId === r.id);
    const unitTable = r.units.length > 1 ? `
      <div><div class="section-title">Units (${r.unitData.length})</div>
      <div class="table-wrap" style="border:1px solid var(--line);border-radius:8px;margin-top:8px">
        <table class="table compact"><thead><tr><th>Unit ID</th><th>Location</th><th>Condition</th><th>Property no.</th></tr></thead>
        <tbody>${r.unitData.map((u) => `<tr><td class="num">${u.unitId}</td><td>${A.esc(u.building)} · ${A.esc(u.room)}</td><td>${A.conditionChip(u.condition)}</td><td class="muted">${u.propertyNo || '—'}</td></tr>`).join('')}</tbody></table>
      </div></div>` : '';
    A.qs('#viewBody').innerHTML = `
      <div class="meta-strip">
        <div><small class="muted">Units</small><br><strong class="num">${r.unitData.length}</strong></div>
        <div><small class="muted">Unit value</small><br><strong class="num">${A.money(r.unitValue)}</strong></div>
        <div><small class="muted">Total value</small><br><strong class="num">${A.money(r.unitValue * r.unitData.length)}</strong></div>
      </div>
      <dl class="dl">
        <div><dt>Category</dt><dd>${A.esc(r.category)}</dd></div>
        <div><dt>Fund source</dt><dd>${A.esc(r.fundSource)}${r.fundCode ? ` · Code ${r.fundCode}` : ''}</dd></div>
        <div><dt>Date acquired</dt><dd>${A.date(r.dateAcquired)}</dd></div>
        ${(() => { const d = r.deliveryRef && (DB.deliveries || []).find((x) => x.id === r.deliveryRef); return d ? `<div><dt>Delivered via</dt><dd><a href="custodian_deliveries.php?open=${d.id}">${d.id}</a> · ${A.esc(d.ref)}<br><small class="muted">${A.esc(d.source)}${d.supplier ? ' · ' + A.esc(d.supplier) : ''}</small></dd></div>` : ''; })()}
        <div><dt>Last modified</dt><dd>${A.date(r.modifiedAt)}</dd></div>
        ${r.description ? `<div class="span-2"><dt>Description</dt><dd>${A.esc(r.description)}</dd></div>` : ''}
      </dl>
      ${unitTable}
      ${tickets.length ? `<div><div class="section-title">Defect tickets (${tickets.length})</div>
        <div style="margin-top:8px;display:flex;flex-direction:column;gap:6px">${tickets.map((t) => `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 10px;border:1px solid var(--line);border-radius:8px"><span><strong style="font-size:12.5px">${A.esc(t.defectType)}</strong><br><small class="muted">${t.id} · ${A.esc(t.submittedBy)}</small></span>${A.statusChip(t.status)}</div>`).join('')}</div></div>` : ''}`;
    A.open('viewDrawer');
  }

  /* Per-unit edit */
  let editingUnit = null;
  function openUnitEdit(unitId) {
    const r = records.find((x) => x.unitData.some((u) => u.unitId === unitId));
    const u = r.unitData.find((x) => x.unitId === unitId);
    editingUnit = { r, u };
    A.qs('#unitSub').textContent = `${unitId} · ${r.name}`;
    A.qs('#u-building').value = u.building; A.qs('#u-room').value = u.room;
    A.qs('#u-condition').value = u.condition; A.qs('#u-propno').value = u.propertyNo || '';
    A.open('unitModal');
  }
  A.qs('#unitForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const { u } = editingUnit;
    u.building = A.qs('#u-building').value; u.room = A.qs('#u-room').value;
    u.condition = A.qs('#u-condition').value; u.propertyNo = A.qs('#u-propno').value.trim();
    A.close('unitModal'); renderKpis(); render(); A.toast(`Unit ${u.unitId} updated.`);
  });

  /* Bulk edit selected units */
  const toggleGroup = (chk, wrap) => { wrap.style.opacity = chk.checked ? '1' : '.5'; wrap.style.pointerEvents = chk.checked ? 'auto' : 'none'; };
  A.qs('#be-locEnable').addEventListener('change', (e) => toggleGroup(e.target, A.qs('#be-locFields')));
  A.qs('#be-condEnable').addEventListener('change', (e) => toggleGroup(e.target, A.qs('#be-condFields')));
  A.qs('#bulkEdit').addEventListener('click', () => {
    if (!selected.size) return;
    A.qs('#be-locEnable').checked = false; A.qs('#be-condEnable').checked = false;
    toggleGroup(A.qs('#be-locEnable'), A.qs('#be-locFields')); toggleGroup(A.qs('#be-condEnable'), A.qs('#be-condFields'));
    A.qs('#be-room').value = ''; A.qs('#be-building').selectedIndex = 0; A.qs('#be-condition').selectedIndex = 0;
    A.qs('#bulkEditSub').textContent = `${selected.size} unit${selected.size > 1 ? 's' : ''} selected`;
    A.qs('#bulkEditHint').textContent = '';
    A.open('bulkEditModal');
  });
  A.qs('#bulkEditForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const doLoc = A.qs('#be-locEnable').checked, doCond = A.qs('#be-condEnable').checked;
    if (!doLoc && !doCond) { A.qs('#bulkEditHint').textContent = 'Tick at least one field to change.'; return; }
    const building = A.qs('#be-building').value, room = A.qs('#be-room').value.trim(), condition = A.qs('#be-condition').value;
    if (doLoc && !room) { A.qs('#bulkEditHint').textContent = 'Enter a room for the new location.'; return; }
    let n = 0;
    records.forEach((r) => r.unitData.forEach((u) => {
      if (!selected.has(u.unitId)) return;
      if (doLoc) { u.building = building; u.room = room; }
      if (doCond) u.condition = condition;
      n++;
    }));
    A.close('bulkEditModal'); selected.clear(); renderKpis(); render();
    A.toast(`${n} unit${n > 1 ? 's' : ''} updated.`);
  });
  A.qs('#bulkClear').addEventListener('click', () => { selected.clear(); render(); });
  A.qs('#bulkDelete').addEventListener('click', async () => {
    if (!selected.size) return;
    const ok = await A.confirm({ title: `Move ${selected.size} unit${selected.size > 1 ? 's' : ''} to trash?`, text: 'Selected units will be moved to trash and can be restored later.', okLabel: 'Move to trash', tone: 'bad' });
    if (ok) { A.toast(`${selected.size} unit${selected.size > 1 ? 's' : ''} moved to trash.`); selected.clear(); render(); }
  });
  A.qs('#bulkExport').addEventListener('click', () => openExport(selected.size));

  /* ---------- Import (unchanged) ---------- */
  const importModal = A.qs('#importModal');
  let importStep = 1, importedRows = [];
  A.qs('#importBtn').addEventListener('click', () => { resetImport(); A.open(importModal); });
  function resetImport() {
    importStep = 1; importedRows = [];
    A.qs('#importStep1').hidden = false; A.qs('#importStep2').hidden = true;
    A.qs('#importNext').textContent = 'Review file'; A.qs('#importNext').disabled = true;
    A.qs('#fileInput').value = ''; A.qs('#importHint').textContent = '';
    setSteps(1);
  }
  const setSteps = (n) => A.qsa('.step', importModal).forEach((s) => { const i = Number(s.dataset.step); s.classList.toggle('is-active', i === n); s.classList.toggle('is-done', i < n); });
  const dz = A.qs('#dropzone'), fi = A.qs('#fileInput');
  ['dragover', 'dragenter'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('is-over'); }));
  ['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove('is-over'); }));
  dz.addEventListener('drop', (e) => { if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]); });
  fi.addEventListener('change', () => { if (fi.files[0]) handleFile(fi.files[0]); });
  A.qs('#tmplLink').addEventListener('click', (e) => { e.preventDefault(); A.toast('Template download starts in the real build.', 'info'); });
  function handleFile(file) {
    A.qs('#fileName').textContent = file.name;
    A.qs('#importNext').disabled = false;
    A.qs('#importHint').textContent = file.name + ' ready to review';
    importedRows = records.slice(0, 6).map((a, i) => ({ ...a, valid: i !== 4, error: i === 4 ? 'Unknown category' : '' }));
  }
  A.qs('#importNext').addEventListener('click', () => {
    if (importStep === 1) {
      importStep = 2; setSteps(2);
      A.qs('#importStep1').hidden = true; A.qs('#importStep2').hidden = false;
      const valid = importedRows.filter((r) => r.valid).length, errs = importedRows.length - valid;
      A.qs('#validCount').textContent = `${valid} valid`;
      const ec = A.qs('#errorCount'); ec.hidden = errs === 0; ec.textContent = `${errs} error${errs > 1 ? 's' : ''}`;
      A.qs('#previewTable').innerHTML = `
        <thead><tr><th>Row</th><th>Asset name</th><th>Category</th><th class="text-right">Qty</th><th>Fund source</th><th>Status</th></tr></thead>
        <tbody>${importedRows.map((r, i) => `<tr><td class="num">${i + 1}</td><td class="cell-main">${A.esc(r.name)}</td><td>${A.esc(r.category)}</td><td class="text-right num">${r.units.length}</td><td>${A.esc(r.fundSource)}</td><td>${r.valid ? A.chip('Valid', 'good') : `<span class="chip bad" title="${A.esc(r.error)}">${A.esc(r.error)}</span>`}</td></tr>`).join('')}</tbody>`;
      A.qs('#importHint').textContent = errs ? `${errs} row will be skipped` : 'All rows valid';
      A.qs('#importNext').textContent = `Import ${valid} asset${valid > 1 ? 's' : ''}`;
    } else {
      const valid = importedRows.filter((r) => r.valid).length;
      A.close(importModal); A.toast(`${valid} assets imported and logged.`);
    }
  });

  /* ---------- Export (PDF report) ---------- */
  const exportModal = A.qs('#exportModal');
  const EXPORT_COLS = [
    { k: 'id', l: 'Asset ID' }, { k: 'name', l: 'Asset name' }, { k: 'category', l: 'Category' },
    { k: 'qty', l: 'Quantity' }, { k: 'building', l: 'Building' }, { k: 'room', l: 'Room' },
    { k: 'dateAcquired', l: 'Date acquired' }, { k: 'unitValue', l: 'Unit value' }, { k: 'totalValue', l: 'Total value' },
    { k: 'fundSource', l: 'Fund source' }, { k: 'fundCode', l: 'Fund code' }, { k: 'condition', l: 'Condition' },
    { k: 'propertyNo', l: 'Property no.' }, { k: 'modifiedAt', l: 'Last modified' }
  ];
  let exportScope = 0;
  A.qs('#colGrid').innerHTML = EXPORT_COLS.map((c) => `<label class="checkbox"><input type="checkbox" value="${c.k}" ${['propertyNo', 'fundCode', 'modifiedAt', 'totalValue'].includes(c.k) ? '' : 'checked'}> ${c.l}</label>`).join('');
  A.qs('#exportBtn').addEventListener('click', () => openExport(0));
  function openExport(selectedCount) {
    exportScope = selectedCount;
    const n = selectedCount || allUnits().length;
    A.qs('#exportScope').textContent = selectedCount ? `Export ${selectedCount} selected unit${selectedCount > 1 ? 's' : ''}.` : 'Export the current filtered list.';
    updateExportSummary(n);
    A.open(exportModal);
  }
  function updateExportSummary(n) {
    const cols = A.qsa('#colGrid input:checked').length;
    A.qs('#exportSummary').innerHTML = `Generating a PDF report of <strong>${A.int(n || allUnits().length)}</strong> item${(n || allUnits().length) > 1 ? 's' : ''} with <strong>${cols}</strong> column${cols > 1 ? 's' : ''}.`;
  }
  A.qs('#colAll').addEventListener('change', (e) => { A.qsa('#colGrid input').forEach((c) => (c.checked = e.target.checked)); updateExportSummary(exportScope); });
  A.qs('#colGrid').addEventListener('change', () => updateExportSummary(exportScope));
  A.qs('#exportGo').addEventListener('click', () => {
    const n = exportScope || allUnits().length;
    A.close(exportModal); A.toast(`Generating PDF report of ${A.int(n)} items…`, 'info');
  });

  renderKpis();
  apply();
})();
