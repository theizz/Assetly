/* =========================================================================
   Assetly · Mock data for the Property Custodian interface (Path 1, in-scope).
   Every page reads from window.DB. Replace this file (or the loaders in each
   page script) with fetch() calls to your PHP endpoints when the backend is
   ready. Shapes are documented inline so the API can mirror them.
   ========================================================================= */
window.DB = (function () {

  const categories = [
    'Furniture & Fixtures',
    'Electronics & Appliances',
    'Computer Lab Equipment',
    'Science Lab Equipment',
    'TVL & Caregiving Equipment',
    'SPA & Arts Equipment',
    'Sports Equipment',
    'Maintenance & Facility Tools',
    'Books & Learning Materials'
  ];

  const buildings = [
    'Vargas Building', 'Castelo Building', 'Bautista Building',
    'TVL Building', 'Library', 'Admin Building', 'Storage Room'
  ];

  // Condition is the asset's working state. "In storage" means not yet issued to a room.
  const conditions = ['Operational', 'Under maintenance', 'In storage', 'For disposal'];

  // Where the asset was funded from.
  const fundSources = ['National Fund', 'SEF', 'Donation', 'School MOOE'];

  // DepEd fund codes seen on the sample inventory report. Optional on an asset.
  const fundCodes = ['221', '222', '223', '229', '236', '240', '250', '763'];

  // Where deliveries come from (interview Q13, Q15, Q22, Q28).
  const deliverySources = ['Division Office', 'DepEd Central Office', 'LGU / School Board (SEF)', 'Supplier (purchase)', 'Donation'];

  const deliveryDocs = {
    'Division Office': 'IAR / RIS no.',
    'DepEd Central Office': 'IAR no.',
    'LGU / School Board (SEF)': 'SEF delivery receipt no.',
    'Supplier (purchase)': 'PO / DR no.',
    'Donation': 'Deed of Donation no.'
  };

  /* Asset record shape:
     id            first unit ID (also the record key)
     units         one ID per physical unit; length === qty
     qty, name, category, building, room, condition
     dateAcquired  ISO date
     unitValue     PHP, per unit
     fundSource, fundCode, propertyNo, description
     createdAt, modifiedAt, modifiedBy
     openTickets   count of defect tickets not yet resolved/rejected
     deliveryRef   delivery that posted this asset, if any
  */
  const mk = (n, o) => {
    const start = n;
    const units = Array.from({ length: o.qty }, (_, i) => 'AST-' + String(start + i).padStart(5, '0'));
    return Object.assign({ id: units[0], units, openTickets: 0, propertyNo: '', description: '', modifiedBy: 'Zaida M. Padullo' }, o);
  };

  const assets = [
    mk(1,   { name: 'Smart TV 43" UHD (LG 43UR7550PSC)', category: 'Electronics & Appliances', qty: 1,  building: 'Library',           room: 'Reading Area', condition: 'Operational',       dateAcquired: '2024-08-14', unitValue: 30990,   fundSource: 'National Fund', fundCode: '229', propertyNo: '2024-05-0231', createdAt: '2024-08-15', modifiedAt: '2026-10-02T14:10:00' }),
    mk(2,   { name: 'Programmable Robot Kit',             category: 'Science Lab Equipment',    qty: 3,  building: 'Vargas Building',   room: '104',          condition: 'Operational',       dateAcquired: '2018-03-02', unitValue: 110000,  fundSource: 'National Fund', fundCode: '236', propertyNo: '2018-05-0112', createdAt: '2018-03-05', modifiedAt: '2026-06-30T09:00:00' }),
    mk(5,   { name: 'STEM Robotics Expansion Set',        category: 'Science Lab Equipment',    qty: 3,  building: 'Vargas Building',   room: '104',          condition: 'Operational',       dateAcquired: '2018-03-02', unitValue: 24000,   fundSource: 'National Fund', fundCode: '236', propertyNo: '2018-05-0113', createdAt: '2018-03-05', modifiedAt: '2026-06-30T09:00:00' }),
    mk(8,   { name: 'Monoblock Chair',                    category: 'Furniture & Fixtures',     qty: 40, building: 'Bautista Building', room: '204',          condition: 'Operational',       dateAcquired: '2023-06-19', unitValue: 420,     fundSource: 'SEF',           fundCode: '250', createdAt: '2023-06-20', modifiedAt: '2026-09-18T10:30:00' }),
    mk(48,  { name: 'Projector (Epson EB-E01)',           category: 'Electronics & Appliances', qty: 1,  building: 'Castelo Building',  room: '301',          condition: 'Under maintenance', dateAcquired: '2022-11-03', unitValue: 25500,   fundSource: 'National Fund', fundCode: '229', propertyNo: '2022-05-0410', createdAt: '2022-11-04', modifiedAt: '2026-11-08T16:05:00', openTickets: 2 }),
    mk(49,  { name: 'Desktop Computer Set',               category: 'Computer Lab Equipment',   qty: 10, building: 'Castelo Building',  room: '205',          condition: 'Operational',       dateAcquired: '2026-10-12', unitValue: 32000,   fundSource: 'Donation',      fundCode: '',    createdAt: '2026-10-13', modifiedAt: '2026-10-13T11:20:00', deliveryRef: 'DLV-2026-009' }),
    mk(59,  { name: 'Printer (Brother DCP-T720DW)',       category: 'Computer Lab Equipment',   qty: 2,  building: 'Admin Building',    room: 'Property Office', condition: 'Operational',    dateAcquired: '2025-02-27', unitValue: 13995,   fundSource: 'School MOOE',   fundCode: '',    createdAt: '2025-02-28', modifiedAt: '2025-02-28T08:00:00' }),
    mk(61,  { name: 'Hospital Bed 118"x35"x21"',           category: 'TVL & Caregiving Equipment', qty: 1, building: 'TVL Building',    room: '203',          condition: 'Operational',       dateAcquired: '2022-05-10', unitValue: 18500,   fundSource: 'National Fund', fundCode: '223', createdAt: '2022-05-11', modifiedAt: '2026-06-30T09:00:00' }),
    mk(62,  { name: 'CPR Mannequin, half body, adult',    category: 'TVL & Caregiving Equipment', qty: 1, building: 'TVL Building',    room: '203',          condition: 'Operational',       dateAcquired: '2022-05-10', unitValue: 9800,    fundSource: 'National Fund', fundCode: '223', createdAt: '2022-05-11', modifiedAt: '2026-06-30T09:00:00' }),
    mk(63,  { name: 'Compound Microscope',                category: 'Science Lab Equipment',    qty: 8,  building: 'Vargas Building',   room: '103',          condition: 'Operational',       dateAcquired: '2021-09-21', unitValue: 7200,    fundSource: 'National Fund', fundCode: '236', createdAt: '2021-09-22', modifiedAt: '2026-10-01T14:00:00' }),
    mk(71,  { name: 'Electric Fan, stand',                category: 'Electronics & Appliances', qty: 6,  building: 'Bautista Building', room: '101',          condition: 'Operational',       dateAcquired: '2024-04-08', unitValue: 1850,    fundSource: 'SEF',           fundCode: '250', description: 'Semi-expendable.', createdAt: '2024-04-09', modifiedAt: '2024-04-09T09:10:00' }),
    mk(77,  { name: 'Electric Fan, stand',                category: 'Electronics & Appliances', qty: 2,  building: 'Bautista Building', room: '102',          condition: 'For disposal',      dateAcquired: '2019-04-08', unitValue: 1650,    fundSource: 'SEF',           fundCode: '250', description: 'Motor burnt. For return to Division Office.', createdAt: '2019-04-09', modifiedAt: '2026-11-02T13:40:00' }),
    mk(79,  { name: 'Whiteboard 4x8 ft',                  category: 'Furniture & Fixtures',     qty: 12, building: 'Castelo Building',  room: 'Various',      condition: 'Operational',       dateAcquired: '2020-01-15', unitValue: 3200,    fundSource: 'SEF',           fundCode: '250', createdAt: '2020-01-16', modifiedAt: '2020-01-16T09:00:00' }),
    mk(91,  { name: "Teacher's Table with drawers",       category: 'Furniture & Fixtures',     qty: 10, building: 'Storage Room',      room: 'Stockroom A',  condition: 'In storage',        dateAcquired: '2026-11-04', unitValue: 4800,    fundSource: 'SEF',           fundCode: '250', createdAt: '2026-11-05', modifiedAt: '2026-11-05T10:00:00', deliveryRef: 'DLV-2026-011' }),
    mk(101, { name: 'Laptop (Acer Aspire 5)',             category: 'Computer Lab Equipment',   qty: 5,  building: 'Admin Building',    room: 'Faculty Room', condition: 'Operational',       dateAcquired: '2023-12-01', unitValue: 38990,   fundSource: 'National Fund', fundCode: '229', propertyNo: '2023-05-0502', createdAt: '2023-12-02', modifiedAt: '2026-05-14T10:00:00' }),
    mk(106, { name: 'Water Dispenser, hot & cold',        category: 'Electronics & Appliances', qty: 2,  building: 'TVL Building',      room: '203',          condition: 'Operational',       dateAcquired: '2022-05-10', unitValue: 5600,    fundSource: 'National Fund', fundCode: '223', createdAt: '2022-05-11', modifiedAt: '2022-05-11T09:00:00' }),
    mk(108, { name: 'Fire Extinguisher 10 lbs',           category: 'Maintenance & Facility Tools', qty: 14, building: 'Vargas Building', room: 'Hallways',   condition: 'Operational',       dateAcquired: '2025-07-07', unitValue: 2400,    fundSource: 'School MOOE',   fundCode: '',    createdAt: '2025-07-08', modifiedAt: '2025-07-08T09:00:00' }),
    mk(122, { name: 'Split-type Aircon 2HP',              category: 'Electronics & Appliances', qty: 6,  building: 'Castelo Building',  room: 'Various',      condition: 'Operational',       dateAcquired: '2026-10-21', unitValue: 42500,   fundSource: 'SEF',           fundCode: '250', createdAt: '2026-10-22', modifiedAt: '2026-10-22T11:00:00', deliveryRef: 'DLV-2026-010' }),
    mk(128, { name: 'Projector (Epson EB-E01)',           category: 'Electronics & Appliances', qty: 4,  building: 'Storage Room',      room: 'Stockroom A',  condition: 'In storage',        dateAcquired: '2026-10-21', unitValue: 25500,   fundSource: 'SEF',           fundCode: '250', createdAt: '2026-10-22', modifiedAt: '2026-10-22T11:00:00', deliveryRef: 'DLV-2026-010' }),
    mk(132, { name: 'Portable Sound System',              category: 'SPA & Arts Equipment',     qty: 1,  building: 'Admin Building',    room: 'Covered Court', condition: 'Under maintenance', dateAcquired: '2021-02-11', unitValue: 15800,  fundSource: 'National Fund', fundCode: '240', createdAt: '2021-02-12', modifiedAt: '2026-11-06T09:30:00', openTickets: 1 }),
    mk(133, { name: 'Basketball, official size',          category: 'Sports Equipment',         qty: 10, building: 'Admin Building',    room: 'MAPEH Office', condition: 'Operational',       dateAcquired: '2025-01-20', unitValue: 1200,    fundSource: 'School MOOE',   fundCode: '',    createdAt: '2025-01-21', modifiedAt: '2025-01-21T09:00:00' }),
    mk(143, { name: 'Sewing Machine, high speed',         category: 'TVL & Caregiving Equipment', qty: 6, building: 'TVL Building',    room: '105',          condition: 'Operational',       dateAcquired: '2022-05-10', unitValue: 12300,   fundSource: 'National Fund', fundCode: '223', createdAt: '2022-05-11', modifiedAt: '2022-05-11T09:00:00' }),
    mk(149, { name: 'Science Activity Kit (Grade 8)',     category: 'Science Lab Equipment',    qty: 28, building: 'Vargas Building',   room: '105',          condition: 'Operational',       dateAcquired: '2026-09-28', unitValue: 3100,    fundSource: 'National Fund', fundCode: '236', createdAt: '2026-09-29', modifiedAt: '2026-09-29T09:00:00', deliveryRef: 'DLV-2026-008' }),
    mk(177, { name: 'Armchair, student',                  category: 'Furniture & Fixtures',     qty: 45, building: 'Vargas Building',   room: '201',          condition: 'Operational',       dateAcquired: '2019-06-03', unitValue: 980,     fundSource: 'National Fund', fundCode: '222', createdAt: '2019-06-04', modifiedAt: '2019-06-04T09:00:00' }),
    mk(222, { name: 'Steel Filing Cabinet, 4 drawers',    category: 'Furniture & Fixtures',     qty: 3,  building: 'Admin Building',    room: 'Property Office', condition: 'Operational',    dateAcquired: '2020-10-05', unitValue: 8900,    fundSource: 'National Fund', fundCode: '222', createdAt: '2020-10-06', modifiedAt: '2020-10-06T09:00:00' }),
    mk(225, { name: 'Monoblock Chair',                    category: 'Furniture & Fixtures',     qty: 196, building: 'Storage Room',     room: 'Stockroom B',  condition: 'In storage',        dateAcquired: '2026-11-04', unitValue: 420,     fundSource: 'SEF',           fundCode: '250', createdAt: '2026-11-05', modifiedAt: '2026-11-05T10:00:00', deliveryRef: 'DLV-2026-011' })
  ];

  /* Delivery shape:
     id, ref (document number), source, supplier, dateDelivered, loggedBy
     status      'Logged' (awaiting count) | 'Counted' (awaiting posting) | 'Posted'
     fundSource  default fund for all lines
     items[]     { name, category, expected, received, damaged, unitValue, remarks }
     postedAt, countedAt, notes, deedReceived (donations only)
  */
  const deliveries = [
    { id: 'DLV-2026-012', ref: 'IAR-2026-0141', source: 'Division Office', supplier: 'SDO Quezon City', dateDelivered: '2026-11-10', loggedBy: 'Ella Socorro D. Luna', status: 'Logged', fundSource: 'National Fund', fundCode: '229',
      notes: 'Learner tablets for Grade 7. Count before issuance; remaining units go back to Division.',
      items: [
        { name: 'Learner Tablet 10" (DepEd-issued)', category: 'Computer Lab Equipment', expected: 120, received: null, damaged: 0, unitValue: 8900, remarks: '' },
        { name: 'Tablet Charger & Cable',            category: 'Computer Lab Equipment', expected: 120, received: null, damaged: 0, unitValue: 450,  remarks: '' },
        { name: 'Tablet Protective Case',            category: 'Computer Lab Equipment', expected: 120, received: null, damaged: 0, unitValue: 250,  remarks: '' }
      ] },
    { id: 'DLV-2026-011', ref: 'PO-2026-0087', source: 'Supplier (purchase)', supplier: 'JV Office & School Supply', dateDelivered: '2026-11-04', loggedBy: 'Zaida M. Padullo', status: 'Posted', fundSource: 'SEF', fundCode: '250', countedAt: '2026-11-04T15:20:00', postedAt: '2026-11-05T10:00:00',
      notes: '',
      items: [
        { name: 'Monoblock Chair',             category: 'Furniture & Fixtures', expected: 200, received: 198, damaged: 2, unitValue: 420,  remarks: '2 cracked seats, set aside for replacement.' },
        { name: "Teacher's Table with drawers", category: 'Furniture & Fixtures', expected: 10,  received: 10,  damaged: 0, unitValue: 4800, remarks: '' }
      ] },
    { id: 'DLV-2026-010', ref: 'SEF-DR-2026-022', source: 'LGU / School Board (SEF)', supplier: 'Quezon City LSB', dateDelivered: '2026-10-21', loggedBy: 'Zaida M. Padullo', status: 'Posted', fundSource: 'SEF', fundCode: '250', countedAt: '2026-10-21T16:00:00', postedAt: '2026-10-22T11:00:00',
      notes: '',
      items: [
        { name: 'Split-type Aircon 2HP',    category: 'Electronics & Appliances', expected: 6, received: 6, damaged: 0, unitValue: 42500, remarks: '' },
        { name: 'Projector (Epson EB-E01)', category: 'Electronics & Appliances', expected: 4, received: 4, damaged: 0, unitValue: 25500, remarks: '' }
      ] },
    { id: 'DLV-2026-009', ref: 'DOD-2026-003', source: 'Donation', supplier: "LHS Alumni Batch '98", dateDelivered: '2026-10-12', loggedBy: 'Zaida M. Padullo', status: 'Posted', fundSource: 'Donation', fundCode: '', countedAt: '2026-10-12T11:30:00', postedAt: '2026-10-13T11:20:00', deedReceived: true,
      notes: 'Deed of Donation signed and filed.',
      items: [
        { name: 'Desktop Computer Set', category: 'Computer Lab Equipment', expected: 10, received: 10, damaged: 0, unitValue: 32000, remarks: '' }
      ] },
    { id: 'DLV-2026-008', ref: 'IAR-2026-0120', source: 'Division Office', supplier: 'SDO Quezon City', dateDelivered: '2026-09-28', loggedBy: 'Ella Socorro D. Luna', status: 'Posted', fundSource: 'National Fund', fundCode: '236', countedAt: '2026-09-28T14:00:00', postedAt: '2026-09-29T09:00:00',
      notes: '',
      items: [
        { name: 'Science Activity Kit (Grade 8)', category: 'Science Lab Equipment', expected: 30, received: 28, damaged: 0, unitValue: 3100, remarks: '2 kits short on the IAR; reported to SDO.' }
      ] },
    { id: 'DLV-2026-013', ref: 'DOD-2026-004', source: 'Donation', supplier: 'Barangay Greater Lagro', dateDelivered: '2026-11-12', loggedBy: 'Ella Socorro D. Luna', status: 'Counted', fundSource: 'Donation', fundCode: '', countedAt: '2026-11-12T10:10:00', deedReceived: false,
      notes: 'Deed of Donation form released; not yet returned.',
      items: [
        { name: 'Electric Fan, wall-mounted', category: 'Electronics & Appliances', expected: 12, received: 12, damaged: 1, unitValue: 2100, remarks: '1 unit with broken guard.' }
      ] }
  ];

  /* Update report (from a teacher) shape:
     id, type 'Add' | 'Relocation' | 'Delete' | 'Other'
     assetName, category, qty, building, room, newBuilding, newRoom (relocation only)
     matchedAssetId, submittedBy, submittedAt, status 'Pending' | 'Approved' | 'Rejected', description, reason (if rejected)
  */
  const reports = [
    { id: 'UR-0241', type: 'Relocation', assetName: 'Projector (Epson EB-E01)', category: 'Electronics & Appliances', qty: 1, building: 'Castelo Building', room: '301', newBuilding: 'Castelo Building', newRoom: '204', matchedAssetId: 'AST-00048', submittedBy: 'Jose Mari Chan', submittedAt: '2026-11-12T08:40:00', status: 'Pending', description: 'Room 301 is being repainted this week; moving the projector to 204 for the Grade 9 classes.' },
    { id: 'UR-0240', type: 'Add', assetName: 'Bookshelf, 5-tier', category: 'Furniture & Fixtures', qty: 2, building: 'Library', room: 'Reading Area', matchedAssetId: null, submittedBy: 'Athea Miranda', submittedAt: '2026-11-11T14:05:00', status: 'Pending', description: 'Two bookshelves donated by the PTA were placed in the reading area. No deed of donation yet.' },
    { id: 'UR-0239', type: 'Delete', assetName: 'Electric Fan, stand', category: 'Electronics & Appliances', qty: 2, building: 'Bautista Building', room: '102', matchedAssetId: 'AST-00077', submittedBy: 'Louiz Dizon', submittedAt: '2026-11-10T10:12:00', status: 'Pending', description: 'Both fans are beyond repair. Requesting removal from the Room 102 list for return to Division.' },
    { id: 'UR-0238', type: 'Other', assetName: 'Compound Microscope', category: 'Science Lab Equipment', qty: 8, building: 'Vargas Building', room: '103', matchedAssetId: 'AST-00063', submittedBy: 'Miggy Nacino', submittedAt: '2026-11-06T09:00:00', status: 'Approved', description: 'Correct quantity on record from 7 to 8; one unit was returned from Room 105.' },
    { id: 'UR-0237', type: 'Add', assetName: 'Rice Cooker 1.8L', category: 'Electronics & Appliances', qty: 1, building: 'TVL Building', room: '105', matchedAssetId: null, submittedBy: 'Blessy Rabino', submittedAt: '2026-11-03T13:30:00', status: 'Rejected', description: 'Personal rice cooker brought for TLE class.', reason: 'Personally owned items are not school property. Please file a deed of donation if it is being turned over to the school.' }
  ];

  /* Defect ticket shape:
     id, assetId, assetName, category, qty, building, room, defectType, description
     submittedBy, submittedAt, status 'Pending' | 'Acknowledged' | 'In progress' | 'Resolved' | 'Rejected'
     history[] { status, at, by, note }
  */
  const tickets = [
    { id: 'DT-0218', assetId: 'AST-00048', assetName: 'Projector (Epson EB-E01)', category: 'Electronics & Appliances', qty: 1, building: 'Castelo Building', room: '301', defectType: 'Overheating / shuts down', description: 'Shuts down after about 20 minutes. Fan is loud. Fourth report on this unit this month.', submittedBy: 'Jose Mari Chan', submittedAt: '2026-11-08T16:05:00', status: 'Pending', history: [ { status: 'Pending', at: '2026-11-08T16:05:00', by: 'Jose Mari Chan', note: 'Ticket submitted' } ] },
    { id: 'DT-0217', assetId: 'AST-00132', assetName: 'Portable Sound System', category: 'SPA & Arts Equipment', qty: 1, building: 'Admin Building', room: 'Covered Court', defectType: 'No audio output', description: 'Left speaker is dead; right crackles at high volume.', submittedBy: 'Athea Miranda', submittedAt: '2026-11-05T09:30:00', status: 'In progress', history: [ { status: 'Pending', at: '2026-11-05T09:30:00', by: 'Athea Miranda', note: 'Ticket submitted' }, { status: 'Acknowledged', at: '2026-11-05T13:00:00', by: 'Zaida M. Padullo', note: '' }, { status: 'In progress', at: '2026-11-06T09:30:00', by: 'Zaida M. Padullo', note: 'Sir Ibay volunteered to check the wiring.' } ] },
    { id: 'DT-0216', assetId: 'AST-00048', assetName: 'Projector (Epson EB-E01)', category: 'Electronics & Appliances', qty: 1, building: 'Castelo Building', room: '301', defectType: 'Dim / discolored image', description: 'Image has a yellow tint even after cleaning the lens.', submittedBy: 'Louiz Dizon', submittedAt: '2026-10-29T10:45:00', status: 'Acknowledged', history: [ { status: 'Pending', at: '2026-10-29T10:45:00', by: 'Louiz Dizon', note: 'Ticket submitted' }, { status: 'Acknowledged', at: '2026-10-30T08:10:00', by: 'Zaida M. Padullo', note: 'Will request a lamp quotation.' } ] },
    { id: 'DT-0215', assetId: 'AST-00122', assetName: 'Split-type Aircon 2HP', category: 'Electronics & Appliances', qty: 1, building: 'Castelo Building', room: '305', defectType: 'Not cooling', description: 'Blows warm air since Monday.', submittedBy: 'Miggy Nacino', submittedAt: '2026-10-27T07:50:00', status: 'Resolved', history: [ { status: 'Pending', at: '2026-10-27T07:50:00', by: 'Miggy Nacino', note: 'Ticket submitted' }, { status: 'Acknowledged', at: '2026-10-27T09:00:00', by: 'Zaida M. Padullo', note: '' }, { status: 'In progress', at: '2026-10-28T10:00:00', by: 'Zaida M. Padullo', note: 'Technician scheduled.' }, { status: 'Resolved', at: '2026-10-30T15:30:00', by: 'Zaida M. Padullo', note: 'Refrigerant recharged under warranty.' } ] },
    { id: 'DT-0214', assetId: 'AST-00133', assetName: 'Basketball, official size', category: 'Sports Equipment', qty: 3, building: 'Admin Building', room: 'MAPEH Office', defectType: 'Deflated / worn', description: 'Three balls no longer hold air.', submittedBy: 'Blessy Rabino', submittedAt: '2026-10-20T11:00:00', status: 'Rejected', reason: 'Consumable sports supplies are replaced through the MAPEH supply request, not a defect ticket.', history: [ { status: 'Pending', at: '2026-10-20T11:00:00', by: 'Blessy Rabino', note: 'Ticket submitted' }, { status: 'Rejected', at: '2026-10-20T14:20:00', by: 'Zaida M. Padullo', note: 'Consumable sports supplies are replaced through the MAPEH supply request, not a defect ticket.' } ] }
  ];

  // Deleted (soft) assets. Restoring moves the record back into assets with condition unchanged.
  const trash = [
    mk(300, { name: 'CRT Monitor 17"',        category: 'Computer Lab Equipment', qty: 6, building: 'Castelo Building', room: '205',  condition: 'For disposal', dateAcquired: '2012-07-02', unitValue: 4500, fundSource: 'National Fund', fundCode: '229', createdAt: '2012-07-03', modifiedAt: '2026-10-15T10:00:00', deletedAt: '2026-10-15T10:00:00', deletedBy: 'Zaida M. Padullo', deleteReason: 'Turned over to Division Office for disposal (IIRUP 2026-02).' }),
    mk(306, { name: 'Wooden Armchair',        category: 'Furniture & Fixtures',   qty: 15, building: 'Bautista Building', room: '103', condition: 'For disposal', dateAcquired: '2009-06-10', unitValue: 650, fundSource: 'National Fund', fundCode: '222', createdAt: '2009-06-11', modifiedAt: '2026-09-30T09:00:00', deletedAt: '2026-09-30T09:00:00', deletedBy: 'Zaida M. Padullo', deleteReason: 'Termite damage; disposed.' }),
    mk(321, { name: 'Overhead Projector',     category: 'Electronics & Appliances', qty: 1, building: 'Vargas Building', room: '201', condition: 'For disposal', dateAcquired: '2008-02-20', unitValue: 12000, fundSource: 'National Fund', fundCode: '229', createdAt: '2008-02-21', modifiedAt: '2026-08-12T14:00:00', deletedAt: '2026-08-12T14:00:00', deletedBy: 'Ella Socorro D. Luna', deleteReason: 'Obsolete; returned to Division.' })
  ];

  const activity = [
    { at: '2026-11-12T08:40:00', event: 'Report submitted',      user: 'Jose Mari Chan',   details: 'UR-0241 · Relocation: Projector to Castelo 204' },
    { at: '2026-11-11T14:05:00', event: 'Report submitted',      user: 'Athea Miranda',    details: 'UR-0240 · Add: 2 bookshelves in the Library' },
    { at: '2026-11-08T16:05:00', event: 'Ticket submitted',      user: 'Jose Mari Chan',   details: 'DT-0218 · Projector overheating' },
    { at: '2026-11-06T09:30:00', event: 'Ticket status changed', user: 'Zaida M. Padullo', details: 'DT-0217 · Acknowledged → In progress' },
    { at: '2026-11-06T09:05:00', event: 'Report approved',       user: 'Zaida M. Padullo', details: 'UR-0238 · Microscope quantity corrected to 8' },
    { at: '2026-11-05T10:05:00', event: 'Assets moved to trash', user: 'Zaida M. Padullo', details: '6 CRT Monitors · for disposal' },
    { at: '2026-11-04T15:30:00', event: 'Assets imported',       user: 'Ella Socorro D. Luna', details: '208 records from monoblock-chairs.csv' },
    { at: '2026-11-02T13:40:00', event: 'Asset updated',         user: 'Zaida M. Padullo', details: 'AST-00077 · condition set to For disposal' }
  ];

  const recommendations = [
    { level: 'high',   title: 'Projector in Castelo 301 has recurring defect reports', why: '4 tickets in 30 days and 2 still open. Consider replacement or pulling it to storage.', link: 'custodian_defect_tickets.php', linkText: 'Review tickets' },
    { level: 'medium', title: '3 update reports are waiting for review', why: 'A relocation, an add, and a delete request from teachers have not been acted on.', link: 'custodian_update_reports.php', linkText: 'Review reports' },
    { level: 'low',    title: '2 electric fans are marked For disposal', why: 'Room 102 fans are beyond repair. Process the disposal or move them to trash to keep records clean.', link: 'custodian_assets.php', linkText: 'View assets' }
  ];

  /* Physical count (semi-annual, June and December). The custodian opens a period;
     each teacher counts the assets in the rooms assigned to them and submits
     (teacher side: teacher/teacher_physical_count.php). The custodian reviews,
     then verifies or returns each submission.

     Period shape: id, period, opensAt, dueAt, openedBy, status 'Open' | 'Closed', closedAt, instructions
     Submission shape (one per teacher per period):
       id, periodId, teacher, rooms[{building, room}], status 'Not started' | 'Draft' | 'Submitted' | 'Verified' | 'Returned'
       savedAt, submittedAt, reviewedAt, reviewedBy, returnReason, certified
       lines[]  { assetId, name, room, onRecord, found, recCondition, condition, remarks }
       extras[] { name, qty, room, remarks }   (found in the room but not on record) */
  const countPeriods = [
    { id: 'PC-2026-12', period: 'December 2026', opensAt: '2026-11-03', dueAt: '2026-12-15', openedBy: 'Zaida M. Padullo', status: 'Open',
      instructions: 'Count every item physically in each room. Enter what you actually see, not what is on record. Note anything damaged, missing, or not on the list.' },
    { id: 'PC-2026-06', period: 'June 2026', opensAt: '2026-06-01', dueAt: '2026-06-30', openedBy: 'Zaida M. Padullo', status: 'Closed', closedAt: '2026-07-03T16:00:00',
      summary: { teachers: 7, onRecord: 8990, found: 8942, short: 81, over: 15 } },
    { id: 'PC-2025-12', period: 'December 2025', opensAt: '2025-11-17', dueAt: '2025-12-15', openedBy: 'Zaida M. Padullo', status: 'Closed', closedAt: '2025-12-19T15:30:00',
      summary: { teachers: 7, onRecord: 8712, found: 8690, short: 26, over: 4 } }
  ];

  const L = (assetId, name, room, onRecord, found, recCondition, condition, remarks) => ({ assetId, name, room, onRecord, found, recCondition, condition: condition || recCondition, remarks: remarks || '' });
  const countSubmissions = [
    { id: 'PCS-0101', periodId: 'PC-2026-12', teacher: 'Athea Miranda', rooms: [{ building: 'Library', room: 'Reading Area' }], status: 'Submitted',
      savedAt: '2026-11-14T15:40:00', submittedAt: '2026-11-14T15:42:00', certified: true,
      lines: [
        L('AST-00001', 'Smart TV 43" UHD (LG 43UR7550PSC)', 'Reading Area', 1, 1, 'Operational'),
        L('AST-00420', 'Reading Table, 6-seater',           'Reading Area', 8, 8, 'Operational'),
        L('AST-00428', 'Library Chair',                      'Reading Area', 48, 45, 'Operational', 'Operational', '3 chairs taken to the AVR for the seminar; not returned yet.'),
        L('AST-00476', 'Book Cart, steel',                   'Reading Area', 2, 2, 'Operational', 'Damaged', 'One wheel broken off.')
      ],
      extras: [ { name: 'Bookshelf, 5-tier', qty: 2, room: 'Reading Area', remarks: 'Donated by the PTA (see UR-0240).' } ] },
    { id: 'PCS-0102', periodId: 'PC-2026-12', teacher: 'Louiz Dizon', rooms: [{ building: 'Bautista Building', room: '101' }, { building: 'Bautista Building', room: '102' }], status: 'Submitted',
      savedAt: '2026-11-15T10:05:00', submittedAt: '2026-11-15T10:06:00', certified: true,
      lines: [
        L('AST-00071', 'Electric Fan, stand',  '101', 6, 6, 'Operational'),
        L('AST-00077', 'Electric Fan, stand',  '102', 2, 2, 'For disposal'),
        L('AST-00480', 'Armchair, student',    '101', 45, 44, 'Operational', 'Operational', 'One chair missing since the October typhoon class suspension.'),
        L('AST-00525', 'Armchair, student',    '102', 42, 42, 'Operational'),
        L('AST-00567', 'Whiteboard 4x8 ft',    '101', 1, 1, 'Operational'),
        L('AST-00568', 'Whiteboard 4x8 ft',    '102', 1, 1, 'Operational')
      ],
      extras: [] },
    { id: 'PCS-0103', periodId: 'PC-2026-12', teacher: 'Miggy Nacino', rooms: [{ building: 'Vargas Building', room: '103' }, { building: 'Vargas Building', room: '104' }, { building: 'Vargas Building', room: '105' }], status: 'Verified',
      savedAt: '2026-11-13T14:00:00', submittedAt: '2026-11-13T14:02:00', reviewedAt: '2026-11-14T09:30:00', reviewedBy: 'Zaida M. Padullo', certified: true,
      lines: [
        L('AST-00063', 'Compound Microscope',            '103', 8, 8, 'Operational'),
        L('AST-00002', 'Programmable Robot Kit',         '104', 3, 3, 'Operational'),
        L('AST-00005', 'STEM Robotics Expansion Set',    '104', 3, 3, 'Operational'),
        L('AST-00149', 'Science Activity Kit (Grade 8)', '105', 28, 28, 'Operational')
      ],
      extras: [] },
    { id: 'PCS-0104', periodId: 'PC-2026-12', teacher: 'Blessy Rabino', rooms: [{ building: 'TVL Building', room: '105' }, { building: 'TVL Building', room: '203' }], status: 'Returned',
      savedAt: '2026-11-15T16:20:00', submittedAt: '2026-11-15T16:21:00', reviewedAt: '2026-11-16T08:10:00', reviewedBy: 'Zaida M. Padullo', certified: true,
      returnReason: 'Sewing machines show 4 of 6 found but there is no remark. Please recount Room 105 and explain where the 2 units are.',
      lines: [
        L('AST-00143', 'Sewing Machine, high speed',      '105', 6, 4, 'Operational'),
        L('AST-00061', 'Hospital Bed 118"x35"x21"',       '203', 1, 1, 'Operational'),
        L('AST-00062', 'CPR Mannequin, half body, adult', '203', 1, 1, 'Operational'),
        L('AST-00106', 'Water Dispenser, hot & cold',     '203', 2, 2, 'Operational', 'Under maintenance', 'Hot side not heating.')
      ],
      extras: [] },
    { id: 'PCS-0105', periodId: 'PC-2026-12', teacher: 'Grace Lim', rooms: [{ building: 'Admin Building', room: 'Faculty Room' }], status: 'Submitted',
      savedAt: '2026-11-16T07:55:00', submittedAt: '2026-11-16T07:58:00', certified: true,
      lines: [
        L('AST-00101', 'Laptop (Acer Aspire 5)', 'Faculty Room', 5, 5, 'Operational'),
        L('AST-00610', 'Office Table',            'Faculty Room', 12, 12, 'Operational'),
        L('AST-00622', 'Office Chair',            'Faculty Room', 12, 12, 'Operational')
      ],
      extras: [] },
    { id: 'PCS-0106', periodId: 'PC-2026-12', teacher: 'Jose Mari Chan', rooms: [{ building: 'Castelo Building', room: '204' }, { building: 'Castelo Building', room: '301' }], status: 'Draft',
      savedAt: '2026-11-16T08:40:00',
      lines: [
        L('AST-00048', 'Projector (Epson EB-E01)', '301', 1, 1, 'Under maintenance'),
        L('AST-00301', 'Armchair, student',        '204', 45, null, 'Operational'),
        L('AST-00360', 'Compound Microscope',      '301', 6, 6, 'Operational')
      ],
      extras: [] },
    { id: 'PCS-0107', periodId: 'PC-2026-12', teacher: 'Carlo Reyes', rooms: [{ building: 'Castelo Building', room: '205' }], status: 'Not started',
      lines: [
        L('AST-00049', 'Desktop Computer Set', '205', 10, null, 'Operational'),
        L('AST-00640', 'Computer Table',        '205', 10, null, 'Operational')
      ],
      extras: [] }
  ];

  return { categories, buildings, conditions, fundSources, fundCodes, deliverySources, deliveryDocs, assets, deliveries, reports, tickets, trash, activity, recommendations, countPeriods, countSubmissions };
})();
