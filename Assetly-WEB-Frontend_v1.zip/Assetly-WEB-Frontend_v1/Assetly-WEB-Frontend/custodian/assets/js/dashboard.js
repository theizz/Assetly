/* Dashboard page (Path 1, in-scope): derives figures from window.DB. */
(function () {
  const A = window.Assetly, DB = window.DB;
  const active = DB.assets.filter((a) => a.condition !== 'For disposal');

  const sumQty = (list, pred = () => true) => list.reduce((n, a) => n + (pred(a) ? a.qty : 0), 0);
  const total   = sumQty(DB.assets);
  const oper    = sumQty(DB.assets, (a) => a.condition === 'Operational');
  const maint   = sumQty(DB.assets, (a) => a.condition === 'Under maintenance');
  const storage = sumQty(DB.assets, (a) => a.condition === 'In storage');

  /* KPIs */
  const openTickets = DB.tickets.filter((t) => ['Pending', 'Acknowledged', 'In progress'].includes(t.status)).length;
  const kpis = [
    { v: A.int(total),   l: 'Total assets',      d: DB.assets.length + ' records', ic: 'brand',   icon: 'i-layers' },
    { v: A.int(oper),    l: 'Operational',       d: Math.round(oper / total * 100) + '% of assets', ic: 'good', icon: 'i-check-circle' },
    { v: A.int(maint),   l: 'Under maintenance', d: openTickets + ' open tickets', ic: 'warn', icon: 'i-wrench' },
    { v: A.int(storage), l: 'In storage',        d: 'Not yet issued', ic: 'neutral', icon: 'i-archive' }
  ];
  A.qs('#kpiRow').innerHTML = kpis.map((k) => `
    <div class="kpi">
      <div><div class="v num">${k.v}</div><div class="l">${k.l}</div><div class="d">${k.d}</div></div>
      <div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div>
    </div>`).join('');

  const barRows = (entries, max) => entries.map(([name, n]) => `
    <div class="bar-row">
      <div class="bl">${A.esc(name)}</div>
      <div class="bt" title="${A.int(n)} units"><span style="width:${Math.max(3, n / max * 100)}%"></span></div>
      <div class="bv num">${A.int(n)}</div>
    </div>`).join('');

  /* Assets by building (all recorded units) */
  const byBldg = {};
  DB.assets.forEach((a) => { byBldg[a.building] = (byBldg[a.building] || 0) + a.qty; });
  const blds = Object.entries(byBldg).sort((a, b) => b[1] - a[1]);
  A.qs('#bldgBars').innerHTML = barRows(blds, Math.max(...blds.map((b) => b[1]), 1));

  /* Assets by category (operational units) */
  const byCat = {};
  active.forEach((a) => { if (a.condition === 'Operational') byCat[a.category] = (byCat[a.category] || 0) + a.qty; });
  const cats = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
  A.qs('#catBars').innerHTML = barRows(cats, Math.max(...cats.map((c) => c[1]), 1));

  /* Activity log */
  A.qs('#activityTable tbody').innerHTML = DB.activity.slice(0, 4).map((e) => `
    <tr><td class="muted" style="white-space:nowrap">${A.dateTime(e.at)}</td>
    <td class="cell-main">${A.esc(e.event)}</td>
    <td>${A.esc(e.user)}</td>
    <td class="wrap muted">${A.esc(e.details)}</td></tr>`).join('');

  /* Needs attention */
  const pendingReports = DB.reports.filter((r) => r.status === 'Pending').length;
  const forDisposal = DB.assets.filter((a) => a.condition === 'For disposal').length;
  const openCount = (DB.countPeriods || []).find((p) => p.status === 'Open');
  const countsToReview = openCount ? DB.countSubmissions.filter((s) => s.periodId === openCount.id && s.status === 'Submitted').length : 0;
  const attn = [
    ...(openCount ? [{ t: 'Physical counts to verify', s: `${openCount.period} · submitted by teachers`, n: countsToReview, href: 'custodian_physical_count.php', ic: 'info', icon: 'i-clipboard', hot: countsToReview > 0 }] : []),
    { t: 'Pending update reports', s: 'Submitted by teachers', n: pendingReports, href: 'custodian_update_reports.php', ic: 'warn', icon: 'i-file', hot: pendingReports > 0 },
    { t: 'Open defect tickets', s: 'Not yet resolved', n: openTickets, href: 'custodian_defect_tickets.php', ic: 'bad', icon: 'i-wrench', hot: openTickets > 0 },
    { t: 'Assets for disposal', s: 'Pending removal', n: forDisposal, href: 'custodian_assets.php', ic: 'neutral', icon: 'i-trash', hot: false }
  ];
  A.qs('#attnList').innerHTML = attn.map((a) => `
    <a href="${a.href}">
      <span class="attn-ic ${a.ic}"><svg class="i"><use href="#${a.icon}"/></svg></span>
      <span><span class="attn-t">${a.t}</span><br><span class="attn-s">${a.s}</span></span>
      <span class="n ${a.hot ? 'hot' : ''}">${a.n}</span>
    </a>`).join('');

  /* AI recommendations */
  A.qs('#recoList').innerHTML = DB.recommendations.map((r) => `
    <div class="reco-item">
      <div class="reco-top"><span class="priority ${r.level}">${r.level[0].toUpperCase() + r.level.slice(1)}</span><a href="${r.link}">${r.linkText}</a></div>
      <p>${A.esc(r.title)}</p>
      <small class="muted">${A.esc(r.why)}</small>
    </div>`).join('');
})();
