/* Defect tickets page: triage damaged-equipment reports through a status lifecycle. */
(function () {
  const A = window.Assetly, DB = window.DB;
  let rows = [...DB.tickets]; let page = 1; const perPage = 10;
  let current = null;

  // Status lifecycle. Each action lists the statuses reachable from the current one.
  const NEXT = {
    'Pending':      ['Acknowledged', 'In progress', 'Resolved', 'Rejected'],
    'Acknowledged': ['In progress', 'Resolved', 'Rejected'],
    'In progress':  ['Resolved', 'Rejected'],
    'Resolved':     [],
    'Rejected':     []
  };
  const ACTION_META = {
    'Acknowledged': { icon: 'i-thumbs-up', tone: 'info', desc: "You've seen the report and will plan the fix." },
    'In progress':  { icon: 'i-wrench',    tone: 'warn', desc: 'Repair or replacement is under way.' },
    'Resolved':     { icon: 'i-check-circle', tone: 'good', desc: 'The issue is fixed; the asset is back in service.' },
    'Rejected':     { icon: 'i-x-circle',  tone: 'bad',  desc: 'Not a valid defect ticket. A reason is required.' }
  };

  const open = DB.tickets.filter((t) => ['Pending', 'Acknowledged', 'In progress'].includes(t.status));
  A.qs('#ticKpis').innerHTML = [
    { v: DB.tickets.filter((t) => t.status === 'Pending').length, l: 'Pending', ic: 'warn', icon: 'i-wrench' },
    { v: DB.tickets.filter((t) => t.status === 'In progress').length, l: 'In progress', ic: 'info', icon: 'i-clock' },
    { v: DB.tickets.filter((t) => t.status === 'Resolved').length, l: 'Resolved', ic: 'good', icon: 'i-check-circle' },
    { v: open.length, l: 'Open total', ic: 'bad', icon: 'i-alert' }
  ].map((k) => `<div class="kpi"><div><div class="v num">${A.int(k.v)}</div><div class="l">${k.l}</div></div><div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div></div>`).join('');

  DB.buildings.forEach((b) => A.qs('#fBuilding').insertAdjacentHTML('beforeend', `<option>${A.esc(b)}</option>`));

  function apply() {
    const q = A.qs('#q').value.trim().toLowerCase(), fs = A.qs('#fStatus').value, fb = A.qs('#fBuilding').value;
    rows = DB.tickets.filter((t) =>
      (!q || t.assetName.toLowerCase().includes(q) || t.submittedBy.toLowerCase().includes(q) || t.id.toLowerCase().includes(q) || t.defectType.toLowerCase().includes(q)) &&
      (!fs || t.status === fs) && (!fb || t.building === fb));
    rows.sort((a, b) => b.submittedAt.localeCompare(a.submittedAt));
    page = 1; render();
  }

  function render() {
    const slice = rows.slice((page - 1) * perPage, page * perPage);
    const body = A.qs('#ticBody');
    if (!slice.length) { body.innerHTML = `<tr><td colspan="8"><div class="empty"><svg class="i"><use href="#i-wrench"/></svg><strong>No tickets found</strong>Nothing matches your filters.</div></td></tr>`; }
    else body.innerHTML = slice.map((t) => {
      const age = A.daysSince(t.submittedAt);
      const stale = ['Pending', 'Acknowledged', 'In progress'].includes(t.status) && age >= 5;
      return `<tr>
        <td class="id num">${t.id}</td>
        <td class="cell-main">${A.esc(t.assetName)}<span class="cell-sub">${t.assetId}</span></td>
        <td class="wrap">${A.esc(t.defectType)}</td>
        <td>${A.esc(t.building)}<span class="cell-sub">Room ${A.esc(t.room)}</span></td>
        <td>${A.esc(t.submittedBy)}</td>
        <td class="num">${A.date(t.submittedAt)}${stale ? `<span class="cell-sub text-danger">${age} days open</span>` : ''}</td>
        <td>${A.statusChip(t.status)}</td>
        <td class="actions"><button class="btn btn-sm ${NEXT[t.status].length ? 'btn-primary' : 'btn-secondary'}" data-open="${t.id}">${NEXT[t.status].length ? 'Manage' : 'View'}</button></td>
      </tr>`;
    }).join('');
    A.pager({ el: A.qs('#ticFoot'), total: rows.length, page, perPage, onPage: (p) => { page = p; render(); } });
  }

  A.qs('#ticBody').addEventListener('click', (e) => { const b = e.target.closest('[data-open]'); if (b) openDrawer(b.dataset.open); });
  ['#q', '#fStatus', '#fBuilding'].forEach((s) => A.qs(s).addEventListener('input', apply));

  function openDrawer(id) {
    const t = current = DB.tickets.find((x) => x.id === id);
    A.qs('#ticTitle').textContent = t.defectType;
    A.qs('#ticSub').textContent = `${t.id} · ${t.assetName}`;
    const history = (t.history || []).map((h) => `
      <div class="tl-item done"><div class="dot"><i></i></div><div class="body">
        <strong>${A.esc(h.status)}</strong><small class="muted">${A.dateTime(h.at)} · ${A.esc(h.by)}</small>
        ${h.note ? `<div style="font-size:12.5px;margin-top:2px">${A.esc(h.note)}</div>` : ''}
      </div></div>`).join('');
    A.qs('#ticBodyDrawer').innerHTML = `
      <div class="meta-strip">
        <div><small class="muted">Reported by</small><br><strong>${A.esc(t.submittedBy)}</strong></div>
        <div><small class="muted">Submitted</small><br><strong>${A.date(t.submittedAt)}</strong></div>
        <div><small class="muted">Status</small><br>${A.statusChip(t.status)}</div>
      </div>
      <dl class="dl">
        <div><dt>Asset</dt><dd>${A.esc(t.assetName)} <span class="muted">(${t.assetId})</span></dd></div>
        <div><dt>Category</dt><dd>${A.esc(t.category)}</dd></div>
        <div><dt>Building</dt><dd>${A.esc(t.building)}</dd></div>
        <div><dt>Room</dt><dd>${A.esc(t.room)}</dd></div>
        <div class="span-2"><dt>Defect type</dt><dd>${A.esc(t.defectType)}</dd></div>
        <div class="span-2"><dt>Description</dt><dd style="font-weight:400">${A.esc(t.description)}</dd></div>
      </dl>
      ${t.reason ? `<div class="note bad"><svg class="i"><use href="#i-x-circle"/></svg><div><strong>Rejected.</strong> ${A.esc(t.reason)}</div></div>` : ''}
      <div><div class="section-title">History</div><div class="timeline" style="margin-top:10px">${history}</div></div>`;
    const foot = A.qs('#ticFootDrawer');
    if (NEXT[t.status].length) {
      foot.innerHTML = `<button class="btn btn-secondary left" data-close type="button">Close</button>
        <button class="btn btn-primary" id="actBtn" type="button"><svg class="i"><use href="#i-clipboard"/></svg> Choose action</button>`;
      A.qs('#actBtn').addEventListener('click', () => openAction(t));
    } else {
      foot.innerHTML = `<button class="btn btn-secondary" data-close type="button">Close</button>`;
    }
    A.open('ticDrawer');
  }

  /* Choose-action modal */
  function openAction(t) {
    A.qs('#actList').innerHTML = NEXT[t.status].map((st, i) => {
      const m = ACTION_META[st];
      return `<label class="radio-card${i === 0 ? ' is-checked' : ''}">
        <input type="radio" name="act" value="${st}" ${i === 0 ? 'checked' : ''}>
        <span class="ri ${m.tone}"><svg class="i"><use href="#${m.icon}"/></svg></span>
        <span><strong>${st}</strong><small>${m.desc}</small></span>
      </label>`;
    }).join('');
    A.qs('#actNote').value = '';
    syncNoteLabel();
    A.open('actionModal');
  }
  function syncNoteLabel() {
    const sel = A.qs('input[name="act"]:checked')?.value;
    const f = A.qs('#actNoteField');
    A.qs('#actNoteLabel').textContent = sel === 'Rejected' ? 'Reason for rejection' : 'Note';
    f.querySelector('label .muted').textContent = sel === 'Rejected' ? '(required)' : '(optional)';
  }
  A.qs('#actList').addEventListener('change', () => { syncNoteLabel(); A.qs('#actNoteField').classList.remove('is-invalid'); });
  A.qs('#actConfirm').addEventListener('click', async () => {
    const sel = A.qs('input[name="act"]:checked')?.value;
    const note = A.qs('#actNote').value.trim();
    if (sel === 'Rejected' && !note) { A.qs('#actNoteField').classList.add('is-invalid'); return; }
    const ok = await A.confirm({ title: `Mark ticket as ${sel}?`, text: `${current.submittedBy} will be notified and the change is logged.`, okLabel: 'Confirm', tone: sel === 'Rejected' ? 'bad' : sel === 'Resolved' ? 'good' : 'warn' });
    if (!ok) return;
    A.close('actionModal'); A.close('ticDrawer');
    A.toast(`Ticket ${current.id} marked ${sel}.`);
  });

  apply();
})();
