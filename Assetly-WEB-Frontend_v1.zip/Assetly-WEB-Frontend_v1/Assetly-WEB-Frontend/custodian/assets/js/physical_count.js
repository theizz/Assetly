/* Physical count (custodian): open/close count periods, follow up with teachers,
   review each submitted count, then verify it or return it for correction.
   Teacher side: teacher/teacher_physical_count.php. Data: DB.countPeriods, DB.countSubmissions. */
(function () {
  const A = window.Assetly, DB = window.DB, { qs, qsa, esc, int } = A;
  /* "Today" fixed for the demo so due-date countdowns are stable. Use new Date() in production. */
  const TODAY = new Date('2026-11-16T09:00:00');
  const nowISO = () => new Date().toISOString().slice(0, 19);
  const ME = 'Zaida M. Padullo';

  const TONE = { 'Not started': 'neutral', Draft: 'warn', Submitted: 'info', Verified: 'good', Returned: 'bad', Open: 'info', Closed: 'neutral' };
  const chip = (s) => A.chip(s, TONE[s]);
  const DONE = ['Submitted', 'Verified'];          // counts that hold real numbers
  const NOT_IN = ['Not started', 'Draft', 'Returned'];

  let periodId = (DB.countPeriods.find((p) => p.status === 'Open') || DB.countPeriods[0]).id;
  let page = 1; const perPage = 10;
  const period = () => DB.countPeriods.find((p) => p.id === periodId);
  const subsOf = (pid) => DB.countSubmissions.filter((s) => s.periodId === pid);

  /* ---------- Per-submission figures ---------- */
  function figures(s) {
    const counted = s.lines.filter((l) => l.found !== null && l.found !== undefined);
    const onRecord = s.lines.reduce((n, l) => n + l.onRecord, 0);
    const found = counted.reduce((n, l) => n + l.found, 0);
    const short = counted.reduce((n, l) => n + Math.max(0, l.onRecord - l.found), 0);
    const extraQty = s.extras.reduce((n, x) => n + x.qty, 0);
    const over = counted.reduce((n, l) => n + Math.max(0, l.found - l.onRecord), 0) + extraQty;
    const shortLines = counted.filter((l) => l.found < l.onRecord);
    const condLines = counted.filter((l) => l.condition !== l.recCondition);
    const noRemark = counted.filter((l) => l.found !== l.onRecord && !l.remarks.trim());
    return { onRecord, found, short, over, counted: counted.length, lines: s.lines.length, shortLines, condLines, noRemark, extras: s.extras.length };
  }
  const roomsText = (s) => s.rooms.map((r) => `${r.building.replace(' Building', '')} · ${r.room}`).join(', ');
  const daysLeft = (iso) => Math.ceil((new Date(iso + 'T23:59:59') - TODAY) / 86400000);

  /* ---------- Header / KPIs / period ---------- */
  function renderPeriodSelect() {
    qs('#periodSel').innerHTML = [...DB.countPeriods].sort((a, b) => b.opensAt.localeCompare(a.opensAt))
      .map((p) => `<option value="${p.id}"${p.id === periodId ? ' selected' : ''}>${esc(p.period)}${p.status === 'Open' ? ' (open)' : ''}</option>`).join('');
  }

  function renderTop() {
    const p = period(), subs = subsOf(p.id), open = DB.countPeriods.some((x) => x.status === 'Open');
    const by = (st) => subs.filter((s) => s.status === st).length;
    const done = subs.filter((s) => DONE.includes(s.status));
    const short = done.reduce((n, s) => n + figures(s).short, 0);

    if (subs.length) {
      qs('#pcKpis').innerHTML = [
        { v: by('Submitted'), l: 'To review', d: 'Submitted, awaiting you', ic: 'brand', icon: 'i-clipboard' },
        { v: `${by('Verified')}/${subs.length}`, l: 'Verified', d: 'Teachers done', ic: 'good', icon: 'i-check-circle' },
        { v: subs.filter((s) => NOT_IN.includes(s.status)).length, l: 'Not in yet', d: 'Not started, draft or returned', ic: 'warn', icon: 'i-clock' },
        { v: short, l: 'Units short', d: 'In submitted counts', ic: 'bad', icon: 'i-alert' }
      ].map(kpi).join('');
    } else {
      const sm = p.summary || {};
      qs('#pcKpis').innerHTML = [
        { v: sm.teachers || 0, l: 'Teachers', d: 'Counted this period', ic: 'brand', icon: 'i-clipboard' },
        { v: int(sm.onRecord), l: 'On record', d: 'Units', ic: 'neutral', icon: 'i-layers' },
        { v: int(sm.found), l: 'Found', d: 'Units', ic: 'good', icon: 'i-check-circle' },
        { v: int(sm.short), l: 'Units short', d: `${int(sm.over)} over`, ic: 'bad', icon: 'i-alert' }
      ].map(kpi).join('');
    }

    qs('#periodName').textContent = `${p.period} physical count`;
    qs('#periodChip').innerHTML = chip(p.status);
    const left = daysLeft(p.dueAt);
    qs('#periodMeta').innerHTML = p.status === 'Open'
      ? `Opened ${A.date(p.opensAt)} by ${esc(p.openedBy)} · Due ${A.date(p.dueAt)} <strong class="${left <= 7 ? 'text-danger' : ''}">(${left < 0 ? Math.abs(left) + ' days overdue' : left + ' days left'})</strong>`
      : `Ran ${A.date(p.opensAt)} – ${A.date(p.dueAt)} · Closed ${A.dateTime(p.closedAt)}`;

    if (subs.length) {
      const pct = Math.round((done.length / subs.length) * 100);
      qs('#periodProgress').innerHTML = `
        <div class="progress ${pct === 100 ? 'good' : ''}"><span style="width:${pct}%"></span></div>
        <div class="pc-legend"><span><b>${done.length} of ${subs.length}</b> teachers submitted (${pct}%)</span>
          ${['Verified', 'Submitted', 'Returned', 'Draft', 'Not started'].map((st) => `<span>${chip(st)} <b>${by(st)}</b></span>`).join('')}</div>`;
    } else qs('#periodProgress').innerHTML = `<div class="note info"><svg class="i"><use href="#i-info"/></svg><div>This period is closed. Per-teacher detail is kept in the archive; totals are shown above.</div></div>`;

    const pb = qs('#periodBtn');
    if (open) { pb.innerHTML = '<svg class="i"><use href="#i-archive"/></svg> Close period'; pb.dataset.mode = 'close'; pb.disabled = p.status !== 'Open'; pb.title = p.status !== 'Open' ? 'Switch to the open period to close it' : ''; }
    else { pb.innerHTML = '<svg class="i"><use href="#i-plus"/></svg> Open count period'; pb.dataset.mode = 'open'; pb.disabled = false; pb.title = ''; }
    qs('#remindAll').disabled = p.status !== 'Open';
  }
  const kpi = (k) => `<div class="kpi"><div><div class="v num">${k.v}</div><div class="l">${k.l}</div><div class="d">${k.d}</div></div><div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div></div>`;

  /* ---------- Submissions table ---------- */
  ['Submitted', 'Returned', 'Draft', 'Not started', 'Verified'].forEach((s) => qs('#fStatus').insertAdjacentHTML('beforeend', `<option>${s}</option>`));
  DB.buildings.forEach((b) => qs('#fBuilding').insertAdjacentHTML('beforeend', `<option>${esc(b)}</option>`));
  const ORDER = { Submitted: 0, Returned: 1, Draft: 2, 'Not started': 3, Verified: 4 };

  function rows() {
    const q = qs('#q').value.trim().toLowerCase(), fs = qs('#fStatus').value, fb = qs('#fBuilding').value;
    return subsOf(periodId).filter((s) => (!fs || s.status === fs) && (!fb || s.rooms.some((r) => r.building === fb)) &&
      (!q || s.teacher.toLowerCase().includes(q) || roomsText(s).toLowerCase().includes(q)))
      .sort((a, b) => ORDER[a.status] - ORDER[b.status] || a.teacher.localeCompare(b.teacher));
  }

  function flagsHTML(f) {
    const t = [];
    if (f.shortLines.length) t.push(`<span class="tag bad">${f.shortLines.length} short</span>`);
    if (f.condLines.length) t.push(`<span class="tag warn">${f.condLines.length} condition</span>`);
    if (f.extras) t.push(`<span class="tag warn">${f.extras} not on record</span>`);
    if (f.noRemark.length) t.push(`<span class="tag bad">${f.noRemark.length} no remark</span>`);
    return t.length ? `<div class="pc-flags">${t.join('')}</div>` : '<span class="tag">No differences</span>';
  }

  function renderTable() {
    const list = rows(), body = qs('#pcBody');
    const slice = list.slice((page - 1) * perPage, page * perPage);
    const isOpen = period().status === 'Open';
    body.innerHTML = slice.map((s) => {
      const f = figures(s), hasNums = DONE.includes(s.status) || s.status === 'Returned';      const action = s.status === 'Submitted' && isOpen ? `<button class="btn btn-sm btn-primary" data-open="${s.id}">Review</button>`
        : (hasNums ? `<button class="btn btn-sm btn-secondary" data-open="${s.id}">View</button>`
        : (isOpen ? `<button class="btn btn-sm btn-secondary" data-remind="${s.id}"><svg class="i"><use href="#i-bell"/></svg> Remind</button>` : ''));
      return `<tr>
        <td class="cell-main">${esc(s.teacher)}</td>
        <td class="wrap">${esc(roomsText(s))}</td>
        <td class="text-right num">${int(f.onRecord)}</td>
        <td class="text-right num">${hasNums ? int(f.found) : `<span class="muted" title="Items counted so far">${f.counted}/${f.lines}</span>`}</td>
        <td class="text-right num ${hasNums && f.short ? 'text-danger' : 'muted'}">${hasNums ? int(f.short) : '—'}</td>
        <td class="text-right num ${hasNums && f.over ? 'text-warn' : 'muted'}">${hasNums ? int(f.over) : '—'}</td>
        <td>${hasNums ? flagsHTML(f) : '<span class="muted">—</span>'}</td>
        <td class="num">${s.submittedAt && s.status !== 'Draft' ? A.date(s.submittedAt) : (s.savedAt ? `<span class="muted">Saved ${A.date(s.savedAt)}</span>` : '<span class="muted">—</span>')}</td>
        <td>${chip(s.status)}</td>
        <td class="actions">${action}</td>
      </tr>`;
    }).join('') || `<tr><td colspan="10"><div class="empty"><svg class="i"><use href="#i-clipboard"/></svg><strong>No counts to show</strong>${subsOf(periodId).length ? 'Try clearing the search or a filter.' : 'Per-teacher detail is not kept for closed periods in this demo.'}</div></td></tr>`;
    A.pager({ el: qs('#pcFoot'), total: list.length, page, perPage, onPage: (p) => { page = p; renderTable(); } });
  }

  /* ---------- Reconciliation by building ---------- */
  function renderRecon() {
    const agg = {};
    subsOf(periodId).filter((s) => DONE.includes(s.status)).forEach((s) => {
      s.lines.forEach((l) => {
        const b = (s.rooms.find((r) => r.room === l.room) || s.rooms[0]).building;
        const a = agg[b] || (agg[b] = { rooms: new Set(), onRecord: 0, found: 0, short: 0, over: 0 });
        a.rooms.add(l.room); a.onRecord += l.onRecord; a.found += l.found;
        a.short += Math.max(0, l.onRecord - l.found); a.over += Math.max(0, l.found - l.onRecord);
      });
      s.extras.forEach((x) => { const b = s.rooms[0].building; if (agg[b]) agg[b].over += x.qty; });
    });
    const list = Object.entries(agg).sort((a, b) => a[0].localeCompare(b[0]));
    qs('#reconBody').innerHTML = list.map(([b, a]) => {
      const pct = a.onRecord ? Math.round(((a.onRecord - a.short) / a.onRecord) * 1000) / 10 : 100;
      return `<tr><td class="cell-main">${esc(b)}</td><td class="text-right num">${a.rooms.size}</td><td class="text-right num">${int(a.onRecord)}</td><td class="text-right num">${int(a.found)}</td>
        <td class="text-right num ${a.short ? 'text-danger' : 'muted'}">${int(a.short)}</td><td class="text-right num ${a.over ? 'text-warn' : 'muted'}">${int(a.over)}</td>
        <td><div class="match"><div class="progress ${pct >= 99 ? 'good' : pct >= 95 ? 'warn' : 'bad'}"><span style="width:${pct}%"></span></div><span class="num">${pct}%</span></div></td></tr>`;
    }).join('') || `<tr><td colspan="7"><div class="empty" style="padding:20px"><strong>Nothing to reconcile yet</strong>Buildings appear here once their counts are submitted.</div></td></tr>`;
  }

  const renderAll = () => { renderPeriodSelect(); renderTop(); renderTable(); renderRecon(); };

  /* ---------- Review drawer ---------- */
  let current = null;
  function openDrawer(id) {
    const s = DB.countSubmissions.find((x) => x.id === id); if (!s) return;
    current = s;
    const f = figures(s), p = DB.countPeriods.find((x) => x.id === s.periodId);
    qs('#pcTitle').textContent = `${s.teacher} · ${p.period}`;
    qs('#pcSub').textContent = roomsText(s);

    const tl = `
      <div class="meta-strip">
        <div><small class="muted">On record</small><br><strong class="num">${int(f.onRecord)}</strong></div>
        <div><small class="muted">Found</small><br><strong class="num">${int(f.found)}</strong></div>
        <div><small class="muted">Short</small><br><strong class="num ${f.short ? 'text-danger' : ''}">${int(f.short)}</strong></div>
        <div><small class="muted">Over / not on record</small><br><strong class="num ${f.over ? 'text-warn' : ''}">${int(f.over)}</strong></div>
      </div>
      <div class="timeline">
        <div class="tl-item done"><div class="dot"><i></i></div><div class="body"><strong>Period opened</strong><small class="muted">${A.date(p.opensAt)} · ${esc(p.openedBy)}</small></div></div>
        <div class="tl-item ${s.submittedAt ? 'done' : 'active'}"><div class="dot"><i></i></div><div class="body"><strong>Counted and submitted${s.certified ? ' (certified by teacher)' : ''}</strong><small class="muted">${s.submittedAt ? A.dateTime(s.submittedAt) : 'Not submitted yet'}</small></div></div>
        <div class="tl-item ${s.status === 'Verified' ? 'done' : s.status === 'Submitted' ? 'active' : ''}"><div class="dot"><i></i></div><div class="body"><strong>${s.status === 'Returned' ? 'Returned for correction' : 'Verified by custodian'}</strong><small class="muted">${s.reviewedAt ? A.dateTime(s.reviewedAt) + ' · ' + esc(s.reviewedBy) : 'Waiting for your review'}</small></div></div>
      </div>`;

    const notes = [
      s.status === 'Returned' ? `<div class="note bad"><svg class="i"><use href="#i-restore"/></svg><div><strong>Returned:</strong> ${esc(s.returnReason)}</div></div>` : '',
      f.noRemark.length && s.status === 'Submitted' ? `<div class="note warn"><svg class="i"><use href="#i-alert"/></svg><div>${f.noRemark.length} item${f.noRemark.length > 1 ? 's have' : ' has'} a difference with no remark from the teacher. Consider returning the count.</div></div>` : '',
      s.status === 'Verified' ? `<div class="note good"><svg class="i"><use href="#i-check-circle"/></svg><div>Verified. ${f.condLines.length ? 'Condition changes were applied to the asset records. ' : ''}${f.shortLines.length ? 'Short items were flagged for investigation.' : ''}</div></div>` : ''
    ].join('');

    const byRoom = s.rooms.map((r) => {
      const ls = s.lines.filter((l) => l.room === r.room);
      if (!ls.length) return '';
      return `<tr class="room-band"><td colspan="6">${esc(r.building)} · ${esc(r.room)}</td></tr>` + ls.map((l) => {
        const v = l.found == null ? null : l.found - l.onRecord;
        const cond = l.condition !== l.recCondition ? `<span class="cond-change">${esc(l.recCondition)} → <b>${esc(l.condition)}</b></span>` : `<span class="muted">${esc(l.condition)}</span>`;
        const rem = l.remarks ? esc(l.remarks) : (v ? '<span class="no-remark">No remark</span>' : '<span class="muted">—</span>');
        return `<tr><td class="cell-main wrap">${esc(l.name)}<span class="cell-sub">${l.assetId}</span></td>
          <td class="text-right num">${int(l.onRecord)}</td>
          <td class="text-right num">${l.found == null ? '<span class="muted">—</span>' : int(l.found)}</td>
          <td class="text-right"><span class="var num ${v < 0 ? 'text-danger' : v > 0 ? 'text-warn' : 'muted'}">${v == null ? '—' : (v > 0 ? '+' : '') + int(v)}</span></td>
          <td>${cond}</td><td class="wrap">${rem}</td></tr>`;
      }).join('');
    }).join('');

    const extras = s.extras.length ? `
      <div><div class="section-title">Found but not on record (${s.extras.length})</div>
        <div class="line-items" style="margin-top:10px"><table class="table"><thead><tr><th>Item</th><th class="text-right">Qty</th><th>Room</th><th>Teacher's note</th></tr></thead>
        <tbody>${s.extras.map((x) => `<tr><td class="cell-main wrap">${esc(x.name)}</td><td class="text-right num">${int(x.qty)}</td><td>${esc(x.room)}</td><td class="wrap">${esc(x.remarks) || '<span class="muted">—</span>'}</td></tr>`).join('')}</tbody></table></div>
        <p class="muted" style="font-size:12px;margin:6px 0 0">To put these on record, use <a href="custodian_add_asset.php">Add asset</a> or approve the matching update report.</p></div>` : '';

    qs('#pcDrawerBody').innerHTML = `${tl}${notes}
      <div><div class="section-title">Count by room</div>
        <div class="line-items" style="margin-top:10px"><table class="table">
          <thead><tr><th>Asset</th><th class="text-right">On record</th><th class="text-right">Found</th><th class="text-right">Variance</th><th>Condition</th><th>Teacher's remarks</th></tr></thead>
          <tbody>${byRoom}</tbody></table></div></div>
      ${extras}`;

    const foot = qs('#pcDrawerFoot');
    if (s.status === 'Submitted' && p.status === 'Open') {
      foot.innerHTML = `<div class="left" style="display:flex;flex-direction:column;gap:4px">
          ${f.condLines.length ? `<label class="checkbox"><input type="checkbox" id="optCond" checked> Apply ${f.condLines.length} condition change${f.condLines.length > 1 ? 's' : ''} to asset records</label>` : ''}
          ${f.shortLines.length ? `<label class="checkbox"><input type="checkbox" id="optShort" checked> Flag ${f.short} short unit${f.short > 1 ? 's' : ''} for investigation</label>` : ''}
        </div>
        <button class="btn btn-danger-soft" id="returnBtn" type="button"><svg class="i"><use href="#i-restore"/></svg> Return</button>
        <button class="btn btn-good" id="verifyBtn" type="button"><svg class="i"><use href="#i-check-circle"/></svg> Verify count</button>`;
      qs('#verifyBtn').addEventListener('click', verify);
      qs('#returnBtn').addEventListener('click', () => { qs('#returnSub').textContent = `${s.teacher} · ${roomsText(s)}`; qs('#returnReason').value = ''; qs('#returnForm .field').classList.remove('is-invalid'); A.open('returnModal'); });
    } else {
      foot.innerHTML = `<button class="btn btn-secondary left" data-close type="button">Close</button>
        <button class="btn btn-primary" type="button" id="printOne"><svg class="i"><use href="#i-printer"/></svg> Print count sheet</button>`;
      qs('#printOne').addEventListener('click', () => window.print());
    }
    A.open('pcDrawer');
  }

  async function verify() {
    const s = current, f = figures(s);
    const applyCond = qs('#optCond') ? qs('#optCond').checked : false, flagShort = qs('#optShort') ? qs('#optShort').checked : false;
    const parts = [applyCond ? `${f.condLines.length} condition change${f.condLines.length > 1 ? 's' : ''} will be applied` : '', flagShort ? `${f.short} short unit${f.short > 1 ? 's' : ''} will be flagged for investigation` : ''].filter(Boolean);
    const ok = await A.confirm({ title: `Verify ${s.teacher}'s count?`, text: `${int(f.found)} of ${int(f.onRecord)} units found.${parts.length ? ' ' + parts.join('; ') + '.' : ''} The teacher can no longer edit this count.`, okLabel: 'Verify count', tone: 'good' });
    if (!ok) return;
    // Backend: POST /count/{periodId}/submissions/{id}/verify { applyCond, flagShort }
    s.status = 'Verified'; s.reviewedAt = nowISO(); s.reviewedBy = ME;
    A.close('pcDrawer'); renderAll(); A.toast(`${s.teacher}'s count verified.`);
  }

  qs('#returnForm').addEventListener('submit', (e) => {
    e.preventDefault();
    if (!A.validate(qs('#returnForm'))) return;
    // Backend: POST /count/{periodId}/submissions/{id}/return { reason }
    const s = current;
    s.status = 'Returned'; s.returnReason = qs('#returnReason').value.trim(); s.reviewedAt = nowISO(); s.reviewedBy = ME;
    A.close('returnModal'); A.close('pcDrawer'); renderAll();
    A.toast(`Count returned to ${s.teacher} for correction.`, 'info');
  });

  /* ---------- Table + filters ---------- */
  qs('#pcBody').addEventListener('click', (e) => {
    const o = e.target.closest('[data-open]'), r = e.target.closest('[data-remind]');
    if (o) openDrawer(o.dataset.open);
    if (r) { const s = DB.countSubmissions.find((x) => x.id === r.dataset.remind); A.toast(`Reminder sent to ${s.teacher}.`, 'info'); }
  });
  ['#q', '#fStatus', '#fBuilding'].forEach((sel) => qs(sel).addEventListener('input', () => { page = 1; renderTable(); }));
  qs('#periodSel').addEventListener('change', (e) => { periodId = e.target.value; page = 1; renderAll(); });
  qs('#remindAll').addEventListener('click', async () => {
    const pending = subsOf(periodId).filter((s) => NOT_IN.includes(s.status));
    if (!pending.length) return A.toast('Everyone has submitted.', 'info');
    const ok = await A.confirm({ title: `Send a reminder to ${pending.length} teacher${pending.length > 1 ? 's' : ''}?`, text: `${pending.map((s) => s.teacher).join(', ')} will be reminded that the count is due ${A.date(period().dueAt)}.`, okLabel: 'Send reminders' });
    if (ok) A.toast(`Reminder sent to ${pending.length} teacher${pending.length > 1 ? 's' : ''}.`, 'info');
  });
  qs('#printBtn').addEventListener('click', () => window.print());

  /* ---------- Open / close period ---------- */
  qs('#periodBtn').addEventListener('click', async () => {
    if (qs('#periodBtn').dataset.mode === 'close') {
      const subs = subsOf(periodId), unverified = subs.filter((s) => s.status === 'Submitted').length, missing = subs.filter((s) => NOT_IN.includes(s.status)).length;
      const warn = unverified || missing;
      const ok = await A.confirm({
        title: `Close the ${period().period} count?`,
        text: warn ? `${unverified} submitted count${unverified === 1 ? ' is' : 's are'} not verified and ${missing} teacher${missing === 1 ? ' has' : 's have'} not submitted. Their rooms will be recorded as not counted. Teachers can no longer submit.`
          : 'All counts are verified. Teachers can no longer submit, and the totals are archived.',
        okLabel: 'Close period', tone: warn ? 'bad' : 'good' });
      if (!ok) return;
      const p = period(), done = subs.filter((s) => DONE.includes(s.status)).map(figures);
      p.status = 'Closed'; p.closedAt = nowISO();
      p.summary = { teachers: done.length, onRecord: done.reduce((n, f) => n + f.onRecord, 0), found: done.reduce((n, f) => n + f.found, 0), short: done.reduce((n, f) => n + f.short, 0), over: done.reduce((n, f) => n + f.over, 0) };
      renderAll(); A.toast(`${p.period} count closed.`);
    } else {
      const have = new Set(DB.countPeriods.map((p) => p.period)), y = TODAY.getFullYear();
      const opts = [`June ${y}`, `December ${y}`, `June ${y + 1}`, `December ${y + 1}`].filter((x) => !have.has(x));
      qs('#o-period').innerHTML = opts.map((o) => `<option>${o}</option>`).join('');
      const due = new Date(TODAY); due.setDate(due.getDate() + 30);
      qs('#o-due').value = due.toISOString().slice(0, 10);
      qs('#o-instr').value = DB.countPeriods[0].instructions || '';
      A.open('openModal');
    }
  });
  qs('#openForm').addEventListener('submit', (e) => {
    e.preventDefault();
    if (!A.validate(qs('#openForm'))) return;
    const name = qs('#o-period').value, id = 'PC-' + name.split(' ')[1] + '-' + (name.startsWith('June') ? '06' : '12');
    // Backend: POST /count/periods — the server creates one submission per teacher with assigned rooms.
    const p = { id, period: name, opensAt: TODAY.toISOString().slice(0, 10), dueAt: qs('#o-due').value, openedBy: ME, status: 'Open', instructions: qs('#o-instr').value.trim() };
    DB.countPeriods.push(p);
    const latest = [...DB.countPeriods].filter((x) => subsOf(x.id).length).sort((a, b) => b.opensAt.localeCompare(a.opensAt))[0];
    subsOf(latest.id).forEach((s, i) => DB.countSubmissions.push({ id: `PCS-${Date.now()}-${i}`, periodId: id, teacher: s.teacher, rooms: s.rooms, status: 'Not started', extras: [],
      lines: s.lines.map((l) => ({ ...l, found: null, condition: l.recCondition, remarks: '' })) }));
    periodId = id; page = 1;
    A.close('openModal'); renderAll(); A.toast(`${name} count opened. Teachers have been notified.`);
  });

  renderAll();
  const deep = new URLSearchParams(location.search).get('open');
  if (deep) openDrawer(deep);
})();
