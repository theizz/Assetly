<?php
/**
 * Placeholder logout. Wire this to your session teardown
 * (session_destroy(), clear cookies) and redirect to the login page.
 */
// session_start(); session_destroy();
header('Location: custodian_dashboard.php');
exit;
