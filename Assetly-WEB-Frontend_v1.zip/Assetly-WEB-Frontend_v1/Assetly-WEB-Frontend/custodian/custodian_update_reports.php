<?php
$pageTitle   = 'Update reports';
$pageSub     = 'Review add, relocation and deletion requests submitted by teachers.';
$active      = 'reports';
$pageScripts = ['update_reports.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <div class="kpi-row" style="flex:1" id="repKpis"></div>
</div>

<section class="card">
  <div class="card-b" style="padding-bottom:0">
    <div class="toolbar">
      <div class="input-icon grow">
        <svg class="i"><use href="#i-search"/></svg>
        <input class="input" id="q" type="search" placeholder="Search by asset, teacher or report ID">
      </div>
      <select class="select" id="fType"><option value="">All types</option><option>Add</option><option>Relocation</option><option>Delete</option><option>Other</option></select>
      <select class="select" id="fStatus"><option value="">All statuses</option><option>Pending</option><option>Approved</option><option>Rejected</option></select>
    </div>
  </div>
  <div class="card-b flush" style="margin-top:12px">
    <div class="table-wrap">
      <table class="table" id="repTable">
        <thead><tr><th>ID</th><th>Asset</th><th>Type</th><th class="text-right">Qty</th><th>Submitted by</th><th>Date</th><th>Status</th><th class="actions">Actions</th></tr></thead>
        <tbody id="repBody"></tbody>
      </table>
    </div>
    <div class="table-foot" id="repFoot"></div>
  </div>
</section>

<!-- Review drawer -->
<div class="drawer-backdrop" id="repDrawer" hidden>
  <div class="drawer" role="dialog" aria-modal="true" aria-labelledby="repTitle">
    <div class="drawer-h">
      <div><h2 id="repTitle">Update report</h2><div class="sub" id="repSub"></div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="drawer-b" id="repBodyDrawer"></div>
    <div class="drawer-f" id="repFootDrawer"></div>
  </div>
</div>

<!-- Reject reason modal -->
<div class="modal-backdrop" id="rejectModal" hidden>
  <div class="modal modal-sm" style="text-align:left;align-items:stretch" role="dialog" aria-modal="true" aria-labelledby="rejTitle">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
      <h3 id="rejTitle">Reason for rejection</h3>
      <button class="icon-btn sm" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="field">
      <textarea class="textarea" id="rejReason" data-required placeholder="Explain why this report is being rejected. The teacher will see this."></textarea>
      <span class="error">A reason is required.</span>
    </div>
    <div class="modal-actions" style="justify-content:flex-end;margin-top:14px">
      <button class="btn btn-secondary" data-close type="button">Cancel</button>
      <button class="btn btn-danger" id="rejConfirm" type="button">Confirm rejection</button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
