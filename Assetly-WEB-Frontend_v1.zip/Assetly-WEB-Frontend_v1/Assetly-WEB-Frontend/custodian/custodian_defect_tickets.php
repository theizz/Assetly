<?php
$pageTitle   = 'Defect tickets';
$pageSub     = 'Track damaged-equipment reports from teachers and move them toward resolution.';
$active      = 'tickets';
$pageScripts = ['defect_tickets.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <div class="kpi-row" style="flex:1" id="ticKpis"></div>
</div>

<section class="card">
  <div class="card-b" style="padding-bottom:0">
    <div class="toolbar">
      <div class="input-icon grow">
        <svg class="i"><use href="#i-search"/></svg>
        <input class="input" id="q" type="search" placeholder="Search by asset, teacher or ticket ID">
      </div>
      <select class="select" id="fStatus"><option value="">All statuses</option><option>Pending</option><option>Acknowledged</option><option>In progress</option><option>Resolved</option><option>Rejected</option></select>
      <select class="select" id="fBuilding"><option value="">All buildings</option></select>
    </div>
  </div>
  <div class="card-b flush" style="margin-top:12px">
    <div class="table-wrap">
      <table class="table" id="ticTable">
        <thead><tr><th>ID</th><th>Asset</th><th>Defect</th><th>Location</th><th>Reported by</th><th>Date</th><th>Status</th><th class="actions">Actions</th></tr></thead>
        <tbody id="ticBody"></tbody>
      </table>
    </div>
    <div class="table-foot" id="ticFoot"></div>
  </div>
</section>

<!-- Ticket drawer -->
<div class="drawer-backdrop" id="ticDrawer" hidden>
  <div class="drawer" role="dialog" aria-modal="true" aria-labelledby="ticTitle">
    <div class="drawer-h">
      <div><h2 id="ticTitle">Defect ticket</h2><div class="sub" id="ticSub"></div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="drawer-b" id="ticBodyDrawer"></div>
    <div class="drawer-f" id="ticFootDrawer"></div>
  </div>
</div>

<!-- Choose action modal -->
<div class="modal-backdrop" id="actionModal" hidden>
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="actTitle">
    <div class="modal-h">
      <div><h2 id="actTitle">Update ticket status</h2><div class="sub">The teacher who reported it will see the new status.</div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="modal-b">
      <div class="radio-list" id="actList"></div>
      <div class="field" id="actNoteField">
        <label for="actNote"><span id="actNoteLabel">Note</span> <span class="muted">(optional)</span></label>
        <textarea class="textarea" id="actNote" placeholder="Add context for the teacher and the activity log"></textarea>
        <span class="error">A reason is required to reject a ticket.</span>
      </div>
    </div>
    <div class="modal-f">
      <button class="btn btn-secondary" data-close type="button">Cancel</button>
      <button class="btn btn-primary" id="actConfirm" type="button">Confirm</button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
