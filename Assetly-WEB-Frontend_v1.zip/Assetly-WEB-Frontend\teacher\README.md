# Assetly — Teacher Interface

Frontend for the Teacher role, built from the "Teacher's Interface" UI/UX design
(Poppins, lavender canvas, blue pill navigation). Plain HTML/CSS/JS served as `.php`.

## Pages

| File | Purpose |
|------|---------|
| `teacher_home.php` | Greeting, status counts (In progress / Pending / Approved-Resolved / Rejected), physical-count banner, quick actions, recent reports |
| `teacher_my_assets.php` | **New.** Assets in the teacher's assigned rooms (what they are accountable for), with quick "Update" / "Defect" actions that prefill the forms |
| `teacher_physical_count.php` | **New.** Semi-annual count for the open period: count sheet per room (on record vs found, variance, condition, remarks), items found but not on record, autosaved draft, review + certification, submit to custodian, past counts |
| `teacher_report_update.php` | Report an Add / Relocation / Delete / Other update. Add shows **Asset source**; Relocation shows **Move to** building/room. Photo upload, review modal |
| `teacher_report_defect.php` | Report a defect (creates a maintenance ticket). Person responsible + role, photo, review modal |
| `teacher_my_reports.php` | Two tabs (update reports / maintenance tickets), status filter, detail panel with custodian reason and status timeline. `?tab=tickets&id=DT-0209` opens one directly |
| `logout.php` | Placeholder |

## Physical count rules (front-end)

- The custodian opens a period (`countPeriod` in `data.js`); each teacher counts their rooms.
- **Submit** is enabled only when every item has a "Found" quantity and every item with a
  difference has a remark. Extra (unrecorded) items need a name.
- Before submitting, the teacher reviews totals and all differences and ticks a certification.
- After submitting, the sheet is locked. "Withdraw to edit" is allowed until the custodian verifies.
- Draft/submission is kept in `localStorage` for the demo (`assetly.t.count.<period id>`).
  Replace with your API (see the comment at the top of `assets/js/physical_count.js`).

## Structure

```
includes/   header.php (head, icon sprite, mobile bar), sidebar.php, footer.php
assets/css/ teacher.css   — design tokens at the top
assets/js/  app.js        — helpers (window.T): dates, chips, toast, modal, validation, photo dropzone, storage
            data.js       — mock data (window.TDB); shapes match the custodian side
            <page>.js     — one script per page
assets/img/ assetly-logo.png, assetly-icon.png
```

## Wiring to the backend

- Set `$userName`, `$userRole`, `$userInitials` before including `includes/header.php`.
- Each submit handler has a `// Backend:` comment where the POST goes.
- Update reports and defect tickets use the same fields as the custodian's `reports` and
  `tickets`, so the custodian's Update reports / Defect tickets pages can read them as-is.
- Submitted counts are reviewed on the custodian side in `custodian/custodian_physical_count.php`
  (`countSubmissions` in the custodian `data.js` uses the same line fields). A "Returned" count
  carries a `returnReason` the teacher page should show once connected.
- The date "today" is fixed to Nov 16, 2026 in `app.js` (`TODAY`) so the demo countdown is
  stable — switch it to `new Date()` for production.
