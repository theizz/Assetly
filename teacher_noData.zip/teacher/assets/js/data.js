/* =========================================================================
   Assetly · Teacher data layer  (EMPTY — sample data removed)

   Every page reads from window.TDB. The record arrays start EMPTY so each page shows its layout,
   KPI cards (0) and "nothing here yet" states. Original demo records: _sample_data/teacher_data.sample.js
   and database/sample_data.sql.

   BACKEND: fill these from PHP (json_encode) or fetch(). Queries: database/queries.sql, sections starting
   with "TEACHER". Search the teacher scripts for  "CRUD:"  to find every place that must call the server.
   NOTE: drafts and room requests are currently kept in the browser (localStorage via T.store). Those spots
   are marked "CRUD:" - replace them with server calls; the database tables already exist in schema.sql.
   ========================================================================= */
window.TDB = (function () {

  /* the logged-in teacher. CRUD: take this from the PHP session (users table), not from this file. */
  const me = { id: '', name: 'Teacher', initials: 'T', role: 'Teacher', department: '', advisory: '' };

  /* ---- lookup lists (CRUD: categories / buildings tables, queries.sql -> "LOOKUPS"). Kept so forms and filters work. ---- */
  const categories = [
    'Furniture & Fixtures', 'Electronics & Appliances', 'Computer Lab Equipment', 'Science Lab Equipment',
    'TVL & Caregiving Equipment', 'SPA & Arts Equipment', 'Sports Equipment', 'Maintenance & Facility Tools', 'Books & Learning Materials'
  ];
  const buildings = [
    'Castelo Building I', 'Castelo Building II', 'Bautista Building I', 'Bautista Building II', 'Simon Building',
    'Vargas Building I', 'Vargas Building II', 'TVL Building', 'SB Building', 'Mathay Building', 'DPWH Building', 'S.P.E.D. Building',
    'Covered Court'
  ];
  const conditions = ['Operational', 'Under maintenance', 'Damaged', 'Missing', 'For disposal'];
  const updateTypes = ['Add', 'Relocation', 'Delete', 'Other'];
  const assetSources = ['Division Office', 'DepEd Central Office', 'LGU / School Board (SEF)', 'Purchased (MOOE)', 'Donation', 'Other'];
  const responsibleRoles = ['Student', 'Teacher', 'Non-teaching staff', 'Visitor', 'Unknown', 'Wear and tear (no one)'];
  const defectTypes = ['Broken', 'Not working', 'Overheating', 'Missing parts', 'Leaking', 'Electrical problem', 'Other'];


  const schoolYear = '2026-2027'; // CRUD: current school year setting (queries.sql -> "SETTINGS")
  const roomRoles = ['Adviser', 'Subject teacher', 'ICT Coordinator', 'Laboratory in-charge', 'Other'];
  const releaseReasons = ['Advisory / class ended', 'Transferred to another department or school', 'Room closed or reassigned', 'Other'];

  /* Rooms this teacher is accountable for (assigned by the custodian).
     shape: { building, room, role, since }      DB: room_assignments JOIN rooms/buildings WHERE teacher_id=:me AND released_at IS NULL */
  const rooms = []; // CRUD: queries.sql -> "TEACHER: MY ROOMS"

  /* Room requests the teacher sent to the custodian.
     shape: id, kind 'Request'|'Release', building, room, role (Request) or reason (Release), note,
     submittedAt, status 'Pending'|'Approved'|'Rejected', reason (custodian's answer)      DB: room_requests */
  const roomRequests = []; // CRUD: queries.sql -> "TEACHER: MY ROOM REQUESTS"

  /* Assigned asset shape: id, name, category, qty, building, room, condition, propertyNo, assignedAt
     DB: asset_units/assets in the teacher's rooms */
  const assets = []; // CRUD: queries.sql -> "TEACHER: MY ASSETS"

  /* Update report shape (same as custodian `reports`) + history[]:
     id, type 'Add'|'Relocation'|'Delete'|'Other', assetName, category, qty, building, room,
     newBuilding, newRoom (relocation), source (add), description, photo,
     submittedAt, status 'Pending'|'Approved'|'Rejected', reason, history[{status, at, note}]     DB: update_reports */
  const reports = []; // CRUD: queries.sql -> "TEACHER: MY UPDATE REPORTS"

  /* Defect ticket shape (same as custodian `tickets`):
     id, assetId, assetName, category, qty, building, room, defectType, description,
     personResponsible, personRole, photo, submittedAt,
     status 'Pending'|'Acknowledged'|'In progress'|'Resolved'|'Rejected', outcome, reason, history[]     DB: defect_tickets + ticket_history */
  const tickets = []; // CRUD: queries.sql -> "TEACHER: MY DEFECT TICKETS"

  /* Physical count. The custodian opens a period (semi-annual: June and December);
     each teacher counts the assets in their rooms and submits.
     countPeriod is null when no period is open (pages show a "no count open" state).
     shape: { id, period, opensAt, dueAt, openedBy, instructions }      DB: count_periods WHERE status='Open'
     Count line shape: { assetId, onRecord, found (number|null), condition, remarks }                  DB: count_lines
     Submission status: 'Not started' | 'Draft' | 'Submitted' | 'Verified' | 'Returned'               DB: count_submissions */
  const countPeriod = null; // CRUD: queries.sql -> "TEACHER: OPEN COUNT PERIOD"

  /* past submissions: { id, period, submittedAt, status, onRecord, found, missing, verifiedBy, note } */
  const pastCounts = []; // CRUD: queries.sql -> "TEACHER: PAST COUNTS"

  return { me, schoolYear, roomRoles, releaseReasons, roomRequests, categories, buildings, conditions, updateTypes, assetSources, responsibleRoles, defectTypes, rooms, assets, reports, tickets, countPeriod, pastCounts };
})();
