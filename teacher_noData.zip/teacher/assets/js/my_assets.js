/* 
   CRUD map for this page (search "CRUD:" below):
     READ    my rooms, my assets, my room requests -> queries.sql "TEACHER: MY ROOMS", "TEACHER: MY ASSETS", "TEACHER: MY ROOM REQUESTS"
     CREATE  room / release request                -> "TEACHER: CREATE ROOM REQUEST"
     UPDATE / DELETE  none (only the custodian decides)
*/
/* My assets: read-only list of assets in the teacher's assigned rooms, with quick report actions. */
(function () {
  const T = window.T, D = window.TDB, { qs, esc, int, condChip } = T;
  const roomKey = (a) => `${a.building}|${a.room}`;
  const openFor = (a) => D.tickets.filter((t) => t.assetId === a.id && !['Resolved', 'Rejected'].includes(t.status)).length
    + D.reports.filter((r) => r.assetName === a.name && r.room === a.room && r.status === 'Pending').length;

  const units = D.assets.reduce((n, a) => n + a.qty, 0);
  const attention = D.assets.filter((a) => a.condition !== 'Operational');
  window.T.kpiRow('#kpis', [
    { v: units, l: 'Items on record', sub: `${D.assets.length} asset lines`, ic: 'info', icon: 'i-layers' },
    { v: D.rooms.length, l: 'Assigned rooms', sub: D.rooms.map((r) => `${r.building.replace(' Building', '')} ${r.room}`).join(', '), ic: 'info', icon: 'i-map' },
    { v: D.assets.filter((a) => a.condition === 'Operational').reduce((n, a) => n + a.qty, 0), l: 'Operational', sub: 'Working items', ic: 'good', icon: 'i-check' },
    { v: attention.reduce((n, a) => n + a.qty, 0), l: 'Need attention', sub: 'Maintenance or disposal', ic: 'pending', icon: 'i-wrench' }
  ]);

  /* ---------- Assigned rooms + requests ---------- */
  const { date, store } = T;
  const REQ_KEY = 'roomRequests';
  let requests = store.get(REQ_KEY) || D.roomRequests.slice();     // Backend: GET /room-requests
  const unitsIn = (r) => D.assets.filter((a) => a.building === r.building && a.room === r.room).reduce((n, a) => n + a.qty, 0);
  const releasePending = (r) => requests.some((q) => q.kind === 'Release' && q.status === 'Pending' && q.building === r.building && q.room === r.room);
  const fillOptions = (sel, items) => items.forEach((v) => qs(sel).insertAdjacentHTML('beforeend', `<option>${esc(v)}</option>`));
  fillOptions('#rm-building', D.buildings); fillOptions('#rm-role', D.roomRoles); fillOptions('#rm-reason', D.releaseReasons);
  qs('#syText').textContent = D.schoolYear;

  function renderRooms() {
    qs('#roomGrid').innerHTML = D.rooms.map((r) => `
      <div class="room-card">
        <h3>${esc(r.building)} · Room ${esc(r.room)}</h3>
        <div class="role">${esc(r.role)}</div>
        <div class="meta">${int(unitsIn(r))} items · accountable since ${date(r.since)}</div>
        ${releasePending(r)
          ? '<span class="tag" style="background:var(--pending-bg);color:var(--pending);align-self:flex-start;margin-top:6px">Release requested</span>'
          : `<button class="btn btn-soft btn-sm" type="button" data-release="${esc(r.building + '|' + r.room)}">Request release</button>`}
      </div>`).join('') ||
      `<div class="empty" style="grid-column:1 / -1"><strong>No rooms assigned yet</strong>Request the room you handle. Once the custodian approves it, its assets appear on this page and in your physical count.</div>`;

    qs('#reqWrap').hidden = !requests.length;
    qs('#reqBody').innerHTML = [...requests].sort((a, b) => b.submittedAt.localeCompare(a.submittedAt)).map((q) => `
      <tr>
        <td>${q.kind === 'Release' ? 'Release room' : 'Request room'}</td>
        <td class="cell-main">${esc(q.building)} · ${esc(q.room)}</td>
        <td>${esc(q.kind === 'Release' ? q.role : q.role)}</td>
        <td class="num">${date(q.submittedAt)}</td>
        <td>${T.chip(q.status)}${q.reason ? `<span class="sub">${esc(q.reason)}</span>` : ''}</td>
      </tr>`).join('');
  }

  /* One modal serves both: "Request a room" and "Request release". */
  let mode = 'Request';
  function openRoomModal(kind, room) {
    mode = kind;
    const rel = kind === 'Release';
    qs('#roomForm').reset();
    qs('#roomForm').querySelectorAll('.has-error').forEach((f) => f.classList.remove('has-error'));
    qs('#roomModalTitle').textContent = rel ? 'Request release of a room' : 'Request a room';
    qs('#roomModalSub').textContent = rel ? 'Tell the custodian you are no longer handling this room.' : 'The custodian will review your request.';
    qs('#roleField').hidden = rel; qs('#reasonField').hidden = !rel;
    qs('#rm-building').disabled = qs('#rm-room').disabled = rel;
    if (rel) { qs('#rm-building').value = room.building; qs('#rm-room').value = room.room; }
    qs('#roomHint').textContent = rel
      ? 'Before you are released, the custodian may ask you to finish a physical count so the room is handed over with accurate records.'
      : 'If another teacher is already accountable for this room, the custodian will confirm with you before approving.';
    T.open('roomModal');
  }
  qs('#requestRoom').addEventListener('click', () => openRoomModal('Request'));
  qs('#roomGrid').addEventListener('click', (e) => {
    const b = e.target.closest('[data-release]'); if (!b) return;
    const [building, room] = b.dataset.release.split('|');
    openRoomModal('Release', D.rooms.find((r) => r.building === building && r.room === room));
  });

  qs('#roomForm').addEventListener('submit', (e) => {
    e.preventDefault();
    if (!T.validate(qs('#roomForm'))) return;
    const building = qs('#rm-building').value, room = qs('#rm-room').value.trim();
    if (mode === 'Request' && D.rooms.some((r) => r.building === building && r.room.toLowerCase() === room.toLowerCase())) { T.toast('This room is already assigned to you.', 'bad'); return; }
    if (requests.some((q) => q.kind === mode && q.status === 'Pending' && q.building === building && q.room.toLowerCase() === room.toLowerCase())) { T.toast('You already have a pending request for this room.', 'bad'); return; }
/* CRUD: CREATE a room request / release request (status Pending)
   endpoint : POST api/room_requests.php?action=create   { kind: 'Request'|'Release', building, room, role_or_reason, note }
   SQL      : INSERT INTO room_requests (kind, teacher_id, room_id, role, release_reason, note, status, submitted_at)
              VALUES (:kind,:me,:room_id,:role,:reason,:note,'Pending',NOW());   (queries.sql -> "TEACHER: CREATE ROOM REQUEST")
   The id (RM-0001 ...) must come from the database, not from requests.length. Await the response, then reload the list.  */
    requests.push({
      id: 'RM-' + String(requests.length + 15).padStart(4, '0'), kind: mode, building, room,
      role: mode === 'Request' ? qs('#rm-role').value : qs('#rm-reason').value,
      note: qs('#rm-note').value.trim(), submittedAt: new Date().toISOString(), status: 'Pending'
    });
    store.set(REQ_KEY, requests);                                    // Backend: POST /room-requests
    T.close('roomModal'); renderRooms();
    T.toast(mode === 'Request' ? 'Room request sent to the custodian.' : 'Release request sent to the custodian.');
  });
  renderRooms();

  D.rooms.forEach((r) => qs('#fRoom').insertAdjacentHTML('beforeend', `<option value="${esc(r.building + '|' + r.room)}">${esc(r.building.replace(' Building', ''))} ${esc(r.room)} · ${esc(r.role)}</option>`));
  [...new Set(D.assets.map((a) => a.condition))].forEach((c) => qs('#fCond').insertAdjacentHTML('beforeend', `<option>${esc(c)}</option>`));

  function render() {
    const q = qs('#q').value.trim().toLowerCase(), fr = qs('#fRoom').value, fc = qs('#fCond').value;
    const rows = D.assets.filter((a) => (!fr || roomKey(a) === fr) && (!fc || a.condition === fc) &&
      (!q || a.name.toLowerCase().includes(q) || a.id.toLowerCase().includes(q) || (a.propertyNo || '').includes(q)));
    qs('#body').innerHTML = rows.map((a) => {
      const open = openFor(a);
      return `<tr>
        <td><span class="cell-main">${esc(a.name)}</span><span class="sub num">${a.id}${a.propertyNo ? ' · PN ' + esc(a.propertyNo) : ''}</span></td>
        <td>${esc(a.category)}</td>
        <td class="text-right num">${int(a.qty)}</td>
        <td>${esc(a.building.replace(' Building', ''))} · ${esc(a.room)}</td>
        <td>${condChip(a.condition)}</td>
        <td>${open ? `<a href="teacher_my_reports.php"><span class="tag" style="background:var(--pending-bg);color:var(--pending)">${open} open</span></a>` : '<span class="muted">—</span>'}</td>
        <td class="text-right" style="white-space:nowrap">
          <a class="btn btn-soft btn-sm" href="teacher_report_update.php?asset=${a.id}" title="Report an update for this asset">Update</a>
          <a class="btn btn-soft btn-sm" href="teacher_report_defect.php?asset=${a.id}" title="Report a defect on this asset" style="background:var(--bad-bg);color:var(--bad)">Defect</a>
        </td>
      </tr>`;
    }).join('') || `<tr><td colspan="7"><div class="empty"><strong>No assets match</strong>Try another search or filter.</div></td></tr>`;
  }
  ['#q', '#fRoom', '#fCond'].forEach((s) => qs(s).addEventListener('input', render));
  render();
})();
