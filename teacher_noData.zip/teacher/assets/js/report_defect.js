/* 
   CRUD map for this page (search "CRUD:" below):
     READ    the asset picker (my assets)   -> queries.sql "TEACHER: MY ASSETS"
     CREATE  defect ticket                  -> "TEACHER: CREATE TICKET"
*/
/* report defect: creates a maintenance ticket after a review step */
(function () {
  const T = window.T,
    D = window.TDB,
    { qs, esc } = T;
  const form = qs("#defectForm");
  const fill = (sel, items) =>
    items.forEach((v) =>
      qs(sel).insertAdjacentHTML("beforeend", `<option>${esc(v)}</option>`),
    );
  fill("#d-category", D.categories);
  fill("#d-building", D.buildings);
  fill("#d-role", D.responsibleRoles);
  qs("#defectTypeList").innerHTML = D.defectTypes
    .map((t) => `<option value="${esc(t)}">`)
    .join("");

  let assetId = null;
  function prefill(a) {
    assetId = a.id;
    qs("#d-name").value = a.name;
    qs("#d-category").value = a.category;
    qs("#d-building").value = a.building;
    qs("#d-room").value = a.room;
    if (!qs("#d-qty").value) qs("#d-qty").value = 1;
  }
  qs("#d-name").addEventListener("change", () => {
    const a = D.assets.find((x) => x.name === qs("#d-name").value);
    assetId = null;
    if (a) prefill(a);
  });
  const fromQ = T.assetFromQuery();
  if (fromQ) prefill(fromQ);

  const idPhoto = T.dropzone(qs("#dzId"));
  const defectPhoto = T.dropzone(qs("#dzDefect"));
  let pending = null;

  /* a photo box turns red when no file was chosen. returns true when a file is there */
  function checkUpload(boxId, picker) {
    const missing = !picker.get();
    qs(boxId).classList.toggle("has-error", missing);
    return !missing;
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const fieldsOk = T.validate(form);
    const idOk = checkUpload("#idBox", idPhoto);
    const defectOk = checkUpload("#defectBox", defectPhoto);
    if (!fieldsOk || !idOk || !defectOk) {
      T.toast(
        "Please complete the highlighted fields and upload both photos.",
        "bad",
      );
      return;
    }
    pending = {
      assetId,
      assetName: qs("#d-name").value.trim(),
      category: qs("#d-category").value,
      qty: Number(qs("#d-qty").value),
      building: qs("#d-building").value,
      room: qs("#d-room").value.trim(),
      defectType: qs("#d-type").value.trim(),
      personResponsible: qs("#d-person").value.trim(),
      personRole: qs("#d-role").value,
      description: qs("#d-desc").value.trim(),
    };
    qs("#reviewBody").innerHTML = T.reviewHTML(
      [
        ["Asset name", pending.assetName],
        ["Category", pending.category],
        ["Building", pending.building.replace(" Building", "")],
        ["Room", pending.room],
        ["Quantity", pending.qty],
        ["Defect type", pending.defectType],
        ["Person Responsible", pending.personResponsible],
        ["Role of the person responsible", pending.personRole],
        ["Description", pending.description, true],
      ],
      [
        { label: "School ID photo", file: idPhoto.get() },
        { label: "Photo of the defect", file: defectPhoto.get() },
      ],
    );
    T.open("reviewModal");
  });

  qs("#reviewCancel").addEventListener("click", () => T.close("reviewModal"));
  qs("#reviewConfirm").addEventListener("click", () => {
/* CRUD: CREATE a defect ticket (status Pending) + its first history row
   endpoint : POST api/tickets.php?action=create   multipart/form-data: { asset_unit/asset_id, defect_type, description, person_responsible, person_role, id_photo, defect_photo }
   SQL      : INSERT INTO defect_tickets (asset_id, submitted_by, defect_type, description, person_responsible, person_role, photo, status, submitted_at) VALUES (...,'Pending',NOW());
              INSERT INTO ticket_history (ticket_id, status, at, by_user, note) VALUES (:id,'Pending',NOW(),:me,'Ticket submitted');
              INSERT INTO notifications (custodian)   (queries.sql -> "TEACHER: CREATE TICKET")
   Photos: move_uploaded_file() into an uploads/ folder and store only the file name. Await the response before form.reset().  */
    // backend: POST pending + both photos (idPhoto.get(), defectPhoto.get()) to your defect-ticket endpoint here
    T.close("reviewModal");
    T.toast(
      `Defect report submitted for ${pending.assetName}. You can track it in My reports.`,
    );
    form.reset();
    idPhoto.reset();
    defectPhoto.reset();
    assetId = null;
    pending = null;
  });
})();
