/* 
   CRUD map for this page (search "CRUD:" below):
     READ    open period + my lines                -> queries.sql "TEACHER: OPEN COUNT PERIOD", "TEACHER: COUNT LINES"
     CREATE/UPDATE  draft (autosave)               -> "TEACHER: SAVE COUNT DRAFT"
     UPDATE  submit / withdraw                     -> "TEACHER: SUBMIT COUNT"
     DELETE  none
*/
/* Physical count: the teacher counts assets in their assigned rooms for the open period,
   notes condition and differences, adds unrecorded items, then certifies and submits.
   The draft is kept in localStorage for this demo. Backend: replace store.* with
   GET/PUT /count/{period}/teacher/{id} and POST .../submit. */
(function () {
  const T = window.T, D = window.TDB, { qs, qsa, esc, int, date, dateTime, chip, store } = T;
  const P = D.countPeriod; // null when the custodian has not opened a count period
  if (!P) {
    qs('#periodTitle').textContent = 'No physical count is open';
    qs('#periodMeta').textContent = 'The Property Custodian has not opened a count period yet. You will be notified when one opens.';
    qs('#instrText').textContent = 'When a count opens, you will count the items in your assigned rooms on this page.';
    qs('#printBtn').disabled = true;
    return;
  }
  const KEY = 'count.' + P.id;
  const COUNT_CONDITIONS = ['Operational', 'Under maintenance', 'Damaged', 'For disposal'];

  /* ---------- State ---------- */
  const blank = () => ({
    status: 'Not started', savedAt: null, submittedAt: null, extras: [],
    lines: Object.fromEntries(D.assets.map((a) => [a.id, { found: null, condition: a.condition === 'For disposal' ? 'For disposal' : a.condition, remarks: '' }]))
  });
  let S = store.get(KEY) || blank();
  D.assets.forEach((a) => { if (!S.lines[a.id]) S.lines[a.id] = blank().lines[a.id]; });   // new assignments since draft
  const locked = () => S.status === 'Submitted';

  const isCounted = (id) => S.lines[id].found !== null && S.lines[id].found !== '';
  const variance = (a) => isCounted(a.id) ? Number(S.lines[a.id].found) - a.qty : null;

  function totals() {
    const onRecord = D.assets.reduce((n, a) => n + a.qty, 0);
    const counted = D.assets.filter((a) => isCounted(a.id));
    const found = counted.reduce((n, a) => n + Number(S.lines[a.id].found), 0);
    const short = counted.reduce((n, a) => n + Math.max(0, -variance(a)), 0);
    const over = counted.reduce((n, a) => n + Math.max(0, variance(a)), 0) + S.extras.reduce((n, x) => n + (Number(x.qty) || 0), 0);
    const condChanged = counted.filter((a) => S.lines[a.id].condition !== a.condition);
    return { onRecord, found, short, over, lines: D.assets.length, countedLines: counted.length, condChanged };
  }

  /* ---------- Header ---------- */
  qs('#periodTitle').textContent = `${P.period} physical count`;
  const left = T.daysUntil(P.dueAt);
  qs('#periodMeta').innerHTML = `
    <span><svg class="i i-sm"><use href="#i-calendar"/></svg> Opened ${date(P.opensAt)} by ${esc(P.openedBy)}</span>
    <span><svg class="i i-sm"><use href="#i-clock"/></svg> Due ${date(P.dueAt)} <b style="color:${left <= 7 ? 'var(--bad)' : 'var(--ink)'}">(${left} day${left === 1 ? '' : 's'} left)</b></span>
    <span><svg class="i i-sm"><use href="#i-map"/></svg> ${D.rooms.map((r) => `${esc(r.building.replace(' Building', ''))} ${esc(r.room)}`).join(', ')}</span>`;
  qs('#instrText').textContent = P.instructions;
  D.rooms.forEach((r) => qs('#fRoom').insertAdjacentHTML('beforeend', `<option value="${esc(r.building + '|' + r.room)}">${esc(r.building.replace(' Building', ''))} ${esc(r.room)}</option>`));

  /* ---------- Render ---------- */
  /* What is still needed before the count can be submitted. */
  function readiness() {
    const t = totals();
    const uncounted = t.lines - t.countedLines;
    const missingRemarks = D.assets.filter((a) => isCounted(a.id) && variance(a) !== 0 && !S.lines[a.id].remarks.trim()).length;
    return { t, uncounted, missingRemarks, ready: t.lines > 0 && uncounted === 0 && missingRemarks === 0 };
  }

  /* The 3 steps at the top of the page. The step you are on is highlighted. */
  const FLOW_STEPS = [
    ['Count your rooms', 'Enter what you actually see. Add anything that is not on the list.'],
    ['Submit to the custodian', 'Every item counted, with a remark for each difference.'],
    ['Custodian verifies', 'You are notified if anything is returned for correction.']
  ];
  function renderFlow(ready) {
    let current = 0;                                    // 0 = counting, 1 = ready to submit, 2 = waiting, 3 = all done
    if (S.status === 'Verified') current = 3;
    else if (S.status === 'Submitted') current = 2;
    else if (ready) current = 1;
    qs('#flow').innerHTML = FLOW_STEPS.map(([title, sub], i) => {
      const state = i < current ? 'done' : (i === current ? 'now' : '');
      const note = i === 0 && S.status === 'Returned' ? 'Returned by the custodian. Fix the marked items and submit again.' : sub;
      return `<li class="${state}"><span class="n">${i < current ? '&#10003;' : i + 1}</span><div><strong>${title}</strong><small>${note}</small></div></li>`;
    }).join('');
  }

  /* ---------- Header ---------- */
  function renderTop() {
    const { t, uncounted, missingRemarks, ready } = readiness();
    qs('#statusChip').innerHTML = chip(S.status);
    const pct = t.lines ? Math.round((t.countedLines / t.lines) * 100) : 0;
    qs('#progBar').style.width = pct + '%';
    qs('#progText').textContent = `${t.countedLines} of ${t.lines} items counted (${pct}%)`;
    qs('#savedText').textContent = S.submittedAt ? `Submitted ${dateTime(S.submittedAt)}` : (S.savedAt ? `Draft saved ${T.time(S.savedAt)}` : 'Not saved yet');
    qs('#stats').innerHTML = [
      { v: t.onRecord, l: 'Units on record', c: '' },
      { v: t.found, l: 'Units found so far', c: 'good' },
      { v: t.short, l: 'Short / missing', c: t.short ? 'bad' : '' },
      { v: t.over, l: 'Over / not on record', c: t.over ? 'warn' : '' }
    ].map((s) => `<div class="card stat ${s.c}"><div class="v num">${int(s.v)}</div><div class="l">${s.l}</div></div>`).join('');

    /* Action bar at the bottom of the screen */
    qs('#barTitle').textContent = locked() ? 'Count submitted' : `${t.countedLines} of ${t.lines} items counted`;
    qs('#submitBtn').disabled = locked() || !ready;
    qs('#submitBtn').hidden = locked();
    qs('#saveBtn').hidden = locked();
    qs('#submitHint').textContent = locked() ? '' :
      !D.rooms.length ? 'You have no assigned rooms yet. Request a room in My assets.' :
      uncounted ? `Count every item to unlock Submit (${uncounted} left).` :
      missingRemarks ? `Add a remark for each item with a difference (${missingRemarks} missing).` : 'Ready to submit.';
    qs('#jumpLeft').hidden = locked() || ready || !t.lines;
    qs('#jumpLeft').textContent = uncounted ? 'Show uncounted items' : 'Go to items that need a remark';

    qs('#addExtra').hidden = locked();
    qs('#lockedNote').hidden = !locked();
    qs('#instructions').hidden = locked();
    if (locked()) qs('#lockedText').innerHTML = `Submitted ${dateTime(S.submittedAt)}. The custodian will verify your count; you will be notified if it is returned for correction. <button class="btn btn-sm btn-outline" type="button" id="withdrawBtn" style="margin-left:6px">Withdraw to edit</button>`;
    renderFlow(ready);
  }

  function renderSheet() {
    const fr = qs('#fRoom').value, only = qs('#onlyOpen').checked, dis = locked() ? 'disabled' : '';
    const html = D.rooms.filter((r) => !fr || `${r.building}|${r.room}` === fr).map((r) => {
      const items = D.assets.filter((a) => a.building === r.building && a.room === r.room && (!only || !isCounted(a.id)));
      if (!items.length) return '';
      return `<tr class="room-h"><td colspan="6">${esc(r.building)} · Room ${esc(r.room)} <span class="muted" style="font-weight:400">· ${esc(r.role)}</span>
        ${locked() ? '' : `<button class="btn btn-soft btn-sm" type="button" data-fill="${esc(r.building + '|' + r.room)}">Mark all as found</button>`}</td></tr>` +
        items.map((a) => {
          const L = S.lines[a.id], v = variance(a);
          const cls = v === null ? '' : (v < 0 ? 'is-short' : (v > 0 ? 'is-over' : 'is-ok'));
          const vtxt = v === null ? '<span class="muted">—</span>' : `<span class="var ${v < 0 ? 'neg' : v > 0 ? 'pos' : 'zero'}">${v > 0 ? '+' : ''}${v}</span>`;
          return `<tr class="${cls}" data-id="${a.id}">
            <td><span class="cell-main">${esc(a.name)}</span><span class="sub num">${a.id}${a.propertyNo ? ' · PN ' + esc(a.propertyNo) : ''}</span></td>
            <td class="text-right num">${int(a.qty)}</td>
            <td class="w-found"><input class="input num" type="number" min="0" step="1" inputmode="numeric" data-k="found" value="${L.found ?? ''}" placeholder="0" aria-label="Found quantity for ${esc(a.name)}" ${dis}></td>
            <td class="text-right w-var" data-var>${vtxt}</td>
            <td class="w-cond"><select class="select" data-k="condition" aria-label="Condition of ${esc(a.name)}" ${dis}>${COUNT_CONDITIONS.map((c) => `<option${c === L.condition ? ' selected' : ''}>${c}</option>`).join('')}</select></td>
            <td><input class="input" data-k="remarks" value="${esc(L.remarks)}" placeholder="${v ? 'Required: explain the difference' : 'Optional'}" aria-label="Remarks for ${esc(a.name)}" ${dis}></td>
          </tr>`;
        }).join('');
    }).join('');
    qs('#sheet').innerHTML = html || (D.rooms.length
      ? `<tr><td colspan="6"><div class="empty"><strong>All items counted</strong>Uncheck "Show uncounted only" to see everything.</div></td></tr>`
      : `<tr><td colspan="6"><div class="empty"><strong>No rooms assigned yet</strong>Request a room in <a href="teacher_my_assets.php">My assets</a>. Once the custodian approves it, its assets show up here for counting.</div></td></tr>`);
  }

  function renderExtras() {
    const dis = locked() ? 'disabled' : '';
    const roomOpts = (sel) => D.rooms.map((r) => { const v = `${r.building.replace(' Building', '')} ${r.room}`; return `<option${v === sel ? ' selected' : ''}>${esc(v)}</option>`; }).join('');
    qs('#extras').innerHTML = S.extras.map((x, i) => `
      <tr data-x="${i}">
        <td><input class="input" data-xk="name" value="${esc(x.name)}" placeholder="e.g. Bookshelf, 5-tier" aria-label="Item name" ${dis}></td>
        <td style="width:90px"><input class="input num" type="number" min="1" data-xk="qty" value="${esc(x.qty)}" aria-label="Quantity" ${dis}></td>
        <td style="width:150px"><select class="select" data-xk="room" aria-label="Room" ${dis}>${roomOpts(x.room)}</select></td>
        <td><input class="input" data-xk="remarks" value="${esc(x.remarks)}" placeholder="Where did it come from?" aria-label="Remarks" ${dis}></td>
        <td style="width:44px">${locked() ? '' : `<button class="icon-btn" type="button" data-rm="${i}" aria-label="Remove item"><svg class="i"><use href="#i-x"/></svg></button>`}</td>
      </tr>`).join('') || `<tr><td colspan="5"><div class="empty" style="padding:18px">No extra items. Use <b>Add item</b> if you found something that is not on your list.</div></td></tr>`;
  }

  function renderHistory() {
    const rows = [...(locked() ? [{ period: P.period, submittedAt: S.submittedAt, status: 'Submitted', ...(() => { const t = totals(); return { onRecord: t.onRecord, found: t.found, missing: t.short }; })(), note: 'Awaiting verification' }] : []), ...D.pastCounts];
    qs('#history').innerHTML = rows.map((h) => `<tr>
      <td class="cell-main">${esc(h.period)}</td><td class="num">${date(h.submittedAt)}</td>
      <td class="text-right num">${int(h.onRecord)}</td><td class="text-right num">${int(h.found)}</td>
      <td class="text-right num">${h.missing ? `<span class="var neg">${int(h.missing)}</span>` : '0'}</td>
      <td>${chip(h.status)}</td><td class="muted">${esc(h.note)}</td></tr>`).join('');
  }

  const renderAll = () => { renderTop(); renderSheet(); renderExtras(); renderHistory(); };

  /* ---------- Saving ---------- */
  let saveTimer = null;
  function save(manual) {
    if (locked()) return;
    if (S.status === 'Not started') S.status = 'Draft';
    S.savedAt = new Date().toISOString();
/* CRUD: CREATE / UPDATE this teacher's count DRAFT (called on every autosave and on "Save draft")
   endpoint : PUT api/teacher_count.php   { period_id, lines: [ {unit_group_id, found, condition, remarks} ], extras: [...] }
   SQL      : INSERT INTO count_submissions (period_id, teacher_id, status, saved_at) VALUES (:p,:me,'Draft',NOW())
                ON DUPLICATE KEY UPDATE status='Draft', saved_at=NOW();
              then UPSERT count_lines (found, condition_status, remarks) and replace count_extras   (queries.sql -> "TEACHER: SAVE COUNT DRAFT")
   Until then the draft stays in this browser (localStorage) - it will NOT follow the teacher to another computer.  */
    const ok = store.set(KEY, S);
    renderTop();
    if (manual) T.toast(ok ? 'Draft saved. You can continue later.' : 'Could not save in this browser; keep this page open.', ok ? '' : 'bad');
  }
  const autosave = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => save(false), 600); };

  /* ---------- Events: count sheet ---------- */
  qs('#sheet').addEventListener('input', (e) => {
    const tr = e.target.closest('tr[data-id]'), k = e.target.dataset.k; if (!tr || !k) return;
    const a = D.assets.find((x) => x.id === tr.dataset.id), L = S.lines[a.id];
    if (k === 'found') {
      const raw = e.target.value.trim();
      L.found = raw === '' ? null : Math.max(0, Math.floor(Number(raw)));
      // Live variance + row tint without re-rendering (keeps focus while typing).
      const v = variance(a), cell = qs('[data-var]', tr);
      tr.classList.remove('is-short', 'is-over', 'is-ok');
      if (v !== null) tr.classList.add(v < 0 ? 'is-short' : v > 0 ? 'is-over' : 'is-ok');
      cell.innerHTML = v === null ? '<span class="muted">—</span>' : `<span class="var ${v < 0 ? 'neg' : v > 0 ? 'pos' : 'zero'}">${v > 0 ? '+' : ''}${v}</span>`;
      qs('[data-k="remarks"]', tr).placeholder = v ? 'Required: explain the difference' : 'Optional';
    } else L[k] = e.target.value;
    autosave(); renderTop();
  });
  qs('#sheet').addEventListener('click', (e) => {
    const b = e.target.closest('[data-fill]'); if (!b) return;
    const [bld, room] = b.dataset.fill.split('|');
    D.assets.filter((a) => a.building === bld && a.room === room && !isCounted(a.id)).forEach((a) => { S.lines[a.id].found = a.qty; });
    save(false); renderSheet(); T.toast(`Uncounted items in ${room} set to their recorded quantity. Adjust any that differ.`);
  });
  qs('#fRoom').addEventListener('change', renderSheet);
  qs('#onlyOpen').addEventListener('change', renderSheet);

  /* ---------- Events: extras ---------- */
  qs('#addExtra').addEventListener('click', () => {
    const r = D.rooms[0];
    S.extras.push({ name: '', qty: 1, room: r ? `${r.building.replace(' Building', '')} ${r.room}` : '', remarks: '' });
    renderExtras(); autosave(); renderTop();
    const inputs = qsa('#extras [data-xk="name"]'); inputs[inputs.length - 1].focus();
  });
  qs('#extras').addEventListener('input', (e) => {
    const tr = e.target.closest('tr[data-x]'), k = e.target.dataset.xk; if (!tr || !k) return;
    S.extras[Number(tr.dataset.x)][k] = k === 'qty' ? Math.max(1, Math.floor(Number(e.target.value) || 1)) : e.target.value;
    autosave(); renderTop();
  });
  qs('#extras').addEventListener('click', (e) => {
    const b = e.target.closest('[data-rm]'); if (!b) return;
    S.extras.splice(Number(b.dataset.rm), 1); renderExtras(); autosave(); renderTop();
  });

  qs('#saveBtn').addEventListener('click', () => save(true));

  /* "Show what is left": jumps to the first item that still blocks Submit. */
  qs('#jumpLeft').addEventListener('click', () => {
    if (D.assets.some((a) => !isCounted(a.id))) {
      qs('#onlyOpen').checked = true; renderSheet();                      // show only uncounted items
      const first = qs('#sheet [data-k="found"]'); if (first) first.focus();
    } else {
      const need = D.assets.find((a) => variance(a) !== 0 && !S.lines[a.id].remarks.trim());
      qs('#onlyOpen').checked = false; renderSheet();
      const box = need && qs(`tr[data-id="${need.id}"] [data-k="remarks"]`); if (box) box.focus();
    }
  });

  /* ---------- Print count sheet: formal template, built automatically from the data ---------- */
  const SCHOOL_NAME = 'Lagro High School';
  const DIVISION_NAME = 'Schools Division Office of Quezon City';
  const FORM_TITLE = 'PHYSICAL COUNT SHEET OF SCHOOL PROPERTY';
  const DEPED_LOGO = '';                        // e.g. 'assets/img/deped-logo.png' (leave '' for no logo)
  const SCHOOL_LOGO = '';                       // e.g. 'assets/img/school-logo.png'
  const PRINT_SHOW_ON_RECORD = true;            // false = "blind" sheet: the quantity on record is not printed
  const EXTRA_BLANK_ROWS = 5;                   // empty lines for items found but not on the list
  document.body.classList.add('print-count');   // tells the print CSS to print ONLY the sheet

  const printLogo = (src) => src ? `<img src="${esc(src)}" alt="">` : '';
  const signed = (n) => (n > 0 ? '+' : '') + n;  // 2 -> +2, -1 -> -1, 0 -> 0

  /* One row per asset. What the teacher already typed is printed; the rest stays blank for pen. */
  function printAssetRow(a, number) {
    const L = S.lines[a.id], counted = isCounted(a.id), v = variance(a);
    const conditions = COUNT_CONDITIONS.map((c) => `<span>${counted && L.condition === c ? '&#9746;' : '&#9744;'} ${esc(c)}</span>`).join('');
    return `<tr>
      <td class="c">${number}</td>
      <td>${esc(a.category)}</td>
      <td>${esc(a.name)}<span class="sub">Asset ID ${esc(a.id)}</span></td>
      <td>${esc(a.propertyNo)}</td>
      ${PRINT_SHOW_ON_RECORD ? `<td class="c">${int(a.qty)}</td>` : ''}
      <td class="c">${counted ? int(L.found) : ''}</td>
      <td class="c">${v === null ? '' : signed(v)}</td>
      <td><div class="ps-cond">${conditions}</div></td>
      <td>${esc(L.remarks)}</td>
    </tr>`;
  }

  /* Total row: the counted totals only appear when every item in the room has been counted. */
  function printTotalRow(items) {
    const allCounted = items.every((a) => isCounted(a.id));
    const onRecord = items.reduce((n, a) => n + a.qty, 0);
    const found = items.reduce((n, a) => n + (isCounted(a.id) ? Number(S.lines[a.id].found) : 0), 0);
    return `<tr class="ps-total">
      <td colspan="4" class="r">TOTAL</td>
      ${PRINT_SHOW_ON_RECORD ? `<td class="c">${int(onRecord)}</td>` : ''}
      <td class="c">${allCounted ? int(found) : ''}</td>
      <td class="c">${allCounted ? signed(found - onRecord) : ''}</td>
      <td colspan="2"></td>
    </tr>`;
  }

  /* One section per assigned room (each starts on a new page). */
  function printRoomSection(room) {
    const items = D.assets.filter((a) => a.building === room.building && a.room === room.room);
    if (!items.length) return '';
    return `<section class="ps-room">
      <div class="ps-run">${esc(P.period)} · ${esc(D.me.name)} · Count ID ${esc(P.id)}-${esc(D.me.id)}</div>
      <h2>Location: ${esc(room.building)}, Room ${esc(room.room)} <span>· ${esc(room.role)}</span></h2>
      <table class="ps-table">
        <thead><tr>
          <th class="c" style="width:4%">No.</th><th style="width:12%">Article</th><th style="width:21%">Description</th><th style="width:10%">Property No.</th>
          ${PRINT_SHOW_ON_RECORD ? '<th class="c" style="width:7%">Qty per record</th>' : ''}
          <th class="c" style="width:7%">Qty per count</th><th class="c" style="width:8%">Short (-) / Over (+)</th><th style="width:17%">Condition</th><th>Remarks</th>
        </tr></thead>
        <tbody>${items.map((a, i) => printAssetRow(a, i + 1)).join('')}${printTotalRow(items)}</tbody>
      </table>
    </section>`;
  }

  /* Items found but not on the list, then the certification and signatures. */
  function printClosingSection() {
    const rows = S.extras.map((x) => `<tr><td>${esc(x.name)}</td><td class="c">${int(x.qty)}</td><td>${esc(x.room)}</td><td>${esc(x.remarks)}</td></tr>`);
    for (let i = rows.length; i < EXTRA_BLANK_ROWS; i++) rows.push('<tr><td></td><td></td><td></td><td></td></tr>');
    return `<section class="ps-extra">
      <div class="ps-run">${esc(P.period)} · ${esc(D.me.name)} · Count ID ${esc(P.id)}-${esc(D.me.id)}</div>
      <h2>Items found in the room but not on the property list</h2>
      <table class="ps-table">
        <thead><tr><th>Item name</th><th class="c" style="width:9%">Qty</th><th style="width:20%">Room</th><th style="width:36%">Remarks / where it came from</th></tr></thead>
        <tbody>${rows.join('')}</tbody>
      </table>
      <p class="ps-cert">I certify that I physically counted the items listed in this sheet in the rooms assigned to me, and that this count is true and correct.</p>
      <div class="ps-sign">
        <div><span class="role">Counted and certified correct by:</span><div class="who"><b>${esc(D.me.name)}</b>Teacher · Signature over printed name<br>Date: ________________</div></div>
        <div><span class="role">Verified by:</span><div class="who"><b>${esc(P.openedBy)}</b>Property Custodian<br>Date: ________________</div></div>
        <div><span class="role">Noted by:</span><div class="who"><b>&nbsp;</b>School Head<br>Date: ________________</div></div>
      </div>
      <div class="ps-foot">Generated by Assetly · ${dateTime(new Date().toISOString())} · Count ID ${esc(P.id)}-${esc(D.me.id)}</div>
    </section>`;
  }

  /* Builds the whole sheet. Runs before every print, so it is always up to date. */
  function buildPrintSheet() {
    let sheet = qs('#printSheet');
    if (!sheet) { sheet = document.createElement('div'); sheet.id = 'printSheet'; document.body.appendChild(sheet); }
    sheet.innerHTML = `
      <header class="ps-head">
        <div class="ps-logo">${printLogo(DEPED_LOGO)}</div>
        <div class="ps-title">
          <div class="gov">Republic of the Philippines<br><b>Department of Education</b><br>${esc(DIVISION_NAME)}</div>
          <div class="school">${esc(SCHOOL_NAME)}</div>
          <h1>${esc(FORM_TITLE)}</h1>
          <div class="sub">Semi-annual count · ${esc(P.period)}</div>
        </div>
        <div class="ps-logo">${printLogo(SCHOOL_LOGO)}</div>
      </header>
      <p class="ps-account">For which <b>${esc(D.me.name)}</b>, Teacher (${esc(D.me.department)} · ${esc(D.me.advisory)}), <b>${esc(SCHOOL_NAME)}</b>,
        is accountable, having assumed such accountability on ____________________.</p>
      <div class="ps-meta">
        <div><b>Rooms:</b> ${D.rooms.map((r) => esc(r.building) + ' · ' + esc(r.room)).join('; ')}</div>
        <div><b>Count period:</b> ${date(P.opensAt)} to ${date(P.dueAt)}</div>
        <div><b>Date counted:</b> ____________________</div>
      </div>
      ${D.rooms.map(printRoomSection).join('')}
      ${printClosingSection()}`;
  }

  window.addEventListener('beforeprint', buildPrintSheet);                 // also covers Ctrl+P
  qs('#printBtn').addEventListener('click', () => { buildPrintSheet(); window.print(); });

  /* ---------- Submit ---------- */
  qs('#submitBtn').addEventListener('click', () => {
    const blankExtra = S.extras.findIndex((x) => !x.name.trim());
    if (blankExtra > -1) { T.toast('Give every extra item a name, or remove it.', 'bad'); qsa('#extras [data-xk="name"]')[blankExtra].focus(); return; }
    const t = totals();
    qs('#submitSummary').innerHTML = [
      ['Period', P.period], ['Rooms', D.rooms.map((r) => `${r.building.replace(' Building', '')} ${r.room}`).join(', ')],
      ['Units on record', int(t.onRecord)], ['Units found', int(t.found)],
      ['Short / missing', int(t.short)], ['Over / not on record', int(t.over)]
    ].map(([l, v]) => `<div><dt>${l}</dt><dd>${esc(v)}</dd></div>`).join('');
    const diffs = D.assets.filter((a) => variance(a) !== 0 || S.lines[a.id].condition !== a.condition);
    const diffRows = diffs.map((a) => {
      const v = variance(a), L = S.lines[a.id];
      const what = [v ? `<span class="var ${v < 0 ? 'neg' : 'pos'}">${v > 0 ? '+' : ''}${v}</span>` : '', L.condition !== a.condition ? `${esc(a.condition)} → <b>${esc(L.condition)}</b>` : ''].filter(Boolean).join(' · ');
      return `<tr><td class="cell-main">${esc(a.name)}<span class="sub">${esc(a.room)}</span></td><td>${what}</td><td class="muted">${esc(L.remarks) || '—'}</td></tr>`;
    }).concat(S.extras.map((x) => `<tr><td class="cell-main">${esc(x.name)}<span class="sub">${esc(x.room)}</span></td><td><span class="var pos">+${int(x.qty)}</span> not on record</td><td class="muted">${esc(x.remarks) || '—'}</td></tr>`));
    qs('#submitDiffs').innerHTML = diffRows.length
      ? `<div class="label" style="margin-bottom:6px">Differences to be reviewed (${diffRows.length})</div><div class="table-wrap" style="max-height:220px;overflow:auto;border:1px solid var(--line);border-radius:10px;background:#fff"><table class="table"><thead><tr><th>Item</th><th>Change</th><th>Remarks</th></tr></thead><tbody>${diffRows.join('')}</tbody></table></div>`
      : `<div class="reason good" style="margin:0;min-height:0"><b>No differences.</b> Everything on record was found in the same condition.</div>`;
    qs('#certify').checked = false; qs('#confirmSubmit').disabled = true;
    T.open('submitModal');
  });
  qs('#certify').addEventListener('change', (e) => { qs('#confirmSubmit').disabled = !e.target.checked; });
  qs('#confirmSubmit').addEventListener('click', () => {
    if (qs('#submitBtn').disabled || !qs('#certify').checked) { T.close('submitModal'); return; }   // re-check: complete + certified
/* CRUD: UPDATE the submission -> SUBMIT to the custodian
   endpoint : POST api/teacher_count_submit.php   { period_id, certified: true }   (save lines/extras first, see the draft note above)
   SQL      : UPDATE count_submissions SET status='Submitted', submitted_at=NOW(), certified=1 WHERE period_id=:p AND teacher_id=:me AND status IN ('Draft','Returned','Not started');
              INSERT INTO notifications (custodian)   (queries.sql -> "TEACHER: SUBMIT COUNT")  */
    // Backend: POST the lines + extras for P.id here.
    S.status = 'Submitted'; S.submittedAt = new Date().toISOString();
    store.set(KEY, S); T.close('submitModal'); renderAll();
    T.toast('Physical count submitted to the Property Custodian.');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#withdrawBtn')) return;
/* CRUD: UPDATE the submission -> WITHDRAW (back to Draft). Only allowed while status = 'Submitted' (not yet verified).
   endpoint : POST api/teacher_count_withdraw.php   { period_id }
   SQL      : UPDATE count_submissions SET status='Draft', submitted_at=NULL WHERE period_id=:p AND teacher_id=:me AND status='Submitted';  */
    S.status = 'Draft'; S.submittedAt = null; store.set(KEY, S); renderAll();
    T.toast('Submission withdrawn. You can edit and submit again.');
  });

  renderAll();
})();
