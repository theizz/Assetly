/* Dashboard page: derives every figure from window.DB so the UI matches the data. */
(function () {
  const A = window.Assetly, DB = window.DB;
  const active = DB.assets.filter((a) => a.condition !== 'For disposal');

  const sumQty = (list, pred = () => true) => list.reduce((n, a) => n + (pred(a) ? a.qty : 0), 0);
  const total   = sumQty(DB.assets);
  const oper    = sumQty(DB.assets, (a) => a.condition === 'Operational');
  const maint   = sumQty(DB.assets, (a) => a.condition === 'Under maintenance');
  const storage = sumQty(DB.assets, (a) => a.condition === 'In storage');

  /* KPIs */
  const kpis = [
    { v: A.int(total),   l: 'Total assets',       d: DB.assets.length + ' records', ic: 'brand',   icon: 'i-layers' },
    { v: A.int(oper),    l: 'Operational',        d: Math.round(oper / total * 100) + '% of assets', ic: 'good', icon: 'i-check-circle' },
    { v: A.int(maint),   l: 'Under maintenance',  d: DB.tickets.filter((t) => ['Pending', 'Acknowledged', 'In progress'].includes(t.status)).length + ' open tickets', ic: 'warn', icon: 'i-wrench' },
    { v: A.int(storage), l: 'In storage',         d: 'Not yet issued', ic: 'neutral', icon: 'i-archive' }
  ];
  A.qs('#kpiRow').innerHTML = kpis.map((k) => `
    <div class="kpi">
      <div><div class="v num">${k.v}</div><div class="l">${k.l}</div><div class="d">${k.d}</div></div>
      <div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div>
    </div>`).join('');

  /* Deliveries: delivered (expected) vs actual (received) across posted/counted deliveries */
  const counted = DB.deliveries.filter((d) => d.status !== 'Logged');
  const expected = counted.reduce((n, d) => n + d.items.reduce((s, i) => s + (i.expected || 0), 0), 0);
  const received = counted.reduce((n, d) => n + d.items.reduce((s, i) => s + (i.received || 0), 0), 0);
  const damaged  = counted.reduce((n, d) => n + d.items.reduce((s, i) => s + (i.damaged || 0), 0), 0);
  const variance = received - expected;
  A.qs('#dlvStats').innerHTML = `
    <div class="pair-stat"><small class="muted">Delivered (on paper)</small><div class="v num">${A.int(expected)}</div><div class="sub">expected units</div></div>
    <div class="pair-stat"><small class="muted">Actual received</small><div class="v num">${A.int(received)}</div><div class="sub">counted on hand</div></div>
    <div class="pair-stat ${variance < 0 ? 'bad' : 'good'}"><small class="muted">Variance</small><div class="v num">${variance > 0 ? '+' : ''}${A.int(variance)}</div><div class="sub">${A.int(damaged)} damaged</div></div>`;

  const recentDlv = [...DB.deliveries].sort((a, b) => b.dateDelivered.localeCompare(a.dateDelivered)).slice(0, 4);
  A.qs('#dlvList').innerHTML = recentDlv.map((d) => {
    const exp = d.items.reduce((s, i) => s + (i.expected || 0), 0);
    const rec = d.items.reduce((s, i) => s + (i.received || 0), 0);
    const pct = d.status === 'Logged' ? 0 : Math.round(rec / exp * 100);
    const tone = d.status === 'Logged' ? '' : rec < exp ? 'warn' : 'good';
    return `<div class="dlv-row">
      <div><div class="t">${A.esc(d.source)}</div><div class="s">${d.ref} · ${A.date(d.dateDelivered)}</div></div>
      <div><div class="progress ${tone}"><span style="width:${pct}%"></span></div></div>
      <div class="q">${d.status === 'Logged' ? A.statusChip('Logged') : `<b>${A.int(rec)}</b><span class="muted">/${A.int(exp)}</span>`}</div>
    </div>`;
  }).join('');

  /* Assets by category (operational units) */
  const byCat = {};
  active.forEach((a) => { if (a.condition === 'Operational') byCat[a.category] = (byCat[a.category] || 0) + a.qty; });
  const cats = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
  const maxCat = Math.max(...cats.map((c) => c[1]), 1);
  A.qs('#catBars').innerHTML = cats.map(([name, n]) => `
    <div class="bar-row">
      <div class="bl">${A.esc(name)}</div>
      <div class="bt" title="${A.int(n)} units"><span style="width:${Math.max(3, n / maxCat * 100)}%"></span></div>
      <div class="bv num">${A.int(n)}</div>
    </div>`).join('');

  /* Physical count reconciliation */
  const pc = DB.physicalCount;
  const rec = pc.rows.reduce((o, r) => { o.onRecord += r.onRecord; o.onHand += r.onHand; o.short += r.short; o.over += r.over; return o; }, { onRecord: 0, onHand: 0, short: 0, over: 0 });
  const matchPct = Math.round((1 - (rec.short + rec.over) / rec.onRecord) * 100);
  A.qs('#reconSub').textContent = `Last count: ${pc.period} (as of ${A.date(pc.asOf)}).`;
  A.qs('#reconPct').textContent = matchPct + '%';
  A.qs('#reconNext').textContent = pc.nextDue;
  A.qs('#reconTable').innerHTML = `
    <thead><tr><th>Building</th><th class="text-right">On record</th><th class="text-right">On hand</th><th class="text-right">Short</th><th class="text-right">Over</th></tr></thead>
    <tbody>${pc.rows.map((r) => `<tr>
      <td>${A.esc(r.building)}</td>
      <td class="text-right num">${A.int(r.onRecord)}</td>
      <td class="text-right num">${A.int(r.onHand)}</td>
      <td class="text-right num ${r.short ? 'text-danger' : 'muted'}">${r.short || '—'}</td>
      <td class="text-right num ${r.over ? 'text-warn' : 'muted'}">${r.over || '—'}</td>
    </tr>`).join('')}
    <tr style="font-weight:600"><td>Total</td><td class="text-right num">${A.int(rec.onRecord)}</td><td class="text-right num">${A.int(rec.onHand)}</td><td class="text-right num text-danger">${A.int(rec.short)}</td><td class="text-right num text-warn">${A.int(rec.over)}</td></tr>
    </tbody>`;

  /* Activity log */
  A.qs('#activityTable tbody').innerHTML = DB.activity.map((e) => `
    <tr><td class="muted" style="white-space:nowrap">${A.dateTime(e.at)}</td>
    <td class="cell-main">${A.esc(e.event)}</td>
    <td>${A.esc(e.user)}</td>
    <td class="wrap muted">${A.esc(e.details)}</td></tr>`).join('');

  /* Needs attention */
  const pendingReports = DB.reports.filter((r) => r.status === 'Pending').length;
  const openTickets = DB.tickets.filter((t) => ['Pending', 'Acknowledged', 'In progress'].includes(t.status)).length;
  const toCount = DB.deliveries.filter((d) => d.status === 'Logged').length;
  const toPost  = DB.deliveries.filter((d) => d.status === 'Counted').length;
  const attn = [
    { t: 'Deliveries to count', s: 'Awaiting physical count', n: toCount, href: 'custodian_deliveries.php', ic: 'info', icon: 'i-truck', hot: toCount > 0 },
    { t: 'Deliveries to post', s: 'Counted, not yet in inventory', n: toPost, href: 'custodian_deliveries.php', ic: 'neutral', icon: 'i-archive', hot: toPost > 0 },
    { t: 'Pending update reports', s: 'Submitted by teachers', n: pendingReports, href: 'custodian_update_reports.php', ic: 'warn', icon: 'i-file', hot: pendingReports > 0 },
    { t: 'Open defect tickets', s: 'Not yet resolved', n: openTickets, href: 'custodian_defect_tickets.php', ic: 'bad', icon: 'i-wrench', hot: openTickets > 0 }
  ];
  A.qs('#attnList').innerHTML = attn.map((a) => `
    <a href="${a.href}">
      <span class="attn-ic ${a.ic}"><svg class="i"><use href="#${a.icon}"/></svg></span>
      <span><span class="attn-t">${a.t}</span><br><span class="attn-s">${a.s}</span></span>
      <span class="n ${a.hot ? 'hot' : ''}">${a.n}</span>
    </a>`).join('');

  /* AI recommendations */
  A.qs('#recoList').innerHTML = DB.recommendations.map((r) => `
    <div class="reco-item">
      <div class="reco-top"><span class="priority ${r.level}">${r.level[0].toUpperCase() + r.level.slice(1)}</span><a href="${r.link}">${r.linkText}</a></div>
      <p>${A.esc(r.title)}</p>
      <small class="muted">${A.esc(r.why)}</small>
    </div>`).join('');
})();
