/* Assets page: filter + sort + paginate the asset table, plus view / import / export. */
(function () {
  const A = window.Assetly, DB = window.DB;
  let rows = [...DB.assets];
  let sortKey = 'id', sortDir = 'asc', page = 1;
  const perPage = 10;

  /* KPIs above the table */
  const sumQty = (p) => DB.assets.reduce((n, a) => n + (p(a) ? a.qty : 0), 0);
  A.qs('#assetKpis').innerHTML = [
    { v: sumQty(() => true), l: 'Total', ic: 'brand', icon: 'i-layers' },
    { v: sumQty((a) => a.condition === 'Operational'), l: 'Operational', ic: 'good', icon: 'i-check-circle' },
    { v: sumQty((a) => a.condition === 'Under maintenance'), l: 'Maintenance', ic: 'warn', icon: 'i-wrench' },
    { v: sumQty((a) => a.condition === 'For disposal'), l: 'For disposal', ic: 'bad', icon: 'i-trash' }
  ].map((k) => `<div class="kpi"><div><div class="v num">${A.int(k.v)}</div><div class="l">${k.l}</div></div><div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div></div>`).join('');

  /* Populate filter dropdowns */
  const fill = (sel, items) => { const el = A.qs(sel); items.forEach((i) => el.insertAdjacentHTML('beforeend', `<option>${A.esc(i)}</option>`)); };
  fill('#fBuilding', DB.buildings); fill('#fCategory', DB.categories); fill('#fCondition', DB.conditions); fill('#fFund', DB.fundSources);

  /* Filtering */
  function apply() {
    const q = A.qs('#q').value.trim().toLowerCase();
    const fb = A.qs('#fBuilding').value, fc = A.qs('#fCategory').value, fcon = A.qs('#fCondition').value, ff = A.qs('#fFund').value;
    rows = DB.assets.filter((a) =>
      (!q || a.name.toLowerCase().includes(q) || a.id.toLowerCase().includes(q) || (a.propertyNo || '').toLowerCase().includes(q) || a.units.some((u) => u.toLowerCase().includes(q))) &&
      (!fb || a.building === fb) && (!fc || a.category === fc) && (!fcon || a.condition === fcon) && (!ff || a.fundSource === ff)
    );
    rows = A.sortBy(rows, sortKey, sortDir);
    page = 1; render();
  }

  function render() {
    const body = A.qs('#assetBody');
    const start = (page - 1) * perPage;
    const slice = rows.slice(start, start + perPage);
    if (!slice.length) {
      body.innerHTML = `<tr><td colspan="11"><div class="empty"><svg class="i"><use href="#i-search"/></svg><strong>No assets match your filters</strong>Try clearing the search or a filter.</div></td></tr>`;
    } else {
      body.innerHTML = slice.map((a) => `
        <tr>
          <td class="check"><input type="checkbox" value="${a.id}" aria-label="Select ${A.esc(a.name)}"></td>
          <td><span class="id-cell"><span class="id num">${a.id}</span>${a.qty > 1 ? `<span class="tag mono">+${a.qty - 1}</span>` : ''}</span></td>
          <td class="cell-main">${A.esc(a.name)}${a.openTickets ? ` <span class="tag" style="background:var(--bad-bg);color:var(--bad)">${a.openTickets} open</span>` : ''}</td>
          <td>${A.esc(a.category)}</td>
          <td class="text-right num">${a.qty}</td>
          <td>${A.esc(a.building)}<span class="cell-sub">Room ${A.esc(a.room)}</span></td>
          <td class="num">${A.date(a.dateAcquired)}</td>
          <td class="text-right num">${A.money(a.unitValue)}</td>
          <td><span class="tag">${A.esc(a.fundSource)}</span></td>
          <td>${A.conditionChip(a.condition)}</td>
          <td class="actions"><div class="row-actions">
            <button class="icon-btn sm brand" data-view="${a.id}" aria-label="View"><svg class="i"><use href="#i-eye"/></svg></button>
            <a class="icon-btn sm brand" href="custodian_add_asset.php?edit=${a.id}" aria-label="Edit"><svg class="i"><use href="#i-pencil"/></svg></a>
            <button class="icon-btn sm danger" data-del="${a.id}" aria-label="Move to trash"><svg class="i"><use href="#i-trash"/></svg></button>
          </div></td>
        </tr>`).join('');
    }
    A.pager({ el: A.qs('#assetFoot'), total: rows.length, page, perPage, onPage: (p) => { page = p; render(); } });
    sel.update();
    A.qsa('#assetTable thead th.sortable').forEach((th) => {
      th.classList.remove('sorted-asc', 'sorted-desc');
      if (th.dataset.sort === sortKey) th.classList.add(sortDir === 'asc' ? 'sorted-asc' : 'sorted-desc');
    });
  }

  /* Selection + bulk bar */
  const sel = A.selection({ table: A.qs('#assetTable'), bulkbar: A.qs('#bulkbar'), countEl: A.qs('#bulkCount') });
  A.qs('#bulkClear').addEventListener('click', () => sel.clear());
  A.qs('#bulkDelete').addEventListener('click', async () => {
    const ids = sel.selected(); if (!ids.length) return;
    const ok = await A.confirm({ title: `Move ${ids.length} asset${ids.length > 1 ? 's' : ''} to trash?`, text: 'Trashed assets can be restored from the Trash page. Any open tickets or reports on them will be cancelled.', okLabel: 'Move to trash', tone: 'bad' });
    if (ok) { A.toast(`${ids.length} asset${ids.length > 1 ? 's' : ''} moved to trash.`); sel.clear(); }
  });
  A.qs('#bulkExport').addEventListener('click', () => openExport(sel.selected().length));

  /* Row actions (delegated) */
  A.qs('#assetBody').addEventListener('click', async (e) => {
    const view = e.target.closest('[data-view]'), del = e.target.closest('[data-del]');
    if (view) return openView(view.dataset.view);
    if (del) {
      const a = DB.assets.find((x) => x.id === del.dataset.del);
      const ok = await A.confirm({ title: 'Move this asset to trash?', text: `“${a.name}” (${a.qty} unit${a.qty > 1 ? 's' : ''}) will be moved to trash. You can restore it later.`, okLabel: 'Move to trash', tone: 'bad' });
      if (ok) A.toast('Asset moved to trash.');
    }
  });

  /* Sorting */
  A.qsa('#assetTable thead th.sortable').forEach((th) => th.addEventListener('click', () => {
    const k = th.dataset.sort;
    if (sortKey === k) sortDir = sortDir === 'asc' ? 'desc' : 'asc'; else { sortKey = k; sortDir = 'asc'; }
    rows = A.sortBy(rows, sortKey, sortDir); page = 1; render();
  }));

  /* Filter listeners */
  ['#q', '#fBuilding', '#fCategory', '#fCondition', '#fFund'].forEach((s) => A.qs(s).addEventListener('input', apply));

  /* View drawer */
  function openView(id) {
    const a = DB.assets.find((x) => x.id === id);
    A.qs('#viewTitle').textContent = a.name;
    A.qs('#viewSub').textContent = `${a.id}${a.qty > 1 ? ` · ${a.qty} units` : ''}`;
    A.qs('#viewEdit').href = 'custodian_add_asset.php?edit=' + a.id;
    const tickets = DB.tickets.filter((t) => t.assetId === a.id);
    A.qs('#viewBody').innerHTML = `
      <div class="meta-strip">
        <div><small class="muted">Condition</small><br>${A.conditionChip(a.condition)}</div>
        <div><small class="muted">Quantity</small><br><strong class="num">${a.qty}</strong></div>
        <div><small class="muted">Total value</small><br><strong class="num">${A.money(a.unitValue * a.qty)}</strong></div>
      </div>
      <dl class="dl">
        <div><dt>Category</dt><dd>${A.esc(a.category)}</dd></div>
        <div><dt>Fund source</dt><dd>${A.esc(a.fundSource)}${a.fundCode ? ` · Code ${a.fundCode}` : ''}</dd></div>
        <div><dt>Building</dt><dd>${A.esc(a.building)}</dd></div>
        <div><dt>Room</dt><dd>${A.esc(a.room)}</dd></div>
        <div><dt>Date acquired</dt><dd>${A.date(a.dateAcquired)}</dd></div>
        <div><dt>Unit value</dt><dd>${A.money(a.unitValue)}</dd></div>
        <div><dt>Property no.</dt><dd>${a.propertyNo ? A.esc(a.propertyNo) : '—'}</dd></div>
        <div><dt>Last modified</dt><dd>${A.date(a.modifiedAt)} · ${A.esc(a.modifiedBy)}</dd></div>
        ${a.description ? `<div class="span-2"><dt>Description</dt><dd>${A.esc(a.description)}</dd></div>` : ''}
      </dl>
      ${a.qty > 1 ? `<div><div class="section-title">Unit IDs</div><div class="unit-ids" style="margin-top:8px">${a.units.map((u) => `<span class="tag mono">${u}</span>`).join('')}</div></div>` : ''}
      ${tickets.length ? `<div><div class="section-title">Defect tickets (${tickets.length})</div>
        <div style="margin-top:8px;display:flex;flex-direction:column;gap:6px">${tickets.map((t) => `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 10px;border:1px solid var(--line);border-radius:8px"><span><strong style="font-size:12.5px">${A.esc(t.defectType)}</strong><br><small class="muted">${t.id} · ${A.esc(t.submittedBy)}</small></span>${A.statusChip(t.status)}</div>`).join('')}</div></div>` : ''}`;
    A.open('viewDrawer');
  }

  /* ---------- Import ---------- */
  const importModal = A.qs('#importModal');
  let importStep = 1, importedRows = [];
  A.qs('#importBtn').addEventListener('click', () => { resetImport(); A.open(importModal); });

  function resetImport() {
    importStep = 1; importedRows = [];
    A.qs('#importStep1').hidden = false; A.qs('#importStep2').hidden = true;
    A.qs('#importNext').textContent = 'Review file'; A.qs('#importNext').disabled = true;
    A.qs('#fileInput').value = ''; A.qs('#importHint').textContent = '';
    setSteps(1);
  }
  const setSteps = (n) => A.qsa('.step', importModal).forEach((s) => {
    const i = Number(s.dataset.step); s.classList.toggle('is-active', i === n); s.classList.toggle('is-done', i < n);
  });

  const dz = A.qs('#dropzone'), fi = A.qs('#fileInput');
  ['dragover', 'dragenter'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('is-over'); }));
  ['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove('is-over'); }));
  dz.addEventListener('drop', (e) => { if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]); });
  fi.addEventListener('change', () => { if (fi.files[0]) handleFile(fi.files[0]); });
  A.qs('#tmplLink').addEventListener('click', (e) => { e.preventDefault(); A.toast('Template download starts in the real build.', 'info'); });

  function handleFile(file) {
    A.qs('#fileName').textContent = file.name;
    A.qs('#importNext').disabled = false;
    A.qs('#importHint').textContent = file.name + ' ready to review';
    // Demo preview: sample the first few records so the custodian sees the mapping.
    importedRows = DB.assets.slice(0, 6).map((a, i) => ({ ...a, valid: i !== 4, error: i === 4 ? 'Unknown category' : '' }));
  }

  A.qs('#importNext').addEventListener('click', () => {
    if (importStep === 1) {
      importStep = 2; setSteps(2);
      A.qs('#importStep1').hidden = true; A.qs('#importStep2').hidden = false;
      const valid = importedRows.filter((r) => r.valid).length, errs = importedRows.length - valid;
      A.qs('#validCount').textContent = `${valid} valid`;
      const ec = A.qs('#errorCount'); ec.hidden = errs === 0; ec.textContent = `${errs} error${errs > 1 ? 's' : ''}`;
      A.qs('#previewTable').innerHTML = `
        <thead><tr><th>Row</th><th>Asset name</th><th>Category</th><th class="text-right">Qty</th><th>Fund source</th><th>Status</th></tr></thead>
        <tbody>${importedRows.map((r, i) => `<tr><td class="num">${i + 1}</td><td class="cell-main">${A.esc(r.name)}</td><td>${A.esc(r.category)}</td><td class="text-right num">${r.qty}</td><td>${A.esc(r.fundSource)}</td><td>${r.valid ? A.chip('Valid', 'good') : `<span class="chip bad" title="${A.esc(r.error)}">${A.esc(r.error)}</span>`}</td></tr>`).join('')}</tbody>`;
      A.qs('#importHint').textContent = errs ? `${errs} row will be skipped` : 'All rows valid';
      A.qs('#importNext').textContent = `Import ${valid} asset${valid > 1 ? 's' : ''}`;
    } else {
      const valid = importedRows.filter((r) => r.valid).length;
      A.close(importModal); A.toast(`${valid} assets imported and logged.`);
    }
  });

  /* ---------- Export ---------- */
  const exportModal = A.qs('#exportModal');
  const EXPORT_COLS = [
    { k: 'id', l: 'Asset ID' }, { k: 'name', l: 'Asset name' }, { k: 'category', l: 'Category' },
    { k: 'qty', l: 'Quantity' }, { k: 'building', l: 'Building' }, { k: 'room', l: 'Room' },
    { k: 'dateAcquired', l: 'Date acquired' }, { k: 'unitValue', l: 'Unit value' }, { k: 'totalValue', l: 'Total value' },
    { k: 'fundSource', l: 'Fund source' }, { k: 'fundCode', l: 'Fund code' }, { k: 'condition', l: 'Condition' },
    { k: 'propertyNo', l: 'Property no.' }, { k: 'modifiedAt', l: 'Last modified' }
  ];
  let exportScope = 0;
  A.qs('#colGrid').innerHTML = EXPORT_COLS.map((c) => `<label class="checkbox"><input type="checkbox" value="${c.k}" ${['propertyNo', 'fundCode', 'modifiedAt', 'totalValue'].includes(c.k) ? '' : 'checked'}> ${c.l}</label>`).join('');
  A.qs('#exportBtn').addEventListener('click', () => openExport(0));
  function openExport(selectedCount) {
    exportScope = selectedCount;
    const n = selectedCount || rows.length;
    A.qs('#exportScope').textContent = selectedCount ? `Export ${selectedCount} selected asset${selectedCount > 1 ? 's' : ''}.` : 'Export the current filtered list.';
    updateExportSummary(n);
    A.open(exportModal);
  }
  function updateExportSummary(n) {
    const cols = A.qsa('#colGrid input:checked').length;
    const fmt = A.qs('#exportFormat .is-active').dataset.fmt.toUpperCase();
    A.qs('#exportSummary').innerHTML = `Exporting <strong>${A.int(n || rows.length)}</strong> asset${(n || rows.length) > 1 ? 's' : ''} with <strong>${cols}</strong> column${cols > 1 ? 's' : ''} as <strong>${fmt}</strong>.`;
  }
  A.qs('#colAll').addEventListener('change', (e) => { A.qsa('#colGrid input').forEach((c) => (c.checked = e.target.checked)); updateExportSummary(exportScope); });
  A.qs('#colGrid').addEventListener('change', () => updateExportSummary(exportScope));
  A.qsa('#exportFormat button').forEach((b) => b.addEventListener('click', () => { A.qsa('#exportFormat button').forEach((x) => x.classList.remove('is-active')); b.classList.add('is-active'); updateExportSummary(exportScope); }));
  A.qs('#exportGo').addEventListener('click', () => {
    const fmt = A.qs('#exportFormat .is-active').dataset.fmt.toUpperCase();
    const n = exportScope || rows.length;
    A.close(exportModal); A.toast(`Exporting ${A.int(n)} assets as ${fmt}…`, 'info');
  });

  apply();
})();
