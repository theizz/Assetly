<?php
$pageTitle   = 'Assets';
$pageSub     = 'Every asset on record. Add, import, export, edit or move items to trash.';
$active      = 'assets';
$pageScripts = ['assets.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <div class="kpi-row" style="flex:1" id="assetKpis"></div>
  <div class="actions">
    <button class="btn btn-secondary" id="importBtn" type="button"><svg class="i"><use href="#i-upload"/></svg> Import</button>
    <button class="btn btn-secondary" id="exportBtn" type="button"><svg class="i"><use href="#i-download"/></svg> Export</button>
    <a class="btn btn-primary" href="custodian_add_asset.php"><svg class="i"><use href="#i-plus"/></svg> Add asset</a>
  </div>
</div>

<section class="card">
  <div class="card-b" style="padding-bottom:0">
    <div class="toolbar">
      <div class="input-icon grow">
        <svg class="i"><use href="#i-search"/></svg>
        <input class="input" id="q" type="search" placeholder="Search by asset name, ID or property number">
      </div>
      <select class="select" id="fBuilding"><option value="">All buildings</option></select>
      <select class="select" id="fCategory"><option value="">All categories</option></select>
      <select class="select" id="fCondition"><option value="">All conditions</option></select>
      <select class="select" id="fFund"><option value="">All fund sources</option></select>
    </div>
  </div>
  <div class="card-b flush" style="margin-top:12px">
    <div class="table-wrap">
      <table class="table" id="assetTable">
        <thead>
          <tr>
            <th class="check"><input type="checkbox" aria-label="Select all"></th>
            <th class="sortable" data-sort="id">ID</th>
            <th class="sortable" data-sort="name">Asset name</th>
            <th class="sortable" data-sort="category">Category</th>
            <th class="sortable text-right" data-sort="qty">Qty</th>
            <th class="sortable" data-sort="building">Location</th>
            <th class="sortable" data-sort="dateAcquired">Date acquired</th>
            <th class="sortable text-right" data-sort="unitValue">Unit value</th>
            <th class="sortable" data-sort="fundSource">Fund source</th>
            <th class="sortable" data-sort="condition">Condition</th>
            <th class="actions">Actions</th>
          </tr>
        </thead>
        <tbody id="assetBody"></tbody>
      </table>
    </div>
    <div class="table-foot" id="assetFoot"></div>
  </div>
</section>

<!-- Bulk action bar -->
<div class="bulkbar" id="bulkbar">
  <span class="count"><b id="bulkCount">0</b> selected</span>
  <span class="sep"></span>
  <button class="btn btn-sm btn-ghost" id="bulkExport" type="button"><svg class="i"><use href="#i-download"/></svg> Export selected</button>
  <button class="btn btn-sm btn-danger-soft" id="bulkDelete" type="button"><svg class="i"><use href="#i-trash"/></svg> Move to trash</button>
  <button class="icon-btn sm" id="bulkClear" type="button" aria-label="Clear selection" style="color:#fff"><svg class="i"><use href="#i-x"/></svg></button>
</div>

<!-- View drawer -->
<div class="drawer-backdrop" id="viewDrawer" hidden>
  <div class="drawer wide" role="dialog" aria-modal="true" aria-labelledby="viewTitle">
    <div class="drawer-h">
      <div><h2 id="viewTitle">Asset</h2><div class="sub" id="viewSub"></div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="drawer-b" id="viewBody"></div>
    <div class="drawer-f">
      <button class="btn btn-secondary" data-close type="button">Close</button>
      <a class="btn btn-primary" id="viewEdit" href="#"><svg class="i"><use href="#i-pencil"/></svg> Edit asset</a>
    </div>
  </div>
</div>

<!-- Import modal -->
<div class="modal-backdrop" id="importModal" hidden>
  <div class="modal modal-lg" role="dialog" aria-modal="true" aria-labelledby="importTitle">
    <div class="modal-h">
      <div><h2 id="importTitle">Bulk import assets</h2><div class="sub">Upload a CSV or Excel file. Each row becomes one asset record.</div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="modal-b" id="importBody">
      <div class="steps">
        <div class="step is-active" data-step="1"><span class="n">1</span> Upload</div>
        <span class="step-line"></span>
        <div class="step" data-step="2"><span class="n">2</span> Review</div>
        <span class="step-line"></span>
        <div class="step" data-step="3"><span class="n">3</span> Import</div>
      </div>

      <div id="importStep1">
        <label class="dropzone" id="dropzone">
          <svg class="i"><use href="#i-file-spreadsheet"/></svg>
          <strong>Drop your file here or click to browse</strong>
          <small>Accepts .csv, .xlsx — up to 2,000 rows</small>
          <input type="file" id="fileInput" accept=".csv,.xlsx,.xls">
        </label>
        <div class="note info" style="margin-top:12px">
          <svg class="i"><use href="#i-info"/></svg>
          <div>Required columns: <strong>Asset Name, Category, Quantity, Condition</strong>. Optional: Building, Room, Date Acquired, Unit Value, Fund Source, Property No.
          <a href="#" id="tmplLink">Download the template</a>.</div>
        </div>
      </div>

      <div id="importStep2" hidden>
        <div class="toolbar" style="margin-bottom:10px">
          <span class="file-pill"><svg class="i"><use href="#i-check"/></svg> <span id="fileName">assets.csv</span></span>
          <span class="toolbar-right"><span class="chip good" id="validCount">0 valid</span><span class="chip bad" id="errorCount" hidden>0 errors</span></span>
        </div>
        <div class="table-wrap" style="border:1px solid var(--line);border-radius:8px;max-height:280px;overflow:auto">
          <table class="table compact" id="previewTable"></table>
        </div>
      </div>
    </div>
    <div class="modal-f">
      <span class="left" id="importHint"></span>
      <button class="btn btn-secondary" data-close type="button">Cancel</button>
      <button class="btn btn-primary" id="importNext" type="button" disabled>Review file</button>
    </div>
  </div>
</div>

<!-- Export modal -->
<div class="modal-backdrop" id="exportModal" hidden>
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="exportTitle">
    <div class="modal-h">
      <div><h2 id="exportTitle">Export assets</h2><div class="sub" id="exportScope">Export the current filtered list.</div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="modal-b">
      <div class="field">
        <span class="label">Format</span>
        <div class="segmented" id="exportFormat" role="group" aria-label="Export format">
          <button type="button" class="is-active" data-fmt="csv">CSV (.csv)</button>
          <button type="button" data-fmt="xlsx">Excel (.xlsx)</button>
          <button type="button" data-fmt="pdf">PDF report</button>
        </div>
      </div>
      <div class="field">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span class="label">Columns to include</span>
          <label class="checkbox"><input type="checkbox" id="colAll" checked> Select all</label>
        </div>
        <div class="col-grid" id="colGrid"></div>
      </div>
      <div class="note info">
        <svg class="i"><use href="#i-info"/></svg>
        <div id="exportSummary"></div>
      </div>
    </div>
    <div class="modal-f">
      <button class="btn btn-secondary" data-close type="button">Cancel</button>
      <button class="btn btn-primary" id="exportGo" type="button"><svg class="i"><use href="#i-download"/></svg> Export</button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
