<?php
/**
 * Sidebar navigation. Expects $active to be set by the including page.
 * Badge counts are placeholders; replace them with counts from the backend.
 */
$nav = [
  ['key' => 'dashboard',  'href' => 'custodian_dashboard.php',      'icon' => 'i-dashboard', 'label' => 'Dashboard'],
  ['key' => 'assets',     'href' => 'custodian_assets.php',         'icon' => 'i-package',   'label' => 'Assets'],
  ['key' => 'deliveries', 'href' => 'custodian_deliveries.php',     'icon' => 'i-truck',     'label' => 'Deliveries',     'badge' => 2],
  ['key' => 'reports',    'href' => 'custodian_update_reports.php', 'icon' => 'i-file',      'label' => 'Update reports', 'badge' => 3],
  ['key' => 'tickets',    'href' => 'custodian_defect_tickets.php', 'icon' => 'i-wrench',    'label' => 'Defect tickets', 'badge' => 2],
  ['key' => 'trash',      'href' => 'custodian_trash.php',          'icon' => 'i-trash',     'label' => 'Trash'],
];
?>
<aside class="sidebar" id="sidebar">
  <a class="brand" href="custodian_dashboard.php" aria-label="Assetly home">
    <span class="brand-mark" aria-hidden="true">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V9"/><path d="M19 21V9"/><path d="M9 21v-6h6v6"/><path d="m2 9 10-6 10 6"/></svg>
    </span>
    <span class="brand-name">Assetly</span>
  </a>

  <nav class="nav" aria-label="Main">
    <?php foreach ($nav as $item): ?>
      <a class="nav-item<?= $active === $item['key'] ? ' is-active' : '' ?>"
         href="<?= $item['href'] ?>"
         <?= $active === $item['key'] ? 'aria-current="page"' : '' ?>>
        <svg class="i"><use href="#<?= $item['icon'] ?>"/></svg>
        <span><?= $item['label'] ?></span>
        <?php if (!empty($item['badge'])): ?><span class="nav-badge"><?= (int)$item['badge'] ?></span><?php endif; ?>
      </a>
    <?php endforeach; ?>
  </nav>

  <div class="sidebar-foot">
    <div class="school-tag">
      <svg class="i"><use href="#i-building"/></svg>
      <span><?= htmlspecialchars($schoolName ?? 'Lagro High School') ?></span>
    </div>
    <a class="nav-item logout" href="logout.php">
      <svg class="i"><use href="#i-logout"/></svg>
      <span>Log out</span>
    </a>
  </div>
</aside>
<div class="sidebar-scrim" id="sidebarScrim"></div>
