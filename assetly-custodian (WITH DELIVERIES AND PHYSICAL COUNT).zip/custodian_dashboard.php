<?php
$pageTitle   = 'Dashboard';
$pageSub     = 'What needs your attention across assets, deliveries, reports and tickets.';
$active      = 'dashboard';
$pageScripts = ['dashboard.js'];
include __DIR__ . '/includes/header.php';
?>

<!-- KPIs -->
<section class="kpi-row" id="kpiRow"></section>

<div class="grid grid-main">
  <div class="stack">

    <!-- Deliveries snapshot (delivered vs actual) -->
    <section class="card">
      <div class="card-h">
        <div>
          <h2>Deliveries &amp; actual count</h2>
          <p>How much was delivered against how much actually arrived.</p>
        </div>
        <a class="link" href="custodian_deliveries.php">Open deliveries <svg class="i i-sm"><use href="#i-arrow-right"/></svg></a>
      </div>
      <div class="card-b">
        <div class="pair-stats" id="dlvStats"></div>
        <div class="dlv-list" id="dlvList"></div>
      </div>
    </section>

    <!-- Assets by category -->
    <section class="card">
      <div class="card-h">
        <div>
          <h2>Assets by category</h2>
          <p>Operational units across all buildings.</p>
        </div>
        <a class="link" href="custodian_assets.php">View assets <svg class="i i-sm"><use href="#i-arrow-right"/></svg></a>
      </div>
      <div class="card-b"><div class="bars" id="catBars"></div></div>
    </section>

    <!-- Physical count reconciliation -->
    <section class="card">
      <div class="card-h">
        <div>
          <h2>Physical count vs records</h2>
          <p id="reconSub"></p>
        </div>
      </div>
      <div class="card-b">
        <div class="recon-head">
          <div><span class="pct num" id="reconPct"></span> <small class="muted">matched on last count</small></div>
          <div class="text-right"><small class="muted">Next count</small><br><strong id="reconNext"></strong></div>
        </div>
        <div class="table-wrap">
          <table class="table recon-table" id="reconTable"></table>
        </div>
      </div>
    </section>

    <!-- Activity log -->
    <section class="card">
      <div class="card-h">
        <div>
          <h2>Activity log</h2>
          <p>Every recorded action, newest first.</p>
        </div>
      </div>
      <div class="card-b flush">
        <div class="table-wrap">
          <table class="table compact" id="activityTable">
            <thead><tr><th>When</th><th>Event</th><th>User</th><th>Details</th></tr></thead>
            <tbody></tbody>
          </table>
        </div>
      </div>
    </section>
  </div>

  <!-- Right rail -->
  <aside class="stack">
    <section class="card">
      <div class="card-h"><div><h2>Needs your attention</h2><p>Pending items across modules.</p></div></div>
      <div class="card-b"><div class="attn" id="attnList"></div></div>
    </section>

    <section class="card">
      <div class="card-h">
        <div><h2>AI recommendations</h2><p>Insights on assets that need action.</p></div>
      </div>
      <div class="card-b">
        <div class="reco" id="recoList"></div>
        <div class="reco-foot">
          <svg class="i i-sm"><use href="#i-sparkles"/></svg>
          <span>AI-assisted. Double-check the details before acting; they may be incomplete.</span>
        </div>
      </div>
    </section>
  </aside>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
