# Assetly — Property Custodian Interface

Front-end for the Property Custodian role of the Assetly Property Management System.
Plain HTML/CSS/JS served as `.php` files so they drop into your PHP backend.

Scope: this build matches the system functions in the paper's Scope and Limitations
(asset management, search/filter, trash, bulk import, maintenance ticketing, dashboard
with inventory counts + ticket status + activity log, AI-assisted recommendations,
printable PDF reports). Deliveries and Physical Count are **not** included (future work).

## Pages

| File | Route | Purpose |
|------|-------|---------|
| `custodian_dashboard.php` | Dashboard | KPIs, assets-by-category, assets-by-condition, activity log, attention list, AI recommendations |
| `custodian_assets.php` | Assets | Searchable/sortable asset table with Date Acquired, Unit Value, Fund Source; view drawer; **Import** / **Export (PDF)** / **Add asset** |
| `custodian_add_asset.php` | Add / edit asset | Full form with live summary; `?edit=<id>` prefills for editing |
| `custodian_update_reports.php` | Update reports | Review / approve / reject teacher update requests |
| `custodian_defect_tickets.php` | Defect tickets | Triage damaged-equipment tickets through a status lifecycle (Pending → Acknowledged → In progress → Resolved/Rejected) |
| `custodian_trash.php` | Trash | Restore or permanently delete soft-deleted assets |
| `logout.php` | — | Placeholder; wire to your session teardown |

## Structure

```
includes/   header.php (head, sidebar, topbar, icon sprite), sidebar.php, footer.php
assets/css/ custodian.css   — one stylesheet, design tokens at the top
assets/js/  app.js   — shared helpers (window.Assetly): formatting, modals, confirm, toasts, table select, sort/paginate
            data.js  — mock data (window.DB). Replace with fetch() to your endpoints
            <page>.js — one script per page
```

## Run locally

```bash
php -S 127.0.0.1:8000
# open http://127.0.0.1:8000/custodian_dashboard.php
```

## Wiring to the backend

- **Data:** every page reads from `window.DB` (in `data.js`). Swap each page script's data source for `fetch()` calls returning the same shapes (documented inline in `data.js`).
- **Header user block:** set `$userName`, `$userRole`, `$userInitials`, `$schoolName`, `$notifCount` before `include 'includes/header.php'` (e.g. from `$_SESSION`).
- **Actions** (save, approve, delete, import, export) currently show a confirm dialog + toast. Replace the success branch in each handler with your POST/API call.
- **Sidebar badges** in `sidebar.php` are placeholders — feed real counts.

## Unit-level tracking (bundles)

Adding an asset with quantity N creates **N individually editable unit records** under
one bundle (Model B — each unit has its own ID, location, condition, property no.).

- The Assets table shows each bundle as one **group row** with a `×N` tag; multi-unit
  bundles **expand** to show their units.
- **Edit asset** (pencil on the group row) changes shared fields (name, category, value,
  fund source) for the whole bundle.
- **Edit unit** (pencil on a unit row) changes that one unit's location / condition /
  property no. — it diverges from the rest.
- **Edit selected** (bulk bar) applies a location and/or condition change to just the
  ticked units across bundles.
- Selection, trash, and export all operate at the **unit** level.

In `data.js` terms: a record carries `units[]` (IDs) and the page builds a `unitData[]`
of `{unitId, building, room, condition, propertyNo}` per unit. Your backend should store
one row per unit, linked by a bundle/group id.

## Notes on conventions

- Condition values: `Operational`, `Under maintenance`, `In storage`, `For disposal`.
- Fund sources: `National Fund`, `SEF`, `Donation`, `School MOOE` (DepEd fund codes optional per asset).
- Delete is soft (moves to Trash); permanent deletion is a separate, confirmed action.
- Export produces a printable PDF report (per the paper's scope); the column picker chooses what the PDF contains.
- Responsive to mobile; keyboard focus visible; `prefers-reduced-motion` respected.
