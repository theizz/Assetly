<?php
$pageTitle   = 'Home';
$active      = 'home';
$pageScripts = ['home.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head hello">
  <h1>Hello, <span id="helloName"><?= htmlspecialchars(explode(' ', $userName)[0]) ?></span></h1>
  <p>Report changes and defects, and track every request.</p>
</div>

<div class="stack">
  <div class="grid-4" id="kpis"></div>

  <!-- physical count call-to-action (shown while a count period is open) -->
  <div class="banner" id="countBanner" hidden>
    <span class="ic"><svg class="i i-lg">
        <use href="#i-clipboard" />
      </svg></span>
    <div><strong id="bannerTitle">Physical count is open</strong><small id="bannerSub"></small></div>
    <a class="btn btn-lg" href="teacher_physical_count.php" id="bannerBtn">Start counting</a>
  </div>

  <div class="grid-2">
    <div class="card action-card">
      <span class="ic"><svg class="i">
          <use href="#i-plus-square" />
        </svg></span>
      <div><strong>Report update</strong><small>Add, move or remove an asset</small></div>
      <a class="btn btn-primary" href="teacher_report_update.php"><svg class="i">
          <use href="#i-plus" />
        </svg> Report</a>
    </div>
    <div class="card action-card">
      <span class="ic"><svg class="i">
          <use href="#i-alert" />
        </svg></span>
      <div><strong>Report defect</strong><small>Broken or damaged items</small></div>
      <a class="btn btn-primary" href="teacher_report_defect.php"><svg class="i">
          <use href="#i-plus" />
        </svg> Report</a>
    </div>
  </div>

  <section class="card">
    <div class="card-h">
      <h2>Recent Reports</h2>
      <a href="teacher_my_reports.php" style="font-weight:600;color:var(--navy);display:inline-flex;align-items:center;gap:4px">View all <svg class="i i-sm">
          <use href="#i-chevron-right" />
        </svg></a>
    </div>
    <div class="card-b" style="padding-top:12px">
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th>Report Type</th>
              <th>Asset Name</th>
              <th>Location</th>
              <th>Date Submitted</th>
              <th>Status</th>
              <th class="center">View</th>
            </tr>
          </thead>
          <tbody id="recentBody"></tbody>
        </table>
      </div>
    </div>
  </section>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>