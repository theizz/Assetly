/* home: status counts across update reports + defect tickets, count banner, recent list. */
(function () {
  const { qs, esc, date, chip, int, daysUntil, store } = window.T,
    D = window.TDB;
  const all = [
    ...D.reports.map((r) => ({
      kind: "update",
      id: r.id,
      type: r.type === "Add" ? "Add asset" : r.type,
      name: r.assetName,
      loc: `${r.building.replace(" Building", "")} ${r.room}`,
      at: r.submittedAt,
      status: r.status,
    })),
    ...D.tickets.map((t) => ({
      kind: "ticket",
      id: t.id,
      type: "Defect · " + t.defectType,
      name: t.assetName,
      loc: `${t.building.replace(" Building", "")} ${t.room}`,
      at: t.submittedAt,
      status: t.status,
    })),
  ].sort((a, b) => b.at.localeCompare(a.at));

  const n = (f) => all.filter(f).length;
  qs("#kpis").innerHTML = [
    {
      v: n((x) => ["Acknowledged", "In progress"].includes(x.status)),
      l: "In progress",
      ic: "info",
      icon: "i-wrench",
    },
    {
      v: n((x) => x.status === "Pending"),
      l: "Pending reports",
      ic: "pending",
      icon: "i-clock",
    },
    {
      v: n((x) => ["Approved", "Resolved"].includes(x.status)),
      l: "Approved/Resolved",
      ic: "good",
      icon: "i-check",
    },
    {
      v: n((x) => x.status === "Rejected"),
      l: "Rejected reports",
      ic: "bad",
      icon: "i-ban",
    },
  ]
    .map(
      (k) =>
        `<div class="card kpi"><div><div class="v num">${int(k.v)}</div><div class="l">${k.l}</div></div><span class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></span></div>`,
    )
    .join("");

  /* count banner reflects the draft/submission saved by the Physical count page. */
  const P = D.countPeriod,
    saved = store.get("count." + P.id);
  const left = daysUntil(P.dueAt);
  if (!saved || saved.status !== "Submitted") {
    qs("#countBanner").hidden = false;
    qs("#bannerTitle").textContent = `${P.period} physical count is open`;
    const done =
      saved && saved.lines
        ? Object.values(saved.lines).filter(
            (l) => l.found !== null && l.found !== "",
          ).length
        : 0;
    qs("#bannerSub").textContent =
      `Due ${date(P.dueAt)} · ${left} day${left === 1 ? "" : "s"} left · ${done} of ${D.assets.length} items counted`;
    qs("#bannerBtn").textContent = done
      ? "Continue counting"
      : "Start counting";
  }

  qs("#recentBody").innerHTML =
    all
      .slice(0, 5)
      .map(
        (x) => `
    <tr>
      <td>${esc(x.type)}</td>
      <td class="cell-main">${esc(x.name)}</td>
      <td>${esc(x.loc)}</td>
      <td class="num">${date(x.at)}</td>
      <td>${chip(x.status)}</td>
      <td class="center"><a class="icon-btn" href="teacher_my_reports.php?tab=${x.kind === "ticket" ? "tickets" : "updates"}&id=${x.id}" aria-label="View ${esc(x.id)}"><svg class="i"><use href="#i-eye"/></svg></a></td>
    </tr>`,
      )
      .join("") ||
    `<tr><td colspan="6"><div class="empty"><strong>No reports yet</strong>Reports you submit will show here.</div></td></tr>`;
})();
