/* my assets: read-only list of assets in the teacher's assigned rooms, with quick report actions. */
(function () {
  const T = window.T,
    D = window.TDB,
    { qs, esc, int, condChip } = T;
  const roomKey = (a) => `${a.building}|${a.room}`;
  const openFor = (a) =>
    D.tickets.filter(
      (t) => t.assetId === a.id && !["Resolved", "Rejected"].includes(t.status),
    ).length +
    D.reports.filter(
      (r) =>
        r.assetName === a.name && r.room === a.room && r.status === "Pending",
    ).length;

  const units = D.assets.reduce((n, a) => n + a.qty, 0);
  const attention = D.assets.filter((a) => a.condition !== "Operational");
  qs("#kpis").innerHTML = [
    {
      v: units,
      l: "Items on record",
      sub: `${D.assets.length} asset lines`,
      ic: "info",
      icon: "i-layers",
    },
    {
      v: D.rooms.length,
      l: "Assigned rooms",
      sub: D.rooms
        .map((r) => `${r.building.replace(" Building", "")} ${r.room}`)
        .join(", "),
      ic: "info",
      icon: "i-map",
    },
    {
      v: D.assets
        .filter((a) => a.condition === "Operational")
        .reduce((n, a) => n + a.qty, 0),
      l: "Operational",
      sub: "Working items",
      ic: "good",
      icon: "i-check",
    },
    {
      v: attention.reduce((n, a) => n + a.qty, 0),
      l: "Need attention",
      sub: "Maintenance or disposal",
      ic: "pending",
      icon: "i-wrench",
    },
  ]
    .map(
      (k) =>
        `<div class="card kpi"><div><div class="v num">${int(k.v)}</div><div class="l">${k.l}</div><div class="hint" style="margin-top:2px">${esc(k.sub)}</div></div><span class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></span></div>`,
    )
    .join("");

  D.rooms.forEach((r) =>
    qs("#fRoom").insertAdjacentHTML(
      "beforeend",
      `<option value="${esc(r.building + "|" + r.room)}">${esc(r.building.replace(" Building", ""))} ${esc(r.room)} · ${esc(r.role)}</option>`,
    ),
  );
  [...new Set(D.assets.map((a) => a.condition))].forEach((c) =>
    qs("#fCond").insertAdjacentHTML("beforeend", `<option>${esc(c)}</option>`),
  );

  function render() {
    const q = qs("#q").value.trim().toLowerCase(),
      fr = qs("#fRoom").value,
      fc = qs("#fCond").value;
    const rows = D.assets.filter(
      (a) =>
        (!fr || roomKey(a) === fr) &&
        (!fc || a.condition === fc) &&
        (!q ||
          a.name.toLowerCase().includes(q) ||
          a.id.toLowerCase().includes(q) ||
          (a.propertyNo || "").includes(q)),
    );
    qs("#body").innerHTML =
      rows
        .map((a) => {
          const open = openFor(a);
          return `<tr>
        <td><span class="cell-main">${esc(a.name)}</span><span class="sub num">${a.id}${a.propertyNo ? " · PN " + esc(a.propertyNo) : ""}</span></td>
        <td>${esc(a.category)}</td>
        <td class="text-right num">${int(a.qty)}</td>
        <td>${esc(a.building.replace(" Building", ""))} · ${esc(a.room)}</td>
        <td>${condChip(a.condition)}</td>
        <td>${open ? `<a href="teacher_my_reports.php"><span class="tag" style="background:var(--pending-bg);color:var(--pending)">${open} open</span></a>` : '<span class="muted">—</span>'}</td>
        <td class="text-right" style="white-space:nowrap">
          <a class="btn btn-soft btn-sm" href="teacher_report_update.php?asset=${a.id}" title="Report an update for this asset">Update</a>
          <a class="btn btn-soft btn-sm" href="teacher_report_defect.php?asset=${a.id}" title="Report a defect on this asset" style="background:var(--bad-bg);color:var(--bad)">Defect</a>
        </td>
      </tr>`;
        })
        .join("") ||
      `<tr><td colspan="7"><div class="empty"><strong>No assets match</strong>Try another search or filter.</div></td></tr>`;
  }
  ["#q", "#fRoom", "#fCond"].forEach((s) =>
    qs(s).addEventListener("input", render),
  );
  render();
})();
