<?php
/**
 * Shared page footer: closes layout wrappers, mounts the toast and confirm dialog,
 * and loads the shared scripts plus any page-specific scripts listed in $pageScripts.
 */
?>
    </div><!-- /.content -->
  </main>
</div><!-- /.app -->

<!-- Toast stack -->
<div class="toast-stack" id="toastStack" aria-live="polite"></div>

<!-- Generic confirm dialog used by every page (see Assetly.confirm in app.js) -->
<div class="modal-backdrop" id="confirmDialog" hidden>
  <div class="modal modal-sm" role="alertdialog" aria-modal="true" aria-labelledby="confirmTitle">
    <div class="confirm-icon" id="confirmIcon"><svg class="i"><use href="#i-help"/></svg></div>
    <h3 id="confirmTitle">Are you sure?</h3>
    <p id="confirmText"></p>
    <div class="modal-actions center">
      <button class="btn btn-secondary" type="button" id="confirmCancel">Go back</button>
      <button class="btn btn-primary" type="button" id="confirmOk">Confirm</button>
    </div>
  </div>
</div>

<script src="assets/js/data.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/notifications.js"></script>
<?php foreach ($pageScripts as $script): ?>
<script src="assets/js/<?= htmlspecialchars($script) ?>"></script>
<?php endforeach; ?>
</body>
</html>