<?php
$pageTitle   = 'Trash';
$pageSub     = 'Deleted assets stay here so they can be restored. Permanent deletion is final.';
$active      = 'trash';
$pageScripts = ['trash.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <div class="kpi-row" style="flex:1" id="trashKpis"></div>
</div>

<section class="card">
  <div class="card-b" style="padding-bottom:0">
    <div class="toolbar">
      <div class="input-icon grow">
        <svg class="i"><use href="#i-search"/></svg>
        <input class="input" id="q" type="search" placeholder="Search deleted assets">
      </div>
      <select class="select" id="fCategory"><option value="">All categories</option></select>
    </div>
  </div>
  <div class="card-b flush" style="margin-top:12px">
    <div class="table-wrap">
      <table class="table" id="trashTable">
        <thead><tr>
          <th class="check"><input type="checkbox" aria-label="Select all"></th>
          <th>ID</th><th>Asset name</th><th>Category</th><th class="text-right">Qty</th><th>Location</th>
          <th>Deleted</th><th>Reason</th><th class="actions">Actions</th>
        </tr></thead>
        <tbody id="trashBody"></tbody>
      </table>
    </div>
    <div class="table-foot" id="trashFoot"></div>
  </div>
</section>

<div class="bulkbar" id="bulkbar">
  <span class="count"><b id="bulkCount">0</b> selected</span>
  <span class="sep"></span>
  <button class="btn btn-sm btn-ghost" id="bulkRestore" type="button"><svg class="i"><use href="#i-restore"/></svg> Restore</button>
  <button class="btn btn-sm btn-danger-soft" id="bulkPurge" type="button"><svg class="i"><use href="#i-trash"/></svg> Delete permanently</button>
  <button class="icon-btn sm" id="bulkClear" type="button" aria-label="Clear selection" style="color:#fff"><svg class="i"><use href="#i-x"/></svg></button>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
