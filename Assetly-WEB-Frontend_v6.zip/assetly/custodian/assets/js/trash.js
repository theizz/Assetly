/* trash page: restore soft-deleted assets or delete them permanently */
(function () {
  const A = window.Assetly,
    DB = window.DB;
  let rows = [...DB.trash];
  let page = 1;
  const perPage = 10;

  A.qs("#trashKpis").innerHTML = [
    {
      v: DB.trash.length,
      l: "Deleted records",
      ic: "neutral",
      icon: "i-trash",
    },
    {
      v: DB.trash.reduce((n, a) => n + a.qty, 0),
      l: "Units in trash",
      ic: "neutral",
      icon: "i-layers",
    },
    {
      v: DB.trash.filter((a) => A.daysSince(a.deletedAt) <= 30).length,
      l: "Deleted (30d)",
      ic: "warn",
      icon: "i-clock",
    },
  ]
    .map(
      (k) =>
        `<div class="kpi"><div><div class="v num">${A.int(k.v)}</div><div class="l">${k.l}</div></div><div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div></div>`,
    )
    .join("");

  DB.categories.forEach((c) =>
    A.qs("#fCategory").insertAdjacentHTML(
      "beforeend",
      `<option>${A.esc(c)}</option>`,
    ),
  );

  function apply() {
    const q = A.qs("#q").value.trim().toLowerCase(),
      fc = A.qs("#fCategory").value;
    rows = DB.trash.filter(
      (a) =>
        (!q ||
          a.name.toLowerCase().includes(q) ||
          a.id.toLowerCase().includes(q)) &&
        (!fc || a.category === fc),
    );
    rows.sort((a, b) => (b.deletedAt || "").localeCompare(a.deletedAt || ""));
    page = 1;
    render();
  }

  function render() {
    const slice = rows.slice((page - 1) * perPage, page * perPage);
    const body = A.qs("#trashBody");
    if (!slice.length) {
      body.innerHTML = `<tr><td colspan="9"><div class="empty"><svg class="i"><use href="#i-trash"/></svg><strong>Trash is empty</strong>Deleted assets will appear here.</div></td></tr>`;
    } else
      body.innerHTML = slice
        .map(
          (a) => `
      <tr>
        <td class="check"><input type="checkbox" value="${a.id}" aria-label="Select ${A.esc(a.name)}"></td>
        <td class="id num">${a.id}${a.qty > 1 ? ` <span class="tag mono">+${a.qty - 1}</span>` : ""}</td>
        <td class="cell-main">${A.esc(a.name)}</td>
        <td>${A.esc(a.category)}</td>
        <td class="text-right num">${a.qty}</td>
        <td>${A.esc(a.building)}<span class="cell-sub">Room ${A.esc(a.room)}</span></td>
        <td class="num">${A.date(a.deletedAt)}<span class="cell-sub">${A.esc(a.deletedBy)}</span></td>
        <td class="wrap muted" style="max-width:220px">${A.esc(a.deleteReason || "—")}</td>
        <td class="actions"><div class="row-actions">
          <button class="btn btn-sm btn-secondary" data-restore="${a.id}"><svg class="i"><use href="#i-restore"/></svg> Restore</button>
          <button class="icon-btn sm danger" data-purge="${a.id}" aria-label="Delete permanently"><svg class="i"><use href="#i-trash"/></svg></button>
        </div></td>
      </tr>`,
        )
        .join("");
    A.pager({
      el: A.qs("#trashFoot"),
      total: rows.length,
      page,
      perPage,
      onPage: (p) => {
        page = p;
        render();
      },
    });
    sel.update();
  }

  const sel = A.selection({
    table: A.qs("#trashTable"),
    bulkbar: A.qs("#bulkbar"),
    countEl: A.qs("#bulkCount"),
  });
  A.qs("#bulkClear").addEventListener("click", () => sel.clear());
  A.qs("#bulkRestore").addEventListener("click", async () => {
    const ids = sel.selected();
    if (!ids.length) return;
    const ok = await A.confirm({
      title: `Restore ${ids.length} asset${ids.length > 1 ? "s" : ""}?`,
      text: "They will return to the Assets list with their last known condition.",
      okLabel: "Restore",
      tone: "good",
    });
    if (ok) {
      A.toast(`${ids.length} asset${ids.length > 1 ? "s" : ""} restored.`);
      sel.clear();
    }
  });
  A.qs("#bulkPurge").addEventListener("click", async () => {
    const ids = sel.selected();
    if (!ids.length) return;
    const ok = await A.confirm({
      title: `Permanently delete ${ids.length} asset${ids.length > 1 ? "s" : ""}?`,
      text: "This cannot be undone. The records and their IDs will be removed for good.",
      okLabel: "Delete permanently",
      tone: "bad",
    });
    if (ok) {
      A.toast(
        `${ids.length} asset${ids.length > 1 ? "s" : ""} permanently deleted.`,
        "bad",
      );
      sel.clear();
    }
  });

  A.qs("#trashBody").addEventListener("click", async (e) => {
    const r = e.target.closest("[data-restore]"),
      p = e.target.closest("[data-purge]");
    if (r) {
      const a = DB.trash.find((x) => x.id === r.dataset.restore);
      const ok = await A.confirm({
        title: "Restore this asset?",
        text: `“${a.name}” will return to the Assets list.`,
        okLabel: "Restore",
        tone: "good",
      });
      if (ok) A.toast("Asset restored.");
    }
    if (p) {
      const a = DB.trash.find((x) => x.id === p.dataset.purge);
      const ok = await A.confirm({
        title: "Permanently delete this asset?",
        text: `“${a.name}” will be removed for good. This cannot be undone.`,
        okLabel: "Delete permanently",
        tone: "bad",
      });
      if (ok) A.toast("Asset permanently deleted.", "bad");
    }
  });

  ["#q", "#fCategory"].forEach((s) => A.qs(s).addEventListener("input", apply));
  apply();
})();
