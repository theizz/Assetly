/* physical count (custodian): open/close count periods, follow up with teachers,
   review each submitted count, then verify it or return it for correction.
   teacher side: teacher/teacher_physical_count.php. Data: DB.countPeriods, DB.countSubmissions. */
(function () {
  const A = window.Assetly,
    DB = window.DB,
    { qs, qsa, esc, int } = A;
  /* "Today" fixed for the demo so due-date countdowns are stable. Use new Date() in production. */
  const TODAY = new Date("2026-11-16T09:00:00");
  const nowISO = () => new Date().toISOString().slice(0, 19);
  const ME = "Zaida M. Padullo";

  const TONE = {
    "Not started": "neutral",
    Draft: "warn",
    Submitted: "info",
    Verified: "good",
    Returned: "bad",
    Open: "info",
    Closed: "neutral",
  };
  const chip = (s) => A.chip(s, TONE[s]);
  const DONE = ["Submitted", "Verified"]; // counts that hold real numbers
  const NOT_IN = ["Not started", "Draft", "Returned"];

  let periodId = (
    DB.countPeriods.find((p) => p.status === "Open") || DB.countPeriods[0]
  ).id;
  let page = 1;
  const perPage = 10;
  const period = () => DB.countPeriods.find((p) => p.id === periodId);
  const subsOf = (pid) => DB.countSubmissions.filter((s) => s.periodId === pid);

  /* ---------- per-submission figures ---------- */
  function figures(s) {
    const counted = s.lines.filter(
      (l) => l.found !== null && l.found !== undefined,
    );
    const onRecord = s.lines.reduce((n, l) => n + l.onRecord, 0);
    const found = counted.reduce((n, l) => n + l.found, 0);
    const short = counted.reduce(
      (n, l) => n + Math.max(0, l.onRecord - l.found),
      0,
    );
    const extraQty = s.extras.reduce((n, x) => n + x.qty, 0);
    const over =
      counted.reduce((n, l) => n + Math.max(0, l.found - l.onRecord), 0) +
      extraQty;
    const shortLines = counted.filter((l) => l.found < l.onRecord);
    const condLines = counted.filter((l) => l.condition !== l.recCondition);
    const noRemark = counted.filter(
      (l) => l.found !== l.onRecord && !l.remarks.trim(),
    );
    return {
      onRecord,
      found,
      short,
      over,
      counted: counted.length,
      lines: s.lines.length,
      shortLines,
      condLines,
      noRemark,
      extras: s.extras.length,
    };
  }
  const roomsText = (s) =>
    s.rooms
      .map((r) => `${r.building.replace(" Building", "")} · ${r.room}`)
      .join(", ");
  const daysLeft = (iso) =>
    Math.ceil((new Date(iso + "T23:59:59") - TODAY) / 86400000);

  /* ---------- header / KPIs / period ---------- */
  function renderPeriodSelect() {
    qs("#periodSel").innerHTML = [...DB.countPeriods]
      .sort((a, b) => b.opensAt.localeCompare(a.opensAt))
      .map(
        (p) =>
          `<option value="${p.id}"${p.id === periodId ? " selected" : ""}>${esc(p.period)}${p.status === "Open" ? " (open)" : ""}</option>`,
      )
      .join("");
  }

  function renderTop() {
    const p = period(),
      subs = subsOf(p.id),
      open = DB.countPeriods.some((x) => x.status === "Open");
    const by = (st) => subs.filter((s) => s.status === st).length;
    const done = subs.filter((s) => DONE.includes(s.status));
    const short = done.reduce((n, s) => n + figures(s).short, 0);

    if (subs.length) {
      qs("#pcKpis").innerHTML = [
        {
          v: by("Submitted"),
          l: "To review",
          d: "Submitted, awaiting you",
          ic: "brand",
          icon: "i-clipboard",
        },
        {
          v: `${by("Verified")}/${subs.length}`,
          l: "Verified",
          d: "Teachers done",
          ic: "good",
          icon: "i-check-circle",
        },
        {
          v: subs.filter((s) => NOT_IN.includes(s.status)).length,
          l: "Not in yet",
          d: "Not started, draft or returned",
          ic: "warn",
          icon: "i-clock",
        },
        {
          v: short,
          l: "Units short",
          d: "In submitted counts",
          ic: "bad",
          icon: "i-alert",
        },
      ]
        .map(kpi)
        .join("");
    } else {
      const sm = p.summary || {};
      qs("#pcKpis").innerHTML = [
        {
          v: sm.teachers || 0,
          l: "Teachers",
          d: "Counted this period",
          ic: "brand",
          icon: "i-clipboard",
        },
        {
          v: int(sm.onRecord),
          l: "On record",
          d: "Units",
          ic: "neutral",
          icon: "i-layers",
        },
        {
          v: int(sm.found),
          l: "Found",
          d: "Units",
          ic: "good",
          icon: "i-check-circle",
        },
        {
          v: int(sm.short),
          l: "Units short",
          d: `${int(sm.over)} over`,
          ic: "bad",
          icon: "i-alert",
        },
      ]
        .map(kpi)
        .join("");
    }

    qs("#periodName").textContent = `${p.period} physical count`;
    qs("#periodChip").innerHTML = chip(p.status);
    const left = daysLeft(p.dueAt);
    qs("#periodMeta").innerHTML =
      p.status === "Open"
        ? `Opened ${A.date(p.opensAt)} by ${esc(p.openedBy)} · Due ${A.date(p.dueAt)} <strong class="${left <= 7 ? "text-danger" : ""}">(${left < 0 ? Math.abs(left) + " days overdue" : left + " days left"})</strong>`
        : `Ran ${A.date(p.opensAt)} – ${A.date(p.dueAt)} · Closed ${A.dateTime(p.closedAt)}`;

    if (subs.length) {
      const pct = Math.round((done.length / subs.length) * 100);
      qs("#periodProgress").innerHTML = `
        <div class="progress ${pct === 100 ? "good" : ""}"><span style="width:${pct}%"></span></div>
        <div class="pc-legend"><span><b>${done.length} of ${subs.length}</b> teachers submitted (${pct}%)</span>
          ${["Verified", "Submitted", "Returned", "Draft", "Not started"].map((st) => `<span>${chip(st)} <b>${by(st)}</b></span>`).join("")}</div>`;
    } else
      qs("#periodProgress").innerHTML =
        `<div class="note info"><svg class="i"><use href="#i-info"/></svg><div>This period is closed. Per-teacher detail is kept in the archive; totals are shown above.</div></div>`;

    const pb = qs("#periodBtn");
    if (open) {
      pb.innerHTML =
        '<svg class="i"><use href="#i-archive"/></svg> Close period';
      pb.dataset.mode = "close";
      pb.disabled = p.status !== "Open";
      pb.title =
        p.status !== "Open" ? "Switch to the open period to close it" : "";
    } else {
      pb.innerHTML =
        '<svg class="i"><use href="#i-plus"/></svg> Open count period';
      pb.dataset.mode = "open";
      pb.disabled = false;
      pb.title = "";
    }
    qs("#remindAll").disabled = p.status !== "Open";
  }
  const kpi = (k) =>
    `<div class="kpi"><div><div class="v num">${k.v}</div><div class="l">${k.l}</div><div class="d">${k.d}</div></div><div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div></div>`;

  /* ---------- submissions table ---------- */
  ["Submitted", "Returned", "Draft", "Not started", "Verified"].forEach((s) =>
    qs("#fStatus").insertAdjacentHTML("beforeend", `<option>${s}</option>`),
  );
  DB.buildings.forEach((b) =>
    qs("#fBuilding").insertAdjacentHTML(
      "beforeend",
      `<option>${esc(b)}</option>`,
    ),
  );
  const ORDER = {
    Submitted: 0,
    Returned: 1,
    Draft: 2,
    "Not started": 3,
    Verified: 4,
  };

  function rows() {
    const q = qs("#q").value.trim().toLowerCase(),
      fs = qs("#fStatus").value,
      fb = qs("#fBuilding").value;
    return subsOf(periodId)
      .filter(
        (s) =>
          (!fs || s.status === fs) &&
          (!fb || s.rooms.some((r) => r.building === fb)) &&
          (!q ||
            s.teacher.toLowerCase().includes(q) ||
            roomsText(s).toLowerCase().includes(q)),
      )
      .sort(
        (a, b) =>
          ORDER[a.status] - ORDER[b.status] ||
          a.teacher.localeCompare(b.teacher),
      );
  }

  function flagsHTML(f) {
    const t = [];
    if (f.shortLines.length)
      t.push(`<span class="tag bad">${f.shortLines.length} short</span>`);
    if (f.condLines.length)
      t.push(`<span class="tag warn">${f.condLines.length} condition</span>`);
    if (f.extras)
      t.push(`<span class="tag warn">${f.extras} not on record</span>`);
    if (f.noRemark.length)
      t.push(`<span class="tag bad">${f.noRemark.length} no remark</span>`);
    return t.length
      ? `<div class="pc-flags">${t.join("")}</div>`
      : '<span class="tag">No differences</span>';
  }

  function renderTable() {
    const list = rows(),
      body = qs("#pcBody");
    const slice = list.slice((page - 1) * perPage, page * perPage);
    const isOpen = period().status === "Open";
    body.innerHTML =
      slice
        .map((s) => {
          const f = figures(s),
            hasNums = DONE.includes(s.status) || s.status === "Returned";
          const action =
            s.status === "Submitted" && isOpen
              ? `<button class="btn btn-sm btn-primary" data-open="${s.id}">Review</button>`
              : hasNums
                ? `<button class="btn btn-sm btn-secondary" data-open="${s.id}">View</button>`
                : isOpen
                  ? `<button class="btn btn-sm btn-secondary" data-remind="${s.id}"><svg class="i"><use href="#i-bell"/></svg> Remind</button>`
                  : "";
          return `<tr>
        <td class="cell-main">${esc(s.teacher)}</td>
        <td class="wrap">${esc(roomsText(s))}</td>
        <td class="text-right num">${int(f.onRecord)}</td>
        <td class="text-right num">${hasNums ? int(f.found) : `<span class="muted" title="Items counted so far">${f.counted}/${f.lines}</span>`}</td>
        <td class="text-right num ${hasNums && f.short ? "text-danger" : "muted"}">${hasNums ? int(f.short) : "—"}</td>
        <td class="text-right num ${hasNums && f.over ? "text-warn" : "muted"}">${hasNums ? int(f.over) : "—"}</td>
        <td>${hasNums ? flagsHTML(f) : '<span class="muted">—</span>'}</td>
        <td class="num">${s.submittedAt && s.status !== "Draft" ? A.date(s.submittedAt) : s.savedAt ? `<span class="muted">Saved ${A.date(s.savedAt)}</span>` : '<span class="muted">—</span>'}</td>
        <td>${chip(s.status)}</td>
        <td class="actions">${action}</td>
      </tr>`;
        })
        .join("") ||
      `<tr><td colspan="10"><div class="empty"><svg class="i"><use href="#i-clipboard"/></svg><strong>No counts to show</strong>${subsOf(periodId).length ? "Try clearing the search or a filter." : "Per-teacher detail is not kept for closed periods in this demo."}</div></td></tr>`;
    A.pager({
      el: qs("#pcFoot"),
      total: list.length,
      page,
      perPage,
      onPage: (p) => {
        page = p;
        renderTable();
      },
    });
  }

  /* ---------- reconciliation by building ---------- */
  /* per-building totals from the counts in the given statuses.
     The screen uses DONE (Submitted + Verified); the printed report uses Verified only. */
  function reconBy(statuses) {
    const agg = {};
    subsOf(periodId)
      .filter((s) => statuses.includes(s.status))
      .forEach((s) => {
        s.lines.forEach((l) => {
          const b = (s.rooms.find((r) => r.room === l.room) || s.rooms[0])
            .building;
          const a =
            agg[b] ||
            (agg[b] = {
              rooms: new Set(),
              onRecord: 0,
              found: 0,
              short: 0,
              over: 0,
            });
          a.rooms.add(l.room);
          a.onRecord += l.onRecord;
          a.found += l.found;
          a.short += Math.max(0, l.onRecord - l.found);
          a.over += Math.max(0, l.found - l.onRecord);
        });
        s.extras.forEach((x) => {
          const b = s.rooms[0].building;
          if (agg[b]) agg[b].over += x.qty;
        });
      });
    return Object.entries(agg).sort((a, b) => a[0].localeCompare(b[0]));
  }

  function renderRecon() {
    const list = reconBy(DONE);
    qs("#reconBody").innerHTML =
      list
        .map(([b, a]) => {
          const pct = a.onRecord
            ? Math.round(((a.onRecord - a.short) / a.onRecord) * 1000) / 10
            : 100;
          return `<tr><td class="cell-main">${esc(b)}</td><td class="text-right num">${a.rooms.size}</td><td class="text-right num">${int(a.onRecord)}</td><td class="text-right num">${int(a.found)}</td>
        <td class="text-right num ${a.short ? "text-danger" : "muted"}">${int(a.short)}</td><td class="text-right num ${a.over ? "text-warn" : "muted"}">${int(a.over)}</td>
        <td><div class="match"><div class="progress ${pct >= 99 ? "good" : pct >= 95 ? "warn" : "bad"}"><span style="width:${pct}%"></span></div><span class="num">${pct}%</span></div></td></tr>`;
        })
        .join("") ||
      `<tr><td colspan="7"><div class="empty" style="padding:20px"><strong>Nothing to reconcile yet</strong>Buildings appear here once their counts are submitted.</div></td></tr>`;
  }

  const renderAll = () => {
    renderPeriodSelect();
    renderTop();
    renderTable();
    renderRecon();
  };

  /* ---------- review drawer ---------- */
  let current = null;
  function openDrawer(id) {
    const s = DB.countSubmissions.find((x) => x.id === id);
    if (!s) return;
    current = s;
    const f = figures(s),
      p = DB.countPeriods.find((x) => x.id === s.periodId);
    qs("#pcTitle").textContent = `${s.teacher} · ${p.period}`;
    qs("#pcSub").textContent = roomsText(s);

    const tl = `
      <div class="meta-strip">
        <div><small class="muted">On record</small><br><strong class="num">${int(f.onRecord)}</strong></div>
        <div><small class="muted">Found</small><br><strong class="num">${int(f.found)}</strong></div>
        <div><small class="muted">Short</small><br><strong class="num ${f.short ? "text-danger" : ""}">${int(f.short)}</strong></div>
        <div><small class="muted">Over / not on record</small><br><strong class="num ${f.over ? "text-warn" : ""}">${int(f.over)}</strong></div>
      </div>
      <div class="timeline">
        <div class="tl-item done"><div class="dot"><i></i></div><div class="body"><strong>Period opened</strong><small class="muted">${A.date(p.opensAt)} · ${esc(p.openedBy)}</small></div></div>
        <div class="tl-item ${s.submittedAt ? "done" : "active"}"><div class="dot"><i></i></div><div class="body"><strong>Counted and submitted${s.certified ? " (certified by teacher)" : ""}</strong><small class="muted">${s.submittedAt ? A.dateTime(s.submittedAt) : "Not submitted yet"}</small></div></div>
        <div class="tl-item ${s.status === "Verified" ? "done" : s.status === "Submitted" ? "active" : ""}"><div class="dot"><i></i></div><div class="body"><strong>${s.status === "Returned" ? "Returned for correction" : "Verified by custodian"}</strong><small class="muted">${s.reviewedAt ? A.dateTime(s.reviewedAt) + " · " + esc(s.reviewedBy) : "Waiting for your review"}</small></div></div>
      </div>`;

    const notes = [
      s.status === "Returned"
        ? `<div class="note bad"><svg class="i"><use href="#i-restore"/></svg><div><strong>Returned:</strong> ${esc(s.returnReason)}</div></div>`
        : "",
      f.noRemark.length && s.status === "Submitted"
        ? `<div class="note warn"><svg class="i"><use href="#i-alert"/></svg><div>${f.noRemark.length} item${f.noRemark.length > 1 ? "s have" : " has"} a difference with no remark from the teacher. Consider returning the count.</div></div>`
        : "",
      s.status === "Verified"
        ? `<div class="note good"><svg class="i"><use href="#i-check-circle"/></svg><div>Verified. ${f.condLines.length ? "Condition changes were applied to the asset records. " : ""}${f.shortLines.length ? "Short items were flagged for investigation." : ""}</div></div>`
        : "",
    ].join("");

    const byRoom = s.rooms
      .map((r) => {
        const ls = s.lines.filter((l) => l.room === r.room);
        if (!ls.length) return "";
        return (
          `<tr class="room-band"><td colspan="6">${esc(r.building)} · ${esc(r.room)}</td></tr>` +
          ls
            .map((l) => {
              const v = l.found == null ? null : l.found - l.onRecord;
              const cond =
                l.condition !== l.recCondition
                  ? `<span class="cond-change">${esc(l.recCondition)} → <b>${esc(l.condition)}</b></span>`
                  : `<span class="muted">${esc(l.condition)}</span>`;
              const rem = l.remarks
                ? esc(l.remarks)
                : v
                  ? '<span class="no-remark">No remark</span>'
                  : '<span class="muted">—</span>';
              return `<tr><td class="cell-main wrap">${esc(l.name)}<span class="cell-sub">${l.assetId}</span></td>
          <td class="text-right num">${int(l.onRecord)}</td>
          <td class="text-right num">${l.found == null ? '<span class="muted">—</span>' : int(l.found)}</td>
          <td class="text-right"><span class="var num ${v < 0 ? "text-danger" : v > 0 ? "text-warn" : "muted"}">${v == null ? "—" : (v > 0 ? "+" : "") + int(v)}</span></td>
          <td>${cond}</td><td class="wrap">${rem}</td></tr>`;
            })
            .join("")
        );
      })
      .join("");

    const extras = s.extras.length
      ? `
      <div><div class="section-title">Found but not on record (${s.extras.length})</div>
        <div class="line-items" style="margin-top:10px"><table class="table"><thead><tr><th>Item</th><th class="text-right">Qty</th><th>Room</th><th>Teacher's note</th></tr></thead>
        <tbody>${s.extras.map((x) => `<tr><td class="cell-main wrap">${esc(x.name)}</td><td class="text-right num">${int(x.qty)}</td><td>${esc(x.room)}</td><td class="wrap">${esc(x.remarks) || '<span class="muted">—</span>'}</td></tr>`).join("")}</tbody></table></div>
        <p class="muted" style="font-size:12px;margin:6px 0 0">To put these on record, use <a href="custodian_add_asset.php">Add asset</a> or approve the matching update report.</p></div>`
      : "";

    qs("#pcDrawerBody").innerHTML = `${tl}${notes}
      <div><div class="section-title">Count by room</div>
        <div class="line-items" style="margin-top:10px"><table class="table">
          <thead><tr><th>Asset</th><th class="text-right">On record</th><th class="text-right">Found</th><th class="text-right">Variance</th><th>Condition</th><th>Teacher's remarks</th></tr></thead>
          <tbody>${byRoom}</tbody></table></div></div>
      ${extras}`;

    const foot = qs("#pcDrawerFoot");
    if (s.status === "Submitted" && p.status === "Open") {
      foot.innerHTML = `<div class="left" style="display:flex;flex-direction:column;gap:4px">
          ${f.condLines.length ? `<label class="checkbox"><input type="checkbox" id="optCond" checked> Apply ${f.condLines.length} condition change${f.condLines.length > 1 ? "s" : ""} to asset records</label>` : ""}
          ${f.shortLines.length ? `<label class="checkbox"><input type="checkbox" id="optShort" checked> Flag ${f.short} short unit${f.short > 1 ? "s" : ""} for investigation</label>` : ""}
        </div>
        <button class="btn btn-danger-soft" id="returnBtn" type="button"><svg class="i"><use href="#i-restore"/></svg> Return</button>
        <button class="btn btn-good" id="verifyBtn" type="button"><svg class="i"><use href="#i-check-circle"/></svg> Verify count</button>`;
      qs("#verifyBtn").addEventListener("click", verify);
      qs("#returnBtn").addEventListener("click", () => {
        qs("#returnSub").textContent = `${s.teacher} · ${roomsText(s)}`;
        qs("#returnReason").value = "";
        qs("#returnForm .field").classList.remove("is-invalid");
        A.open("returnModal");
      });
    } else {
      foot.innerHTML = `<button class="btn btn-secondary left" data-close type="button">Close</button>
        <button class="btn btn-primary" type="button" id="printOne"><svg class="i"><use href="#i-printer"/></svg> Print count sheet</button>`;
      qs("#printOne").addEventListener("click", () => printCountSheet(s));
    }
    A.open("pcDrawer");
  }

  async function verify() {
    const s = current,
      f = figures(s);
    const applyCond = qs("#optCond") ? qs("#optCond").checked : false,
      flagShort = qs("#optShort") ? qs("#optShort").checked : false;
    const parts = [
      applyCond
        ? `${f.condLines.length} condition change${f.condLines.length > 1 ? "s" : ""} will be applied`
        : "",
      flagShort
        ? `${f.short} short unit${f.short > 1 ? "s" : ""} will be flagged for investigation`
        : "",
    ].filter(Boolean);
    const ok = await A.confirm({
      title: `Verify ${s.teacher}'s count?`,
      text: `${int(f.found)} of ${int(f.onRecord)} units found.${parts.length ? " " + parts.join("; ") + "." : ""} The teacher can no longer edit this count.`,
      okLabel: "Verify count",
      tone: "good",
    });
    if (!ok) return;
    // backend: POST /count/{periodId}/submissions/{id}/verify { applyCond, flagShort }
    s.status = "Verified";
    s.reviewedAt = nowISO();
    s.reviewedBy = ME;
    A.close("pcDrawer");
    renderAll();
    A.toast(`${s.teacher}'s count verified.`);
  }

  qs("#returnForm").addEventListener("submit", (e) => {
    e.preventDefault();
    if (!A.validate(qs("#returnForm"))) return;
    // backend: POST /count/{periodId}/submissions/{id}/return { reason }
    const s = current;
    s.status = "Returned";
    s.returnReason = qs("#returnReason").value.trim();
    s.reviewedAt = nowISO();
    s.reviewedBy = ME;
    A.close("returnModal");
    A.close("pcDrawer");
    renderAll();
    A.toast(`Count returned to ${s.teacher} for correction.`, "info");
  });

  /* ---------- table & filters ---------- */
  qs("#pcBody").addEventListener("click", (e) => {
    const o = e.target.closest("[data-open]"),
      r = e.target.closest("[data-remind]");
    if (o) openDrawer(o.dataset.open);
    if (r) {
      const s = DB.countSubmissions.find((x) => x.id === r.dataset.remind);
      A.toast(`Reminder sent to ${s.teacher}.`, "info");
    }
  });
  ["#q", "#fStatus", "#fBuilding"].forEach((sel) =>
    qs(sel).addEventListener("input", () => {
      page = 1;
      renderTable();
    }),
  );
  qs("#periodSel").addEventListener("change", (e) => {
    periodId = e.target.value;
    page = 1;
    renderAll();
  });
  qs("#remindAll").addEventListener("click", async () => {
    const pending = subsOf(periodId).filter((s) => NOT_IN.includes(s.status));
    if (!pending.length) return A.toast("Everyone has submitted.", "info");
    const ok = await A.confirm({
      title: `Send a reminder to ${pending.length} teacher${pending.length > 1 ? "s" : ""}?`,
      text: `${pending.map((s) => s.teacher).join(", ")} will be reminded that the count is due ${A.date(period().dueAt)}.`,
      okLabel: "Send reminders",
    });
    if (ok)
      A.toast(
        `Reminder sent to ${pending.length} teacher${pending.length > 1 ? "s" : ""}.`,
        "info",
      );
  });

  /* ---------- print summary: consolidated count report (Verified counts only) ----------
     Same approach as the assets report: builds #printSheet from the live data, then opens the
     print dialog (choose "Save as PDF" to keep a copy). Layout classes (ps-*) live in custodian.css
     under "print: property inventory report". Only Verified counts are included. */
  const SCHOOL_NAME = document.body.dataset.school || "Lagro High School";
  const DIVISION_NAME = "Schools Division Office of Quezon City";
  const FORM_TITLE = "CONSOLIDATED PHYSICAL COUNT REPORT";
  const PREPARED_ROLE = "Property Custodian";
  const PAGE_CSS =
    '@page{size:A4 landscape;margin:12mm 12mm 14mm;@bottom-right{content:"Page " counter(page) " of " counter(pages);font-size:8.5pt;font-family:"Neue Montreal",Arial,sans-serif}}';

  /* shared by the print reports: the #printSheet element, the page style and the letterhead */
  function startSheet(cls) {
    let sheet = qs("#printSheet");
    if (!sheet) {
      sheet = document.createElement("div");
      sheet.id = "printSheet";
      document.body.appendChild(sheet);
    }
    let style = qs("#psPageStyle");
    if (!style) {
      style = document.createElement("style");
      style.id = "psPageStyle";
      document.head.appendChild(style);
    }
    style.textContent = PAGE_CSS; // landscape A4, only while printing from this page
    sheet.className = cls || "";
    return sheet;
  }
  const sheetHead = (title, sub) => `<header class="ps-head">
        <div class="ps-logo"></div>
        <div class="ps-title">
          <div class="gov">Republic of the Philippines<br><b>Department of Education</b><br>${esc(DIVISION_NAME)}</div>
          <div class="school">${esc(SCHOOL_NAME)}</div>
          <h1>${esc(title)}</h1>
          <div class="sub">${esc(sub)}</div>
        </div>
        <div class="ps-logo"></div>
      </header>`;

  function buildSummarySheet() {
    const p = period(),
      subs = subsOf(p.id),
      ver = subs
        .filter((s) => s.status === "Verified")
        .sort((a, b) => a.teacher.localeCompare(b.teacher));
    if (!ver.length) {
      A.toast(
        subs.length
          ? "No verified counts to print yet. Verify at least one count first."
          : "This period has no per-teacher detail to print.",
        "bad",
      );
      return false;
    }

    const sheet = startSheet("");

    const stamp = A.dateTime(new Date().toISOString());
    const fig = ver.map((s) => ({ s, f: figures(s) }));
    const tot = (k) => fig.reduce((n, x) => n + x.f[k], 0);
    const pct = (a) =>
      a.onRecord
        ? Math.round(((a.onRecord - a.short) / a.onRecord) * 1000) / 10
        : 100;

    /* 1. count per teacher */
    const teacherRows = fig
      .map(
        ({ s, f }, i) => `<tr>
          <td class="c">${i + 1}</td><td>${esc(s.teacher)}</td><td>${esc(roomsText(s))}</td>
          <td class="c">${int(f.onRecord)}</td><td class="c">${int(f.found)}</td>
          <td class="c">${int(f.short)}</td><td class="c">${int(f.over)}</td>
          <td class="c nw">${s.reviewedAt ? A.date(s.reviewedAt) : "—"}</td></tr>`,
      )
      .join("");

    /* 2. reconciliation by building (Verified only) */
    const recon = reconBy(["Verified"]);
    const rt = recon.reduce(
      (t, [, a]) => ({
        rooms: t.rooms + a.rooms.size,
        onRecord: t.onRecord + a.onRecord,
        found: t.found + a.found,
        short: t.short + a.short,
        over: t.over + a.over,
      }),
      { rooms: 0, onRecord: 0, found: 0, short: 0, over: 0 },
    );
    const reconRows = recon
      .map(
        ([b, a]) => `<tr>
          <td>${esc(b)}</td><td class="c">${int(a.rooms.size)}</td>
          <td class="c">${int(a.onRecord)}</td><td class="c">${int(a.found)}</td>
          <td class="c">${int(a.short)}</td><td class="c">${int(a.over)}</td>
          <td class="c">${pct(a)}%</td></tr>`,
      )
      .join("");

    /* 3. found but not on the property list (from every verified count) */
    const extras = ver.flatMap((s) =>
      s.extras.map((x) => ({ ...x, teacher: s.teacher })),
    );
    const extraRows = extras.length
      ? extras
          .map(
            (x, i) => `<tr>
          <td class="c">${i + 1}</td><td>${esc(x.name)}</td><td class="c">${int(x.qty)}</td>
          <td>${esc(x.room)}</td><td>${esc(x.teacher)}</td><td>${esc(x.remarks) || "—"}</td></tr>`,
          )
          .join("")
      : `<tr><td colspan="6" class="c">None reported.</td></tr>`;

    sheet.innerHTML = `
      ${sheetHead(FORM_TITLE, p.period)}
      <p class="ps-account">Consolidated results of the <b>${esc(p.period)} physical count</b> of school property at <b>${esc(SCHOOL_NAME)}</b>, based on the counts submitted by teachers and verified by the Property Custodian, <b>${esc(ME)}</b>.</p>
      <div class="ps-meta">
        <div><b>Count period:</b> ${A.date(p.opensAt)} – ${A.date(p.dueAt)}</div>
        <div><b>Verified:</b> ${ver.length} of ${subs.length} teachers</div>
        <div><b>Date generated:</b> ${stamp}</div>
      </div>

      <section class="ps-sec">
        <h2>Count per teacher <span>· ${ver.length} verified</span></h2>
        <table class="ps-table">
          <thead><tr>
            <th class="c" style="width:5%">No.</th><th style="width:19%">Teacher</th><th style="width:26%">Rooms</th>
            <th class="c" style="width:10%">On record</th><th class="c" style="width:9%">Found</th>
            <th class="c" style="width:9%">Short (-)</th><th class="c" style="width:9%">Over (+)</th>
            <th class="c" style="width:13%">Verified on</th>
          </tr></thead>
          <tbody>${teacherRows}
            <tr class="ps-total"><td colspan="3" class="r">TOTAL</td>
              <td class="c">${int(tot("onRecord"))}</td><td class="c">${int(tot("found"))}</td>
              <td class="c">${int(tot("short"))}</td><td class="c">${int(tot("over"))}</td><td></td></tr>
          </tbody>
        </table>
      </section>

      <section class="ps-sec">
        <h2>Reconciliation by building</h2>
        <table class="ps-table">
          <thead><tr>
            <th style="width:28%">Building</th><th class="c" style="width:12%">Rooms counted</th>
            <th class="c" style="width:14%">On record</th><th class="c" style="width:12%">Found</th>
            <th class="c" style="width:11%">Short (-)</th><th class="c" style="width:11%">Over (+)</th>
            <th class="c" style="width:12%">Match</th>
          </tr></thead>
          <tbody>${reconRows}
            <tr class="ps-total"><td class="r">TOTAL</td><td class="c">${int(rt.rooms)}</td>
              <td class="c">${int(rt.onRecord)}</td><td class="c">${int(rt.found)}</td>
              <td class="c">${int(rt.short)}</td><td class="c">${int(rt.over)}</td><td class="c">${pct(rt)}%</td></tr>
          </tbody>
        </table>
      </section>

      <section class="ps-sec">
        <h2>Items found in the rooms but not on the property list <span>· ${extras.length}</span></h2>
        <table class="ps-table">
          <thead><tr>
            <th class="c" style="width:5%">No.</th><th style="width:30%">Item name</th><th class="c" style="width:8%">Qty</th>
            <th style="width:14%">Room</th><th style="width:18%">Counted by</th><th style="width:25%">Remarks / where it came from</th>
          </tr></thead>
          <tbody>${extraRows}</tbody>
        </table>
      </section>

      <section class="ps-close">
        <p class="ps-cert">I certify that this report was prepared from the physical counts submitted by the teachers and verified by this office, as of ${stamp}.</p>
        <div class="ps-sign">
          <div><span class="role">Prepared by:</span><div class="who"><b>${esc(ME)}</b>${PREPARED_ROLE} · Signature over printed name<br>Date: ________________</div></div>
          <div><span class="role">Noted by:</span><div class="who"><b>&nbsp;</b>School Head<br>Date: ________________</div></div>
        </div>
        <div class="ps-foot">Generated by Assetly · ${stamp}</div>
      </section>`;
    return true;
  }

  /* ---------- print count sheet: one teacher's count (same layout as the teacher's own sheet) ----------
     Opened from the drawer. One page per room, then the "found but not on the list" page with the
     certification and signatures. The custodian copy fills in the counted and verified dates when
     they exist; a count that has not been done yet prints as a blank sheet. */
  const COUNT_CONDITIONS = ["Operational", "Under maintenance", "Damaged", "For disposal"];
  const BLANK_LINE = "________________";

  function printCountSheet(s) {
    const p = DB.countPeriods.find((x) => x.id === s.periodId) || period();
    const done = (l) => l.found !== null && l.found !== undefined;
    const sgn = (n) => (n > 0 ? "+" : "") + int(n);
    const assetOf = (id) => (DB.assets || []).find((a) => a.id === id);
    const stamp = A.dateTime(new Date().toISOString());

    /* four condition boxes, the counted one ticked (a condition outside the four is added and ticked) */
    const condCell = (l) => {
      const opts =
        done(l) && l.condition && !COUNT_CONDITIONS.includes(l.condition)
          ? [...COUNT_CONDITIONS, l.condition]
          : COUNT_CONDITIONS;
      return opts
        .map((c) => `<span class="nw">${done(l) && l.condition === c ? "☒" : "☐"} ${esc(c)}</span>`)
        .join(" ");
    };

    const rooms = s.rooms
      .map((r) => {
        const ls = s.lines.filter((l) => l.room === r.room);
        if (!ls.length) return "";
        const counted = ls.filter(done);
        const rec = ls.reduce((n, l) => n + l.onRecord, 0);
        const rows = ls
          .map((l, i) => {
            const a = assetOf(l.assetId);
            const v = done(l) ? l.found - l.onRecord : null;
            return `<tr>
              <td class="c">${i + 1}</td>
              <td>${esc(a ? a.category : "")}</td>
              <td>${esc(l.name)}<br>Asset ID ${esc(l.assetId)}</td>
              <td class="nw">${esc(a && a.propertyNo ? a.propertyNo : "—")}</td>
              <td class="c">${int(l.onRecord)}</td>
              <td class="c">${done(l) ? int(l.found) : ""}</td>
              <td class="c">${v == null ? "" : sgn(v)}</td>
              <td>${condCell(l)}</td>
              <td>${esc(l.remarks || "")}</td></tr>`;
          })
          .join("");
        return `<section class="ps-sec">
          <h2>Location: ${esc(r.building)}, Room ${esc(r.room)} <span>· ${esc(p.period)} · ${esc(s.teacher)} · Count ID ${esc(s.id)}</span></h2>
          <table class="ps-table">
            <thead><tr>
              <th class="c" style="width:4%">No.</th><th style="width:12%">Article</th><th style="width:20%">Description</th>
              <th style="width:11%">Property No.</th><th class="c" style="width:8%">Qty per record</th>
              <th class="c" style="width:8%">Qty per count</th><th class="c" style="width:8%">Short (-) / Over (+)</th>
              <th style="width:20%">Condition</th><th style="width:9%">Remarks</th>
            </tr></thead>
            <tbody>${rows}
              <tr class="ps-total"><td colspan="4" class="r">TOTAL</td><td class="c">${int(rec)}</td>
                <td class="c">${counted.length ? int(counted.reduce((n, l) => n + l.found, 0)) : ""}</td>
                <td class="c">${counted.length ? sgn(counted.reduce((n, l) => n + l.found - l.onRecord, 0)) : ""}</td><td></td><td></td></tr>
            </tbody>
          </table>
        </section>`;
      })
      .join("");

    const blank = ["Not started", "Draft"].includes(s.status);
    const extraRows = s.extras.length
      ? s.extras
          .map((x) => `<tr><td>${esc(x.name)}</td><td class="c">${int(x.qty)}</td><td>${esc(x.room)}</td><td>${esc(x.remarks || "")}</td></tr>`)
          .join("")
      : blank
        ? '<tr><td>&nbsp;</td><td></td><td></td><td></td></tr>'.repeat(3)
        : '<tr><td colspan="4" class="c">None reported.</td></tr>';

    const verifier = s.status === "Verified" && s.reviewedBy ? s.reviewedBy : ME;
    const counted = s.submittedAt ? A.date(s.submittedAt) : BLANK_LINE;
    const verified = s.status === "Verified" && s.reviewedAt ? A.date(s.reviewedAt) : BLANK_LINE;

    const sheet = startSheet("ps-paged");
    sheet.innerHTML = `
      ${sheetHead("PHYSICAL COUNT SHEET OF SCHOOL PROPERTY", "Semi-annual count · " + p.period)}
      <p class="ps-account">For which <b>${esc(s.teacher)}</b>, Teacher, ${esc(SCHOOL_NAME)}, is accountable, having assumed such accountability on ${BLANK_LINE}.</p>
      <div class="ps-meta">
        <div><b>Rooms:</b> ${esc(roomsText(s))}</div>
        <div><b>Count period:</b> ${A.date(p.opensAt)} to ${A.date(p.dueAt)}</div>
        <div><b>Date counted:</b> ${counted}</div>
      </div>
      ${rooms}

      <section class="ps-sec">
        <h2>Items found in the room but not on the property list <span>· ${esc(p.period)} · ${esc(s.teacher)} · Count ID ${esc(s.id)}</span></h2>
        <table class="ps-table">
          <thead><tr><th style="width:38%">Item name</th><th class="c" style="width:10%">Qty</th><th style="width:14%">Room</th><th style="width:38%">Remarks / where it came from</th></tr></thead>
          <tbody>${extraRows}</tbody>
        </table>
      </section>

      <section class="ps-close">
        <p class="ps-cert">I certify that I physically counted the items listed in this sheet in the rooms assigned to me, and that this count is true and correct.</p>
        <div class="ps-sign">
          <div><span class="role">Counted and certified correct by:</span><div class="who"><b>${esc(s.teacher)}</b>Teacher · Signature over printed name<br>Date: ${counted}</div></div>
          <div><span class="role">Verified by:</span><div class="who"><b>${esc(verifier)}</b>Property Custodian<br>Date: ${verified}</div></div>
          <div><span class="role">Noted by:</span><div class="who"><b>&nbsp;</b>School Head<br>Date: ${BLANK_LINE}</div></div>
        </div>
        <div class="ps-foot">Generated by Assetly · ${stamp} · Count ID ${esc(s.id)}</div>
      </section>`;

    document.body.classList.add("ps-active"); // tells custodian.css to print only #printSheet
    window.print();
  }

  qs("#printBtn").addEventListener("click", () => {
    if (!buildSummarySheet()) return;
    document.body.classList.add("ps-active"); // tells custodian.css to print only #printSheet
    window.print();
  });
  window.addEventListener("afterprint", () => {
    document.body.classList.remove("ps-active");
    const s = qs("#psPageStyle");
    if (s) s.remove();
  });

  /* ---------- open / close period ---------- */
  qs("#periodBtn").addEventListener("click", async () => {
    if (qs("#periodBtn").dataset.mode === "close") {
      const subs = subsOf(periodId),
        unverified = subs.filter((s) => s.status === "Submitted").length,
        missing = subs.filter((s) => NOT_IN.includes(s.status)).length;
      const warn = unverified || missing;
      const ok = await A.confirm({
        title: `Close the ${period().period} count?`,
        text: warn
          ? `${unverified} submitted count${unverified === 1 ? " is" : "s are"} not verified and ${missing} teacher${missing === 1 ? " has" : "s have"} not submitted. Their rooms will be recorded as not counted. Teachers can no longer submit.`
          : "All counts are verified. Teachers can no longer submit, and the totals are archived.",
        okLabel: "Close period",
        tone: warn ? "bad" : "good",
      });
      if (!ok) return;
      const p = period(),
        done = subs.filter((s) => DONE.includes(s.status)).map(figures);
      p.status = "Closed";
      p.closedAt = nowISO();
      p.summary = {
        teachers: done.length,
        onRecord: done.reduce((n, f) => n + f.onRecord, 0),
        found: done.reduce((n, f) => n + f.found, 0),
        short: done.reduce((n, f) => n + f.short, 0),
        over: done.reduce((n, f) => n + f.over, 0),
      };
      renderAll();
      A.toast(`${p.period} count closed.`);
    } else {
      const have = new Set(DB.countPeriods.map((p) => p.period)),
        y = TODAY.getFullYear();
      const opts = [
        `June ${y}`,
        `December ${y}`,
        `June ${y + 1}`,
        `December ${y + 1}`,
      ].filter((x) => !have.has(x));
      qs("#o-period").innerHTML = opts
        .map((o) => `<option>${o}</option>`)
        .join("");
      const due = new Date(TODAY);
      due.setDate(due.getDate() + 30);
      qs("#o-due").value = due.toISOString().slice(0, 10);
      qs("#o-instr").value = DB.countPeriods[0].instructions || "";
      A.open("openModal");
    }
  });
  qs("#openForm").addEventListener("submit", (e) => {
    e.preventDefault();
    if (!A.validate(qs("#openForm"))) return;
    const name = qs("#o-period").value,
      id =
        "PC-" +
        name.split(" ")[1] +
        "-" +
        (name.startsWith("June") ? "06" : "12");
    // backend: POST /count/periods — the server creates one submission per teacher with assigned rooms
    const p = {
      id,
      period: name,
      opensAt: TODAY.toISOString().slice(0, 10),
      dueAt: qs("#o-due").value,
      openedBy: ME,
      status: "Open",
      instructions: qs("#o-instr").value.trim(),
    };
    DB.countPeriods.push(p);
    const latest = [...DB.countPeriods]
      .filter((x) => subsOf(x.id).length)
      .sort((a, b) => b.opensAt.localeCompare(a.opensAt))[0];
    subsOf(latest.id).forEach((s, i) =>
      DB.countSubmissions.push({
        id: `PCS-${Date.now()}-${i}`,
        periodId: id,
        teacher: s.teacher,
        rooms: s.rooms,
        status: "Not started",
        extras: [],
        lines: s.lines.map((l) => ({
          ...l,
          found: null,
          condition: l.recCondition,
          remarks: "",
        })),
      }),
    );
    periodId = id;
    page = 1;
    A.close("openModal");
    renderAll();
    A.toast(`${name} count opened. Teachers have been notified.`);
  });

  renderAll();
  const deep = new URLSearchParams(location.search).get("open");
  if (deep) openDrawer(deep);
})();