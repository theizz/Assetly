/* notification panel: opens from the bell in the top bar on every page.
   Items are built from window.DB (pending requests, new tickets, counts to review, deliveries to count)
   plus a few recent activity events. Read state is kept in localStorage for this mock-up; with a real
   backend, load the list from the server and send "mark read" back to it. */
(function () {
  const A = window.Assetly, DB = window.DB;
  const btn = A.qs("#notifBtn");
  if (!btn || !DB) return;

  /* ---------- items ---------- */
  const roomLabel = (r) => (/^\d+$/.test(String(r)) ? "Room " + r : r);
  const items = [];
  (DB.roomRequests || []).filter((r) => r.status === "Pending").forEach((r) =>
    items.push({
      id: "rm:" + r.id, at: r.submittedAt, tone: "info", icon: "i-map-pin", href: "custodian_room_requests.php",
      title: r.kind === "Request" ? `${r.teacher} requested a room` : `${r.teacher} wants to release a room`,
      text: `${r.building} · ${roomLabel(r.room)}`,
    }));
  (DB.reports || []).filter((r) => r.status === "Pending").forEach((r) =>
    items.push({
      id: "ur:" + r.id, at: r.submittedAt, tone: "warn", icon: "i-file", href: "custodian_update_reports.php",
      title: `${r.submittedBy} sent an update report`, text: `${r.type}: ${r.assetName}`,
    }));
  (DB.tickets || []).filter((t) => t.status === "Pending").forEach((t) =>
    items.push({
      id: "dt:" + t.id, at: t.submittedAt, tone: "bad", icon: "i-wrench", href: "custodian_defect_tickets.php",
      title: "New defect ticket", text: `${t.defectType} · ${t.assetName}`,
    }));
  (DB.countSubmissions || []).filter((s) => s.status === "Submitted").forEach((s) =>
    items.push({
      id: "pc:" + s.id, at: s.submittedAt, tone: "good", icon: "i-clipboard", href: "custodian_physical_count.php",
      title: "Count waiting for review", text: `${s.teacher} submitted their physical count`,
    }));
  (DB.deliveries || []).filter((d) => d.status === "Logged").forEach((d) =>
    items.push({
      id: "dl:" + d.id, at: d.dateDelivered, tone: "warn", icon: "i-truck", href: "custodian_deliveries.php",
      title: "Delivery needs counting", text: `${d.ref} · ${d.source}`,
    }));
  /* a few finished things, already read, so the list isn't only to-dos */
  [...(DB.activity || [])].sort((a, b) => b.at.localeCompare(a.at))
    .filter((e) => /approved|imported/i.test(e.event)).slice(0, 3)
    .forEach((e, i) =>
      items.push({
        id: "ac:" + i + e.at, at: e.at, tone: "good", icon: "i-check-circle", href: "custodian_dashboard.php",
        title: e.event, text: e.details, done: true,
      }));
  items.sort((a, b) => String(b.at || "").localeCompare(String(a.at || "")));
  items.splice(14);

  /* ---------- read state ---------- */
  const KEY = "assetly.notifRead";
  const seen = new Set();
  try { JSON.parse(localStorage.getItem(KEY) || "[]").forEach((x) => seen.add(x)); } catch (e) {}
  const persist = () => { try { localStorage.setItem(KEY, JSON.stringify([...seen])); } catch (e) {} };
  const isRead = (n) => n.done || seen.has(n.id);
  const unread = () => items.filter((n) => !isRead(n)).length;

  /* "2h ago" for the last week, a plain date after that */
  const ago = (iso) => {
    if (!iso) return "";
    const d = A.parseDate ? A.parseDate(iso) : new Date(iso);
    const mins = Math.round((Date.now() - d.getTime()) / 60000);
    if (mins >= 0 && mins < 1) return "Just now";
    if (mins >= 0 && mins < 60) return mins + "m ago";
    if (mins >= 0 && mins < 1440) return Math.floor(mins / 60) + "h ago";
    if (mins >= 0 && mins < 10080) return Math.floor(mins / 1440) + "d ago";
    return A.date(iso);
  };

  /* ---------- panel ---------- */
  const host = btn.parentElement;
  const panel = document.createElement("div");
  panel.className = "notif-panel";
  panel.id = "notifPanel";
  panel.hidden = true;
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-label", "Notifications");
  host.appendChild(panel);
  btn.setAttribute("aria-haspopup", "dialog");
  btn.setAttribute("aria-expanded", "false");
  btn.setAttribute("aria-controls", "notifPanel");

  let tab = "all";

  function updateBadge() {
    const n = unread();
    let b = A.qs(".badge-dot", btn);
    if (!n) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement("span"); b.className = "badge-dot"; btn.appendChild(b); }
    b.textContent = n > 9 ? "9+" : n;
  }

  function render() {
    const n = unread();
    const list = tab === "unread" ? items.filter((x) => !isRead(x)) : items;
    panel.innerHTML = `
      <div class="notif-h">
        <div><h2>Notifications</h2><p>${n ? `${n} need${n === 1 ? "s" : ""} your attention` : "You're all caught up"}</p></div>
        <button class="notif-link" id="notifMarkAll" type="button" ${n ? "" : "disabled"}>Mark all as read</button>
      </div>
      <div class="notif-tabs" role="tablist">
        <button role="tab" type="button" data-tab="all" aria-selected="${tab === "all"}" class="${tab === "all" ? "is-on" : ""}">All</button>
        <button role="tab" type="button" data-tab="unread" aria-selected="${tab === "unread"}" class="${tab === "unread" ? "is-on" : ""}">Unread${n ? ` <b>${n}</b>` : ""}</button>
      </div>
      <div class="notif-list">
        ${list.length ? list.map((x, i) => `
          <a class="notif-item${isRead(x) ? "" : " is-unread"}" style="--i:${i}" href="${A.esc(x.href)}" data-id="${A.esc(x.id)}">
            <span class="notif-ic ${x.tone}"><svg class="i"><use href="#${x.icon}"/></svg></span>
            <span class="notif-body">
              <span class="notif-t">${A.esc(x.title)}</span>
              <span class="notif-s">${A.esc(x.text)}</span>
              <span class="notif-time">${A.esc(ago(x.at))}</span>
            </span>
            <span class="notif-dot" aria-label="${isRead(x) ? "" : "Unread"}"></span>
          </a>`).join("") : `
          <div class="notif-empty"><svg class="i"><use href="#i-check-circle"/></svg><strong>${tab === "unread" ? "Nothing unread" : "No notifications"}</strong><span>New requests, tickets and counts will show up here.</span></div>`}
      </div>`;
    updateBadge();
  }

  function setOpen(open) {
    panel.hidden = !open;
    btn.setAttribute("aria-expanded", String(open));
    if (open) render();
  }

  btn.addEventListener("click", (e) => { e.stopPropagation(); setOpen(panel.hidden); });
  /* use the event path, not e.target: switching tabs re-renders the panel, so by the time this runs the
     clicked button is no longer in the DOM and panel.contains(e.target) would wrongly say "outside" */
  document.addEventListener("click", (e) => {
    const path = e.composedPath ? e.composedPath() : [];
    const inside = path.includes(panel) || path.includes(btn);
    if (!panel.hidden && !inside) setOpen(false);
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !panel.hidden) { setOpen(false); btn.focus(); }
  });

  panel.addEventListener("click", (e) => {
    const t = e.target.closest("[data-tab]");
    if (t) { tab = t.dataset.tab; render(); return; }
    if (e.target.closest("#notifMarkAll")) {
      items.forEach((x) => seen.add(x.id));
      persist(); render();
      A.toast("All notifications marked as read.", "info");
      return;
    }
    const it = e.target.closest(".notif-item");
    if (it) { seen.add(it.dataset.id); persist(); } /* then follow the link */
  });

  updateBadge();
  if (unread()) {
    btn.classList.add("is-ring");
    setTimeout(() => btn.classList.remove("is-ring"), 1600);
  }
})();