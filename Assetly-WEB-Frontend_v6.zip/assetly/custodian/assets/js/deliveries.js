/* deliveries page: log → count → post workflow for incoming assets */
(function () {
  const A = window.Assetly,
    DB = window.DB;
  let rows = [...DB.deliveries];
  let page = 1;
  const perPage = 8;

  /* items already posted one-by-one through the Add asset form (demo: kept in sessionStorage) */
  const POSTED_KEY = "assetly.postedItems";
  const postedSet = () => {
    try {
      return new Set(JSON.parse(sessionStorage.getItem(POSTED_KEY) || "[]"));
    } catch (e) {
      return new Set();
    }
  };
  const itemPosted = (d, i) =>
    d.status === "Posted" || postedSet().has(d.id + ":" + i);
  const qtyToPost = (it) => (it.received != null ? it.received : it.expected) || 0;
  const postHref = (d, i) => {
    const it = d.items[i];
    const q = new URLSearchParams({
      from: d.id,
      item: String(i),
      name: it.name,
      category: it.category,
      qty: String(qtyToPost(it)),
    });
    return "custodian_add_asset.php?" + q.toString();
  };
  const expanded = new Set();

  const expOf = (d) => d.items.reduce((n, i) => n + (i.expected || 0), 0);
  const recOf = (d) => d.items.reduce((n, i) => n + (i.received || 0), 0);
  const dmgOf = (d) => d.items.reduce((n, i) => n + (i.damaged || 0), 0);
  const valOf = (d) =>
    d.items.reduce(
      (n, i) => n + (i.received || i.expected || 0) * (i.unitValue || 0),
      0,
    );

  /* KPIs */
  const toCount = DB.deliveries.filter((d) => d.status === "Logged");
  const toPost = DB.deliveries.filter((d) => d.status === "Counted");
  const posted30 = DB.deliveries.filter(
    (d) =>
      d.status === "Posted" && A.daysSince(d.postedAt || d.dateDelivered) <= 60,
  );
  const totalDmg = DB.deliveries.reduce((n, d) => n + dmgOf(d), 0);
  A.qs("#dlvKpis").innerHTML = [
    {
      v: toCount.length,
      l: "To count",
      d: "Awaiting physical count",
      ic: "warn",
      icon: "i-truck",
    },
    {
      v: toPost.length,
      l: "To post",
      d: "Counted, not in inventory",
      ic: "info",
      icon: "i-archive",
    },
    {
      v: posted30.length,
      l: "Posted (60d)",
      d: "Added to inventory",
      ic: "good",
      icon: "i-check-circle",
    },
    {
      v: totalDmg,
      l: "Damaged units",
      d: "Across all deliveries",
      ic: "bad",
      icon: "i-alert",
    },
  ]
    .map(
      (k) =>
        `<div class="kpi"><div><div class="v num">${A.int(k.v)}</div><div class="l">${k.l}</div><div class="d">${k.d}</div></div><div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div></div>`,
    )
    .join("");

  /* source filter */
  DB.deliverySources.forEach((s) =>
    A.qs("#fSource").insertAdjacentHTML(
      "beforeend",
      `<option>${A.esc(s)}</option>`,
    ),
  );

  function apply() {
    const q = A.qs("#q").value.trim().toLowerCase(),
      fs = A.qs("#fStatus").value,
      fsrc = A.qs("#fSource").value;
    rows = DB.deliveries.filter(
      (d) =>
        (!q ||
          d.ref.toLowerCase().includes(q) ||
          d.source.toLowerCase().includes(q) ||
          (d.supplier || "").toLowerCase().includes(q)) &&
        (!fs || d.status === fs) &&
        (!fsrc || d.source === fsrc),
    );
    rows.sort((a, b) => b.dateDelivered.localeCompare(a.dateDelivered));
    page = 1;
    render();
  }

  function render() {
    const body = A.qs("#dlvBody");
    const slice = rows.slice((page - 1) * perPage, page * perPage);
    if (!slice.length) {
      body.innerHTML = `<tr><td colspan="8"><div class="empty"><svg class="i"><use href="#i-truck"/></svg><strong>No deliveries found</strong>Log a delivery when items arrive.</div></td></tr>`;
    } else {
      body.innerHTML = slice
        .map((d) => {
          const exp = expOf(d),
            rec = recOf(d),
            counted = d.status !== "Logged";
          const variance = counted ? rec - exp : null;
          const multi = d.items.length > 1;
          const isExp = multi && expanded.has(d.id);
          const main = `<tr class="group-row" data-group="${d.id}">
          <td class="cell-main"><span class="id-cell">${multi ? `<button class="icon-btn sm expander" type="button" data-expand="${d.id}" aria-expanded="${isExp}" aria-label="${isExp ? "Hide" : "Show"} items of ${A.esc(d.ref)}"><svg class="i i-sm" style="transition:transform .15s;${isExp ? "transform:rotate(90deg)" : ""}"><use href="#i-chevron-right"/></svg></button>` : '<span class="expander-spacer"></span>'}<span>${A.esc(d.ref)}<span class="cell-sub">${d.id}${multi ? ` · ${d.items.length} items` : ""}</span></span></span></td>
          <td>${A.esc(d.source)}<span class="cell-sub">${A.esc(d.supplier || "")}</span></td>
          <td class="num">${A.date(d.dateDelivered)}</td>
          <td class="text-right num">${A.int(exp)}</td>
          <td class="text-right num">${counted ? A.int(rec) : '<span class="muted">—</span>'}</td>
          <td class="text-right num ${variance < 0 ? "text-danger" : variance > 0 ? "text-warn" : "muted"}">${counted ? (variance > 0 ? "+" : "") + A.int(variance) : "—"}</td>
          <td>${A.statusChip(d.status)}</td>
          <td class="actions"><button class="btn btn-sm ${d.status === "Posted" ? "btn-secondary" : "btn-primary"}" data-open="${d.id}">${d.status === "Logged" ? "Count" : d.status === "Counted" ? "Post" : "View"}</button></td>
        </tr>`;
          if (!isExp) return main;
          const itemRows = d.items
            .map((it, i) => {
              const posted = itemPosted(d, i);
              const got = it.received;
              const v = got == null ? null : got - it.expected;
              let stage, action;
              if (posted) {
                stage = A.chip("Posted", "good");
                action = `<span class="muted">Done</span>`;
              } else if (d.status === "Logged") {
                stage = A.chip("To count", "warn");
                action = `<button class="btn btn-sm btn-secondary" data-open="${d.id}">Count first</button>`;
              } else if (!qtyToPost(it)) {
                stage = A.chip("Nothing received", "bad");
                action = `<span class="muted">—</span>`;
              } else {
                stage = A.chip("Ready to post", "info");
                action = `<a class="btn btn-sm btn-primary" href="${postHref(d, i)}">Post</a>`;
              }
              return `<tr class="item-row" data-item-of="${d.id}">
              <td><div class="item-name">${A.esc(it.name)}</div></td>
              <td>${A.esc(it.category)}</td>
              <td></td>
              <td class="text-right num">${A.int(it.expected)}</td>
              <td class="text-right num">${got == null ? '<span class="muted">—</span>' : A.int(got)}</td>
              <td class="text-right num ${v == null ? "muted" : v < 0 ? "text-danger" : v > 0 ? "text-warn" : "muted"}">${v == null ? "—" : (v > 0 ? "+" : "") + A.int(v)}</td>
              <td>${stage}</td>
              <td class="actions">${action}</td>
            </tr>`;
            })
            .join("");
          return main + itemRows;
        })
        .join("");
    }
    A.pager({
      el: A.qs("#dlvFoot"),
      total: rows.length,
      page,
      perPage,
      onPage: (p) => {
        page = p;
        render();
      },
    });
  }

  A.qs("#dlvBody").addEventListener("click", (e) => {
    const x = e.target.closest("[data-expand]");
    if (x) {
      const id = x.dataset.expand;
      expanded.has(id) ? expanded.delete(id) : expanded.add(id);
      render();
      return;
    }
    const b = e.target.closest("[data-open]");
    if (b) openDrawer(b.dataset.open);
  });
  ["#q", "#fStatus", "#fSource"].forEach((s) =>
    A.qs(s).addEventListener("input", apply),
  );

  /* ---------- delivery drawer ---------- */
  function openDrawer(id) {
    const d = DB.deliveries.find((x) => x.id === id);
    A.qs("#dlvTitle").textContent = d.ref;
    A.qs("#dlvSub").textContent =
      `${d.source} · ${d.supplier || ""} · delivered ${A.date(d.dateDelivered)}`;
    const body = A.qs("#dlvBodyDrawer"),
      foot = A.qs("#dlvFootDrawer");

    const exp = expOf(d),
      rec = recOf(d),
      dmg = dmgOf(d);
    const stages = ["Logged", "Counted", "Posted"];
    const stageIdx = stages.indexOf(d.status);

    // timeline
    const tl = `
      <div class="meta-strip">
        <div><small class="muted">Fund source</small><br><strong>${A.esc(d.fundSource)}</strong></div>
        <div><small class="muted">Logged by</small><br><strong>${A.esc(d.loggedBy)}</strong></div>
        <div><small class="muted">Total value</small><br><strong class="num">${A.money(valOf(d))}</strong></div>
      </div>
      <div class="timeline">
        <div class="tl-item done"><div class="dot"><i></i></div><div class="body"><strong>Delivery logged</strong><small class="muted">${A.date(d.dateDelivered)} · ${A.esc(d.loggedBy)}</small></div></div>
        <div class="tl-item ${stageIdx >= 1 ? "done" : "active"}"><div class="dot"><i></i></div><div class="body"><strong>Actual count</strong><small class="muted">${d.countedAt ? A.dateTime(d.countedAt) : "Not counted yet — enter received quantities below."}</small></div></div>
        <div class="tl-item ${stageIdx >= 2 ? "done" : stageIdx === 1 ? "active" : ""}"><div class="dot"><i></i></div><div class="body"><strong>Posted to inventory</strong><small class="muted">${d.postedAt ? A.dateTime(d.postedAt) + " · " + A.int(rec) + " assets created" : "Not posted yet."}</small></div></div>
      </div>`;

    // deed of donation flag
    const deed =
      d.source === "Donation"
        ? `<div class="note ${d.deedReceived ? "good" : "warn"}"><svg class="i"><use href="#${d.deedReceived ? "i-check-circle" : "i-alert"}"/></svg><div>${d.deedReceived ? "Deed of Donation received and filed." : "Deed of Donation not yet returned. Mark it received before posting so the items count as school property."}</div></div>`
        : "";

    // items: editable when counting, read-only otherwise
    const counting = d.status === "Logged";
    const canPost = d.status === "Counted";
    const itemRows = d.items
      .map((it, i) => {
        const recVal = it.received == null ? "" : it.received;
        const variance = it.received == null ? null : it.received - it.expected;
        return `<tr data-i="${i}">
        <td class="cell-main wrap">${A.esc(it.name)}<span class="cell-sub">${A.esc(it.category)}</span></td>
        <td class="text-right num">${A.int(it.expected)}</td>
        <td class="w-qty">${counting ? `<input class="input num rec" type="number" min="0" max="${it.expected}" value="${recVal}" placeholder="0" data-i="${i}">` : `<span class="num">${A.int(it.received)}</span>`}</td>
        <td class="w-qty">${counting ? `<input class="input num dmg" type="number" min="0" value="${it.damaged || 0}" data-i="${i}">` : `<span class="num">${A.int(it.damaged || 0)}</span>`}</td>
        <td class="text-right"><span class="var num" data-var="${i}">${variance == null ? "—" : (variance > 0 ? "+" : "") + A.int(variance)}</span></td>
        <td class="wrap">${counting ? `<input class="input remark" value="${A.esc(it.remarks || "")}" placeholder="Remarks" data-i="${i}">` : it.remarks ? A.esc(it.remarks) : '<span class="muted">—</span>'}</td>
        ${canPost ? `<td class="text-right">${itemPosted(d, i) ? A.chip("Posted", "good") : qtyToPost(it) ? `<a class="btn btn-sm btn-primary" href="${postHref(d, i)}">Post</a>` : '<span class="muted">—</span>'}</td>` : ""}
      </tr>`;
      })
      .join("");

    body.innerHTML = `${tl}${deed}
      ${d.notes ? `<div class="note info"><svg class="i"><use href="#i-info"/></svg><div>${A.esc(d.notes)}</div></div>` : ""}
      <div>
        <div class="section-title">${counting ? "Count what actually arrived" : "Delivered vs actual"}</div>
        <div class="line-items" style="margin-top:10px">
          <table class="table">
            <thead><tr><th>Item</th><th class="text-right">Delivered</th><th class="w-qty">Received</th><th class="w-qty">Damaged</th><th class="text-right">Variance</th><th>Remarks</th>${canPost ? '<th class="text-right">Post</th>' : ""}</tr></thead>
            <tbody>${itemRows}</tbody>
          </table>
          <div class="line-items-foot"><span class="muted">Totals</span><span class="muted">Delivered <strong>${A.int(exp)}</strong> · Received <strong id="recTotal">${A.int(rec)}</strong> · Damaged <strong id="dmgTotal">${A.int(dmg)}</strong></span></div>
        </div>
      </div>`;

    body.oninput = null;
    // footer actions by stage
    if (d.status === "Logged") {
      foot.innerHTML = `<button class="btn btn-secondary left" data-close type="button">Close</button>
        <button class="btn btn-primary" id="saveCount" type="button"><svg class="i"><use href="#i-clipboard"/></svg> Save count</button>`;
      // live variance
      body.oninput = () => {
        let rt = 0,
          dt = 0;
        A.qsa("#dlvBodyDrawer tbody tr").forEach((tr) => {
          const i = Number(tr.dataset.i);
          const r = Number(A.qs(".rec", tr)?.value || 0),
            dd = Number(A.qs(".dmg", tr)?.value || 0);
          rt += r;
          dt += dd;
          const v = r - d.items[i].expected;
          const el = A.qs(`[data-var="${i}"]`, body);
          el.textContent = (v > 0 ? "+" : "") + A.int(v);
          el.className =
            "var num " +
            (v < 0 ? "text-danger" : v > 0 ? "text-warn" : "muted");
        });
        A.qs("#recTotal").textContent = A.int(rt);
        A.qs("#dmgTotal").textContent = A.int(dt);
      };
      A.qs("#saveCount").addEventListener("click", async () => {
        const ok = await A.confirm({
          title: "Save this count?",
          text: "The received and damaged quantities will be recorded. You can still post the delivery afterwards.",
          okLabel: "Save count",
          tone: "good",
        });
        if (ok) {
          A.close("dlvDrawer");
          A.toast("Count saved. Delivery is ready to post.");
        }
      });
    } else if (d.status === "Counted") {
      const left = d.items.reduce(
        (n, it, i) => n + (itemPosted(d, i) ? 0 : qtyToPost(it)),
        0,
      );
      const anyPosted = d.items.some((_, i) => itemPosted(d, i));
      const deedBlock =
        d.source === "Donation" && !d.deedReceived
          ? `<label class="checkbox left" id="deedChk"><input type="checkbox"> Deed of Donation received and filed</label>`
          : `<span class="left"></span>`;
      foot.innerHTML = `${deedBlock}
        <button class="btn btn-secondary" data-close type="button">Close</button>
        <button class="btn btn-primary" id="postBtn" type="button"><svg class="i"><use href="#i-archive"/></svg> Post ${anyPosted ? "remaining " : "all "}${A.int(left)} to inventory</button>`;
      A.qs("#postBtn").addEventListener("click", async () => {
        if (
          d.source === "Donation" &&
          !d.deedReceived &&
          !A.qs("#deedChk input").checked
        ) {
          return A.toast(
            "Mark the Deed of Donation received before posting.",
            "bad",
          );
        }
        const ok = await A.confirm({
          title: `Post ${A.int(left)} assets to inventory?`,
          text: `This creates ${A.int(left)} asset record${left > 1 ? "s" : ""} under ${d.fundSource}. Damaged units are flagged separately. This can't be undone from here.`,
          okLabel: "Confirm and post",
          tone: "good",
        });
        if (ok) {
          A.close("dlvDrawer");
          A.toast(`${A.int(left)} assets posted to inventory.`);
        }
      });
    } else {
      foot.innerHTML = `<a class="btn btn-secondary left" href="custodian_assets.php"><svg class="i"><use href="#i-package"/></svg> View in assets</a>
        <button class="btn btn-secondary" data-close type="button">Close</button>
        <button class="btn btn-primary" id="printBtn" type="button"><svg class="i"><use href="#i-printer"/></svg> Print report</button>`;
      A.qs("#printBtn").addEventListener("click", () => printDeliveryReport(d));
    }
    A.open("dlvDrawer");
  }

  /* ---------- print report: delivery report for one delivery (PO, DOD, IAR, DR ... any document type) ----------
     Same approach as the assets and physical count reports: builds #printSheet from the live data,
     then opens the print dialog (choose "Save as PDF" to keep a copy). Layout classes (ps-*) live in
     custodian.css under "print: property inventory report". */
  const SCHOOL_NAME = document.body.dataset.school || "Lagro High School";
  const DIVISION_NAME = "Schools Division Office of Quezon City";
  const FORM_TITLE = "DELIVERY REPORT";
  const RECEIVED_BY = document.body.dataset.user || "Property Custodian";
  const RECEIVED_ROLE = document.body.dataset.role || "Property Custodian";
  const PAGE_CSS =
    '@page{size:A4 landscape;margin:12mm 12mm 14mm;@bottom-right{content:"Page " counter(page) " of " counter(pages);font-size:8.5pt;font-family:"Neue Montreal",Arial,sans-serif}}';

  function printDeliveryReport(d) {
    let sheet = A.qs("#printSheet");
    if (!sheet) {
      sheet = document.createElement("div");
      sheet.id = "printSheet";
      document.body.appendChild(sheet);
    }
    let style = A.qs("#psPageStyle");
    if (!style) {
      style = document.createElement("style");
      style.id = "psPageStyle";
      document.head.appendChild(style);
    }
    style.textContent = PAGE_CSS; // landscape A4, only while printing from this page

    const stamp = A.dateTime(new Date().toISOString());
    const exp = expOf(d),
      rec = recOf(d),
      dmg = dmgOf(d);
    const qtyOf = (it) => (it.received != null ? it.received : it.expected) || 0;
    const value = d.items.reduce(
      (n, it) => n + qtyOf(it) * (it.unitValue || 0),
      0,
    );
    const sgn = (n) => (n > 0 ? "+" : "") + A.int(n);

    const rows = d.items
      .map((it, i) => {
        const v = it.received == null ? null : it.received - it.expected;
        return `<tr>
          <td class="c">${i + 1}</td>
          <td>${A.esc(it.name)}<br><span style="color:#444">${A.esc(it.category)}</span></td>
          <td class="c">${A.int(it.expected)}</td>
          <td class="c">${it.received == null ? "—" : A.int(it.received)}</td>
          <td class="c">${A.int(it.damaged || 0)}</td>
          <td class="c">${v == null ? "—" : sgn(v)}</td>
          <td class="n">${A.money(it.unitValue || 0)}</td>
          <td class="n">${A.money(qtyOf(it) * (it.unitValue || 0))}</td>
          <td>${A.esc(it.remarks || "") || "—"}</td></tr>`;
      })
      .join("");

    const deed =
      d.source === "Donation"
        ? `<p class="ps-account"><b>Deed of Donation:</b> ${d.deedReceived ? "received and filed." : "not yet received."}</p>`
        : "";
    const notes = d.notes
      ? `<p class="ps-account"><b>Notes:</b> ${A.esc(d.notes)}</p>`
      : "";

    sheet.className = "";
    sheet.innerHTML = `
      <header class="ps-head">
        <div class="ps-logo"></div>
        <div class="ps-title">
          <div class="gov">Republic of the Philippines<br><b>Department of Education</b><br>${A.esc(DIVISION_NAME)}</div>
          <div class="school">${A.esc(SCHOOL_NAME)}</div>
          <h1>${A.esc(FORM_TITLE)}</h1>
          <div class="sub">Document no. ${A.esc(d.ref)}</div>
        </div>
        <div class="ps-logo"></div>
      </header>
      <p class="ps-account">Items delivered to <b>${A.esc(SCHOOL_NAME)}</b> under <b>${A.esc(d.ref)}</b>, counted against the delivery and accepted by the Property Custodian, <b>${A.esc(RECEIVED_BY)}</b>.</p>
      <div class="ps-meta">
        <div><b>Source:</b> ${A.esc(d.source)}${d.supplier ? " · " + A.esc(d.supplier) : ""}</div>
        <div><b>Date delivered:</b> ${A.date(d.dateDelivered)}</div>
        <div><b>Fund source:</b> ${A.esc(d.fundSource)}</div>
        <div><b>Logged by:</b> ${A.esc(d.loggedBy || "—")}</div>
        <div><b>Date counted:</b> ${d.countedAt ? A.date(d.countedAt) : "—"}</div>
        <div><b>Date posted:</b> ${d.postedAt ? A.date(d.postedAt) : "—"}</div>
      </div>
      ${deed}${notes}

      <section class="ps-sec">
        <h2>Items delivered and received <span>· ${d.items.length} item${d.items.length === 1 ? "" : "s"}</span></h2>
        <table class="ps-table">
          <thead><tr>
            <th class="c" style="width:4%">No.</th><th style="width:24%">Item</th>
            <th class="c" style="width:9%">Delivered</th><th class="c" style="width:8%">Actual</th>
            <th class="c" style="width:9%">Damaged</th><th class="c" style="width:9%">Variance</th>
            <th class="n" style="width:10%">Unit value</th><th class="n" style="width:12%">Total value</th>
            <th style="width:15%">Remarks</th>
          </tr></thead>
          <tbody>${rows}
            <tr class="ps-total"><td colspan="2" class="r">TOTAL</td>
              <td class="c">${A.int(exp)}</td><td class="c">${A.int(rec)}</td><td class="c">${A.int(dmg)}</td>
              <td class="c">${sgn(rec - exp)}</td><td></td><td class="n">${A.money(value)}</td><td></td></tr>
          </tbody>
        </table>
      </section>

      <section class="ps-close">
        <table class="ps-table ps-summary">
          <thead><tr><th>Summary</th><th class="n" style="width:38%">Total</th></tr></thead>
          <tbody>
            <tr><td>Units delivered</td><td class="n">${A.int(exp)}</td></tr>
            <tr><td>Units received (actual)</td><td class="n">${A.int(rec)}</td></tr>
            <tr><td>Units damaged</td><td class="n">${A.int(dmg)}</td></tr>
            <tr><td>Variance (actual − delivered)</td><td class="n">${sgn(rec - exp)}</td></tr>
            <tr class="ps-total"><td class="r">Total value received</td><td class="n">${A.money(value)}</td></tr>
          </tbody>
        </table>
        <p class="ps-cert">I certify that the items listed above were inspected and counted against the delivery, and that the quantities received are true and correct${d.postedAt ? ", and were posted to the school inventory on " + A.date(d.postedAt) : ""}.</p>
        <div class="ps-sign">
          <div><span class="role">Received by:</span><div class="who"><b>${A.esc(RECEIVED_BY)}</b>${A.esc(RECEIVED_ROLE)} · Signature over printed name<br>Date: ________________</div></div>
          <div><span class="role">Noted by:</span><div class="who"><b>&nbsp;</b>School Head<br>Date: ________________</div></div>
        </div>
        <div class="ps-foot">Generated by Assetly · ${stamp}</div>
      </section>`;

    document.body.classList.add("ps-active"); // tells custodian.css to print only #printSheet
    window.print();
  }
  window.addEventListener("afterprint", () => {
    document.body.classList.remove("ps-active");
    const s = A.qs("#psPageStyle");
    if (s) s.remove();
  });

  /* ---------- log new delivery ---------- */
  const logModal = A.qs("#logModal"),
    logForm = A.qs("#logForm");
  DB.deliverySources.forEach((s) =>
    A.qs("#l-source").insertAdjacentHTML(
      "beforeend",
      `<option>${A.esc(s)}</option>`,
    ),
  );
  DB.fundSources.forEach((s) =>
    A.qs("#l-fund").insertAdjacentHTML(
      "beforeend",
      `<option>${A.esc(s)}</option>`,
    ),
  );

  let itemSeed = 0;
  function itemRow() {
    const id = itemSeed++;
    return `<tr data-row="${id}">
      <td><input class="input iname" placeholder="e.g. Monoblock Chair"></td>
      <td class="w-cat"><select class="select icat"><option value="">Category</option>${DB.categories.map((c) => `<option>${A.esc(c)}</option>`).join("")}</select></td>
      <td class="w-qty"><input class="input num iqty" type="number" min="1" value="1"></td>
      <td class="w-val"><input class="input num ival" type="number" min="0" step="0.01" placeholder="0.00"></td>
      <td class="w-act"><button class="icon-btn sm danger" type="button" data-rm="${id}" aria-label="Remove"><svg class="i"><use href="#i-x"/></svg></button></td>
    </tr>`;
  }
  function logTotal() {
    let t = 0;
    A.qsa("#logItems tr").forEach((tr) => {
      t +=
        Number(A.qs(".iqty", tr).value || 0) *
        Number(A.qs(".ival", tr).value || 0);
    });
    A.qs("#logTotal").textContent = A.money(t);
  }
  A.qs("#logBtn").addEventListener("click", () => {
    logForm.reset();
    A.qs("#logItems").innerHTML = itemRow() + itemRow();
    logTotal();
    A.qs("#donationNote").hidden = true;
    A.qs("#l-date").value = A.todayISO();
    A.qs("#logHint").textContent = "";
    A.open(logModal);
  });
  A.qs("#addItem").addEventListener("click", () => {
    A.qs("#logItems").insertAdjacentHTML("beforeend", itemRow());
  });
  A.qs("#logItems").addEventListener("click", (e) => {
    const rm = e.target.closest("[data-rm]");
    if (rm && A.qsa("#logItems tr").length > 1) {
      rm.closest("tr").remove();
      logTotal();
    }
  });
  A.qs("#logItems").addEventListener("input", logTotal);
  A.qs("#l-source").addEventListener("change", (e) => {
    A.qs("#donationNote").hidden = e.target.value !== "Donation";
    A.qs("#l-refLabel").textContent =
      DB.deliveryDocs[e.target.value] || "Document no.";
  });
  logForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const hasItems = A.qsa("#logItems tr").some((tr) =>
      A.qs(".iname", tr).value.trim(),
    );
    if (!A.validate(logForm) || !hasItems) {
      A.toast("Complete the required fields and at least one item.", "bad");
      return;
    }
    const count = A.qsa("#logItems tr").filter((tr) =>
      A.qs(".iname", tr).value.trim(),
    ).length;
    A.close(logModal);
    A.toast(
      `Delivery logged with ${count} item line${count > 1 ? "s" : ""}. Count it when it arrives.`,
    );
  });

  apply();

  /* deep link from the Assets page: custodian_deliveries.php?open=DLV-2026-011 */
  const deep = new URLSearchParams(location.search).get("open");
  if (deep && DB.deliveries.some((d) => d.id === deep)) openDrawer(deep);
})();