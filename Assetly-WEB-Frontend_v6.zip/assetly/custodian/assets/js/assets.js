/* Assets page — unit-level tracking (Model B).
   each asset record is a "bundle"; every physical unit under it is independently
   editable (location, condition, property no). The table groups units by bundle,
   expands to show units, supports per-unit edit and "Edit selected" bulk edit.
   shared fields (name, category, value, fund source) are edited via Edit asset */
(function () {
  const A = window.Assetly, DB = window.DB;

  /* B=build editable per-unit data on each record once (demo-mutable). */
  const records = DB.assets.map((r) => ({
    ...r,
    unitData: r.units.map((uid, i) => ({
      unitId: uid, building: r.building, room: r.room, assignedTo: r.assignedTo || '',
      condition: r.condition, propertyNo: i === 0 ? (r.propertyNo || '') : ''
    }))
  }));
  const recordById = (id) => records.find((r) => r.id === id);

  /* assigned to = the person picked in the form (assignedTo), else whoever holds the unit's room (see DB.teacherFor),
     else the Property Office (the default holder) */
  const teacherOf = (u) => u.assignedTo || DB.teacherFor(u.building, u.room) || 'Property Office';
  const teachersOf = (units) => [...new Set(units.map(teacherOf).filter(Boolean))];
  const initialsOf = (n) => n.split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  const teacherCell = (names) => names.length === 0
    ? '<span class="muted">Unassigned</span>'
    : names.length === 1
      ? `<span class="teacher-cell"><span class="mini-av">${A.esc(initialsOf(names[0]))}</span>${A.esc(names[0])}</span>`
      : `<span class="muted" title="${A.esc(names.join(', '))}">${names.length} teachers</span>`;
  const allUnits = () => records.flatMap((r) => r.unitData);

  let sortKey = 'id', sortDir = 'asc', page = 1;
  const perPage = 10;
  const expanded = new Set();
  const selected = new Set();   // unitIds
  let viewRows = [];            // filtered records for current render

  /* KPIs — counted per unit so divergence is reflected */
  function renderKpis() {
    const u = allUnits();
    const by = (c) => u.filter((x) => x.condition === c).length;
    A.qs('#assetKpis').innerHTML = [
      { v: u.length, l: 'Total', ic: 'brand', icon: 'i-layers' },
      { v: by('Operational'), l: 'Operational', ic: 'good', icon: 'i-check-circle' },
      { v: by('Under maintenance'), l: 'Maintenance', ic: 'warn', icon: 'i-wrench' },
      { v: by('For disposal'), l: 'For disposal', ic: 'bad', icon: 'i-trash' }
    ].map((k) => `<div class="kpi"><div><div class="v num">${A.int(k.v)}</div><div class="l">${k.l}</div></div><div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div></div>`).join('');
  }

  /* populate filter + modal selects */
  const fill = (sel, items, withBlank) => { const el = A.qs(sel); if (withBlank) {} items.forEach((i) => el.insertAdjacentHTML('beforeend', `<option>${A.esc(i)}</option>`)); };
  fill('#fBuilding', DB.buildings); A.qs('#fBuilding').insertAdjacentHTML('beforeend', '<option value="__none">Not assigned yet</option>'); fill('#fCategory', DB.categories); fill('#fCondition', DB.conditions); fill('#fFund', DB.fundSources);
  fill('#u-building', DB.buildings); A.qs('#u-building').insertAdjacentHTML('afterbegin', '<option value="">Not assigned yet</option>'); fill('#u-condition', DB.conditions);
  fill('#be-building', DB.buildings); fill('#be-condition', DB.conditions);

  /* units of a record that pass the active unit-level filters (building, condition) */
  function unitsOf(r) {
    const fb = A.qs('#fBuilding').value, fcon = A.qs('#fCondition').value;
    return r.unitData.filter((u) => (!fb || (fb === '__none' ? !u.building : u.building === fb)) && (!fcon || u.condition === fcon));
  }

  function apply() {
    const q = A.qs('#q').value.trim().toLowerCase();
    const fc = A.qs('#fCategory').value, ff = A.qs('#fFund').value;
    viewRows = records.filter((r) => {
      if (fc && r.category !== fc) return false;
      if (ff && r.fundSource !== ff) return false;
      if (q && !(r.name.toLowerCase().includes(q) || r.id.toLowerCase().includes(q) ||
                 (r.propertyNo || '').toLowerCase().includes(q) || r.units.some((u) => u.toLowerCase().includes(q)) ||
                 teachersOf(r.unitData).some((t) => t.toLowerCase().includes(q)))) return false;
      return unitsOf(r).length > 0;
    });
    viewRows.forEach((r) => { r.teacherKey = teachersOf(r.unitData).join(', '); });
    viewRows = A.sortBy(viewRows, sortKey === 'qty' ? 'qty' : sortKey, sortDir);
    page = 1; render();
  }

  function locSummary(units) {
    const set = [...new Map(units.map((u) => [`${u.building}|${u.room}`, u])).values()];
    return set.length === 1
      ? (set[0].building ? `${A.esc(set[0].building)}<span class="cell-sub">Room ${A.esc(set[0].room)}</span>` : '<span class="muted">Not assigned yet</span>')
      : `<span class="muted">${set.length} locations</span>`;
  }
  function condSummary(units) {
    const set = [...new Set(units.map((u) => u.condition))];
    if (set.length === 1) return A.conditionChip(set[0]);
    const counts = set.map((c) => `${units.filter((u) => u.condition === c).length} ${c}`).join(', ');
    return `<span class="tag" title="${A.esc(counts)}">Mixed (${set.length})</span>`;
  }

  function render() {
    const body = A.qs('#assetBody');
    const slice = viewRows.slice((page - 1) * perPage, page * perPage);
    if (!slice.length) {
      body.innerHTML = `<tr><td colspan="12"><div class="empty"><svg class="i"><use href="#i-search"/></svg><strong>No assets match your filters</strong>Try clearing the search or a filter.</div></td></tr>`;
    } else {
      body.innerHTML = slice.map((r) => {
        const units = unitsOf(r);
        const multi = r.units.length > 1;
        const isExp = expanded.has(r.id);
        const allSel = units.length > 0 && units.every((u) => selected.has(u.unitId));
        const someSel = units.some((u) => selected.has(u.unitId));
        const groupRow = `
          <tr class="group-row" data-group="${r.id}">
            <td class="check"><input type="checkbox" data-group-cb="${r.id}" ${allSel ? 'checked' : ''} aria-label="Select all units of ${A.esc(r.name)}"></td>
            <td><span class="id-cell">
              ${multi ? `<button class="icon-btn sm expander" data-expand="${r.id}" aria-label="${isExp ? 'Collapse' : 'Expand'}"><svg class="i i-sm" style="transition:transform .15s;${isExp ? 'transform:rotate(90deg)' : ''}"><use href="#i-chevron-right"/></svg></button>` : ''}
              <span class="id num">${r.id}</span>${multi ? `<span class="tag mono">×${r.units.length}</span>` : ''}</span></td>
            <td class="cell-main">${A.esc(r.name)}${r.openTickets ? ` <span class="tag" style="background:var(--bad-bg);color:var(--bad)">${r.openTickets} open</span>` : ''}</td>
            <td>${A.esc(r.category)}</td>
            <td class="text-right num">${units.length}</td>
            <td>${locSummary(units)}</td>
            <td>${teacherCell(teachersOf(units))}</td>
            <td class="num">${A.date(r.dateAcquired)}</td>
            <td class="text-right num">${A.money(r.unitValue)}</td>
            <td><span class="tag">${A.esc(r.fundSource)}</span></td>
            <td>${condSummary(units)}</td>
            <td class="actions"><div class="row-actions">
              <button class="icon-btn sm brand" data-view="${r.id}" aria-label="View"><svg class="i"><use href="#i-eye"/></svg></button>
              <a class="icon-btn sm brand" href="custodian_add_asset.php?edit=${r.id}" aria-label="Edit shared details"><svg class="i"><use href="#i-pencil"/></svg></a>
              <button class="icon-btn sm danger" data-del-group="${r.id}" aria-label="Move bundle to trash"><svg class="i"><use href="#i-trash"/></svg></button>
            </div></td>
          </tr>`;
        let unitRows = '';
        if (multi && isExp) {
          unitRows = units.map((u) => `
            <tr class="unit-row" data-unit-row="${u.unitId}">
              <td class="check"><input type="checkbox" data-unit-cb="${u.unitId}" ${selected.has(u.unitId) ? 'checked' : ''} aria-label="Select ${u.unitId}"></td>
              <td><span class="id num unit-id">${u.unitId}</span></td>
              <td class="muted">— unit —</td>
              <td></td>
              <td class="text-right num">1</td>
              <td>${u.building ? `${A.esc(u.building)}<span class="cell-sub">Room ${A.esc(u.room)}</span>` : '<span class="muted">Not assigned yet</span>'}</td>
              <td>${teacherCell(teachersOf([u]))}</td>
              <td></td>
              <td></td>
              <td></td>
              <td>${A.conditionChip(u.condition)}</td>
              <td class="actions"><div class="row-actions">
                <button class="icon-btn sm brand" data-edit-unit="${u.unitId}" aria-label="Edit unit"><svg class="i"><use href="#i-pencil"/></svg></button>
                <button class="icon-btn sm danger" data-del-unit="${u.unitId}" aria-label="Move unit to trash"><svg class="i"><use href="#i-trash"/></svg></button>
              </div></td>
            </tr>`).join('');
        }
        return groupRow + unitRows;
      }).join('');
    }
    A.pager({ el: A.qs('#assetFoot'), total: viewRows.length, page, perPage, onPage: (p) => { page = p; render(); } });
    syncHeader();
    A.qsa('#assetTable thead th.sortable').forEach((th) => {
      th.classList.remove('sorted-asc', 'sorted-desc');
      if (th.dataset.sort === sortKey) th.classList.add(sortDir === 'asc' ? 'sorted-asc' : 'sorted-desc');
    });
  }

  /* selection */
  function syncHeader() {
    const head = A.qs('#assetTable thead input[type=checkbox]');
    const all = viewRows.flatMap((r) => unitsOf(r).map((u) => u.unitId));
    const chosen = all.filter((id) => selected.has(id));
    head.checked = all.length > 0 && chosen.length === all.length;
    head.indeterminate = chosen.length > 0 && chosen.length < all.length;
    A.qs('#bulkCount').textContent = selected.size;
    A.qs('#bulkLabel').textContent = (selected.size === 1 ? 'unit' : 'units') + ' selected';
    A.qs('#bulkbar').classList.toggle('is-visible', selected.size > 0);
  }
  A.qs('#assetTable thead input[type=checkbox]').addEventListener('change', (e) => {
    const all = viewRows.flatMap((r) => unitsOf(r).map((u) => u.unitId));
    if (e.target.checked) all.forEach((id) => selected.add(id)); else all.forEach((id) => selected.delete(id));
    render();
  });
  A.qs('#assetBody').addEventListener('change', (e) => {
    const g = e.target.closest('[data-group-cb]'), u = e.target.closest('[data-unit-cb]');
    if (g) {
      const r = recordById(g.dataset.groupCb);
      unitsOf(r).forEach((x) => e.target.checked ? selected.add(x.unitId) : selected.delete(x.unitId));
      render();
    } else if (u) {
      e.target.checked ? selected.add(u.dataset.unitCb) : selected.delete(u.dataset.unitCb);
      render();
    }
  });

  /* row actions */
  A.qs('#assetBody').addEventListener('click', async (e) => {
    const exp = e.target.closest('[data-expand]');
    const view = e.target.closest('[data-view]');
    const editUnit = e.target.closest('[data-edit-unit]');
    const delGroup = e.target.closest('[data-del-group]');
    const delUnit = e.target.closest('[data-del-unit]');
    if (exp) { const id = exp.dataset.expand; expanded.has(id) ? expanded.delete(id) : expanded.add(id); render(); return; }
    if (view) return openView(view.dataset.view);
    if (editUnit) return openUnitEdit(editUnit.dataset.editUnit);
    if (delGroup) {
      const r = recordById(delGroup.dataset.delGroup);
      const ok = await A.confirm({ title: 'Move this bundle to trash?', text: `“${r.name}” (${r.units.length} unit${r.units.length > 1 ? 's' : ''}) will be moved to trash. You can restore it later.`, okLabel: 'Move to trash', tone: 'bad' });
      if (ok) A.toast('Bundle moved to trash.');
    }
    if (delUnit) {
      const ok = await A.confirm({ title: 'Move this unit to trash?', text: `Unit ${delUnit.dataset.delUnit} will be moved to trash separately from its bundle.`, okLabel: 'Move to trash', tone: 'bad' });
      if (ok) A.toast('Unit moved to trash.');
    }
  });

  /* sorting */
  A.qsa('#assetTable thead th.sortable').forEach((th) => th.addEventListener('click', () => {
    const k = th.dataset.sort;
    if (sortKey === k) sortDir = sortDir === 'asc' ? 'desc' : 'asc'; else { sortKey = k; sortDir = 'asc'; }
    apply();
  }));
  ['#q', '#fBuilding', '#fCategory', '#fCondition', '#fFund'].forEach((s) => A.qs(s).addEventListener('input', () => { apply(); }));

  /* view drawer — shows the bundle with a per-unit breakdown */
  function openView(id) {
    const r = recordById(id);
    A.qs('#viewTitle').textContent = r.name;
    A.qs('#viewSub').textContent = `${r.id}${r.units.length > 1 ? ` · ${r.units.length} units` : ''}`;
    A.qs('#viewEdit').href = 'custodian_add_asset.php?edit=' + r.id;
    const tickets = DB.tickets.filter((t) => t.assetId === r.id);
    const unitTable = r.units.length > 1 ? `
      <div><div class="section-title">Units (${r.unitData.length})</div>
      <div class="table-wrap" style="border:1px solid var(--line);border-radius:8px;margin-top:8px">
        <table class="table compact"><thead><tr><th>Unit ID</th><th>Location</th><th>Assigned teacher</th><th>Condition</th><th>Property no.</th></tr></thead>
        <tbody>${r.unitData.map((u) => `<tr><td class="num">${u.unitId}</td><td>${A.esc(u.building)} · ${A.esc(u.room)}</td><td>${teacherCell(teachersOf([u]))}</td><td>${A.conditionChip(u.condition)}</td><td class="muted">${u.propertyNo || '—'}</td></tr>`).join('')}</tbody></table>
      </div></div>` : '';
    A.qs('#viewBody').innerHTML = `
      <div class="meta-strip">
        <div><small class="muted">Units</small><br><strong class="num">${r.unitData.length}</strong></div>
        <div><small class="muted">Unit value</small><br><strong class="num">${A.money(r.unitValue)}</strong></div>
        <div><small class="muted">Total value</small><br><strong class="num">${A.money(r.unitValue * r.unitData.length)}</strong></div>
      </div>
      <dl class="dl">
        <div><dt>Category</dt><dd>${A.esc(r.category)}</dd></div>
        <div><dt>Assigned teacher</dt><dd>${teachersOf(r.unitData).length ? teachersOf(r.unitData).map(A.esc).join(', ') : '<span class="muted">Unassigned</span>'}</dd></div>
        <div><dt>Fund source</dt><dd>${A.esc(r.fundSource)}${r.fundCode ? ` · Code ${r.fundCode}` : ''}</dd></div>
        <div><dt>Date acquired</dt><dd>${A.date(r.dateAcquired)}</dd></div>
        ${(() => { const d = r.deliveryRef && (DB.deliveries || []).find((x) => x.id === r.deliveryRef); return d ? `<div><dt>Delivered via</dt><dd><a href="custodian_deliveries.php?open=${d.id}">${d.id}</a> · ${A.esc(d.ref)}<br><small class="muted">${A.esc(d.source)}${d.supplier ? ' · ' + A.esc(d.supplier) : ''}</small></dd></div>` : ''; })()}
        <div><dt>Last modified</dt><dd>${A.date(r.modifiedAt)}</dd></div>
        ${r.description ? `<div class="span-2"><dt>Description</dt><dd>${A.esc(r.description)}</dd></div>` : ''}
      </dl>
      ${unitTable}
      ${tickets.length ? `<div><div class="section-title">Defect tickets (${tickets.length})</div>
        <div style="margin-top:8px;display:flex;flex-direction:column;gap:6px">${tickets.map((t) => `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 10px;border:1px solid var(--line);border-radius:8px"><span><strong style="font-size:12.5px">${A.esc(t.defectType)}</strong><br><small class="muted">${t.id} · ${A.esc(t.submittedBy)}</small></span>${A.statusChip(t.status)}</div>`).join('')}</div></div>` : ''}`;
    A.open('viewDrawer');
  }

  /* per-unit edit */
  let editingUnit = null;
  function openUnitEdit(unitId) {
    const r = records.find((x) => x.unitData.some((u) => u.unitId === unitId));
    const u = r.unitData.find((x) => x.unitId === unitId);
    editingUnit = { r, u };
    A.qs('#unitSub').textContent = `${unitId} · ${r.name}`;
    A.qs('#u-building').value = u.building; A.qs('#u-room').value = u.room;
    A.qs('#u-condition').value = u.condition; A.qs('#u-propno').value = u.propertyNo || '';
    A.open('unitModal');
  }
  A.qs('#unitForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const { u } = editingUnit;
    u.building = A.qs('#u-building').value; u.room = A.qs('#u-room').value;
    u.condition = A.qs('#u-condition').value; u.propertyNo = A.qs('#u-propno').value.trim();
    A.close('unitModal'); renderKpis(); render(); A.toast(`Unit ${u.unitId} updated.`);
  });

  /* bulk edit selected units */
  const toggleGroup = (chk, wrap) => { wrap.style.opacity = chk.checked ? '1' : '.5'; wrap.style.pointerEvents = chk.checked ? 'auto' : 'none'; };
  A.qs('#be-locEnable').addEventListener('change', (e) => toggleGroup(e.target, A.qs('#be-locFields')));
  A.qs('#be-condEnable').addEventListener('change', (e) => toggleGroup(e.target, A.qs('#be-condFields')));
  A.qs('#bulkEdit').addEventListener('click', () => {
    if (!selected.size) return;
    A.qs('#be-locEnable').checked = false; A.qs('#be-condEnable').checked = false;
    toggleGroup(A.qs('#be-locEnable'), A.qs('#be-locFields')); toggleGroup(A.qs('#be-condEnable'), A.qs('#be-condFields'));
    A.qs('#be-room').value = ''; A.qs('#be-building').selectedIndex = 0; A.qs('#be-condition').selectedIndex = 0;
    A.qs('#bulkEditSub').textContent = `${selected.size} unit${selected.size > 1 ? 's' : ''} selected`;
    A.qs('#bulkEditHint').textContent = '';
    A.open('bulkEditModal');
  });
  A.qs('#bulkEditForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const doLoc = A.qs('#be-locEnable').checked, doCond = A.qs('#be-condEnable').checked;
    if (!doLoc && !doCond) { A.qs('#bulkEditHint').textContent = 'Tick at least one field to change.'; return; }
    const building = A.qs('#be-building').value, room = A.qs('#be-room').value.trim(), condition = A.qs('#be-condition').value;
    if (doLoc && !room) { A.qs('#bulkEditHint').textContent = 'Enter a room for the new location.'; return; }
    let n = 0;
    records.forEach((r) => r.unitData.forEach((u) => {
      if (!selected.has(u.unitId)) return;
      if (doLoc) { u.building = building; u.room = room; }
      if (doCond) u.condition = condition;
      n++;
    }));
    A.close('bulkEditModal'); selected.clear(); renderKpis(); render();
    A.toast(`${n} unit${n > 1 ? 's' : ''} updated.`);
  });
  A.qs('#bulkClear').addEventListener('click', () => { selected.clear(); render(); });
  A.qs('#bulkDelete').addEventListener('click', async () => {
    if (!selected.size) return;
    const ok = await A.confirm({ title: `Move ${selected.size} unit${selected.size > 1 ? 's' : ''} to trash?`, text: 'Selected units will be moved to trash and can be restored later.', okLabel: 'Move to trash', tone: 'bad' });
    if (ok) { A.toast(`${selected.size} unit${selected.size > 1 ? 's' : ''} moved to trash.`); selected.clear(); render(); }
  });
  A.qs('#bulkExport').addEventListener('click', () => openExport(selected.size));

  /* ---------- import (unchanged) ---------- */
  const importModal = A.qs('#importModal');
  let importStep = 1, importedRows = [];
  A.qs('#importBtn').addEventListener('click', () => { resetImport(); A.open(importModal); });
  function resetImport() {
    importStep = 1; importedRows = [];
    A.qs('#importStep1').hidden = false; A.qs('#importStep2').hidden = true;
    A.qs('#importNext').textContent = 'Review file'; A.qs('#importNext').disabled = true;
    A.qs('#fileInput').value = ''; A.qs('#importHint').textContent = '';
    setSteps(1);
  }
  const setSteps = (n) => A.qsa('.step', importModal).forEach((s) => { const i = Number(s.dataset.step); s.classList.toggle('is-active', i === n); s.classList.toggle('is-done', i < n); });
  const dz = A.qs('#dropzone'), fi = A.qs('#fileInput');
  ['dragover', 'dragenter'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('is-over'); }));
  ['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove('is-over'); }));
  dz.addEventListener('drop', (e) => { if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]); });
  fi.addEventListener('change', () => { if (fi.files[0]) handleFile(fi.files[0]); });
  function handleFile(file) {
    A.qs('#fileName').textContent = file.name;
    A.qs('#importNext').disabled = false;
    A.qs('#importHint').textContent = file.name + ' ready to review';
    /* demo rows. Building, Room and Fund source are required columns:
       a blank or unknown value makes the row invalid */
    importedRows = records.slice(0, 6).map((a, i) => {
      const row = {
        ...a,
        building: i === 2 ? '' : a.building,
        room: i === 3 ? '' : a.room,
        fundSource: i === 5 ? '' : a.fundSource
      };
      const error = !row.building ? 'Building is required'
        : !DB.buildings.includes(row.building) ? 'Unknown building'
        : !String(row.room || '').trim() ? 'Room is required'
        : !row.fundSource ? 'Fund source is required'
        : !DB.fundSources.includes(row.fundSource) ? 'Unknown fund source'
        : i === 4 ? 'Unknown category' : '';
      return { ...row, valid: !error, error };
    });
  }
  A.qs('#importNext').addEventListener('click', () => {
    if (importStep === 1) {
      importStep = 2; setSteps(2);
      A.qs('#importStep1').hidden = true; A.qs('#importStep2').hidden = false;
      const valid = importedRows.filter((r) => r.valid).length, errs = importedRows.length - valid;
      A.qs('#validCount').textContent = `${valid} valid`;
      const ec = A.qs('#errorCount'); ec.hidden = errs === 0; ec.textContent = `${errs} error${errs > 1 ? 's' : ''}`;
      const miss = '<span class="text-danger">Missing</span>';
      A.qs('#previewTable').innerHTML = `
        <thead><tr><th>Row</th><th>Asset name</th><th>Category</th><th class="text-right">Qty</th><th>Building</th><th>Room</th><th>Fund source</th><th>Status</th></tr></thead>
        <tbody>${importedRows.map((r, i) => `<tr><td class="num">${i + 1}</td><td class="cell-main">${A.esc(r.name)}</td><td>${A.esc(r.category)}</td><td class="text-right num">${r.units.length}</td><td>${r.building ? A.esc(r.building) : miss}</td><td>${r.room ? A.esc(r.room) : miss}</td><td>${r.fundSource ? A.esc(r.fundSource) : miss}</td><td>${r.valid ? A.chip('Valid', 'good') : `<span class="chip bad" title="${A.esc(r.error)}">${A.esc(r.error)}</span>`}</td></tr>`).join('')}</tbody>`;
      A.qs('#importHint').textContent = errs ? `${errs} row${errs > 1 ? 's' : ''} will be skipped — fix the file and re-upload to include ${errs > 1 ? 'them' : 'it'}` : 'All rows valid';
      A.qs('#importNext').textContent = `Import ${valid} asset${valid > 1 ? 's' : ''}`;
    } else {
      const valid = importedRows.filter((r) => r.valid).length;
      A.close(importModal); A.toast(`${valid} assets imported and logged.`);
    }
  });

  /* ---------- export: formal print report (same approach as the teacher's count sheet) ----------
     "Export" / "Export selected" builds a Property Inventory Report into #printSheet and opens the
     browser print dialog (choose "Save as PDF" to keep a copy). Built from the live data on every
     print, so Ctrl+P is always up to date. Layout lives in custodian.css under "print: property report". */
  const exportModal = A.qs('#exportModal');
  const EXPORT_COLS = [
    { k: 'id', l: 'Asset ID' }, { k: 'name', l: 'Asset name' }, { k: 'category', l: 'Category' },
    { k: 'qty', l: 'Quantity' }, { k: 'building', l: 'Building' }, { k: 'room', l: 'Room' }, { k: 'teacher', l: 'Assigned teacher' },
    { k: 'dateAcquired', l: 'Date acquired' }, { k: 'unitValue', l: 'Unit value' }, { k: 'totalValue', l: 'Total value' },
    { k: 'fundSource', l: 'Fund source' }, { k: 'fundCode', l: 'Fund code' }, { k: 'condition', l: 'Condition' },
    { k: 'propertyNo', l: 'Property no.' }, { k: 'modifiedAt', l: 'Last modified' }
  ];

  /* form settings (edit here, same idea as the teacher sheet) */
  const SCHOOL_NAME = document.body.dataset.school || 'Lagro High School';
  const DIVISION_NAME = 'Schools Division Office of Quezon City';
  const FORM_TITLE = 'PROPERTY INVENTORY REPORT';
  const PREPARED_BY = document.body.dataset.user || 'Property Custodian';
  const PREPARED_ROLE = document.body.dataset.role || 'Property Custodian';
  const DEPED_LOGO = '';                 // e.g. 'assets/img/deped-logo.png' (leave '' for no logo)
  const SCHOOL_LOGO = '';                // e.g. 'assets/img/school-logo.png'
  const PAGE_BREAK_PER_BUILDING = false; // true = every building starts on a new page
  const DENSE_FROM = 10;                 // this many columns or more -> smaller print text
  const PAGE_CSS = '@page{size:A4 landscape;margin:12mm 12mm 14mm;@bottom-right{content:"Page " counter(page) " of " counter(pages);font-size:8.5pt;font-family:"Neue Montreal",Arial,sans-serif}}';

  let exportScope = 0;   // 0 = the current filtered list, n = the n selected units

  A.qs('#colGrid').innerHTML = EXPORT_COLS.map((c) => `<label class="checkbox"><input type="checkbox" value="${c.k}" ${['propertyNo', 'fundCode', 'modifiedAt', 'totalValue'].includes(c.k) ? '' : 'checked'}> ${c.l}</label>`).join('');
  const selectedCols = () => {
    const on = A.qsa('#colGrid input:checked').map((i) => i.value);
    const picked = EXPORT_COLS.filter((c) => on.includes(c.k));
    return picked.length ? picked : EXPORT_COLS;
  };

  /* what gets printed: the selected units, or every unit passing the current filters */
  function exportUnits() {
    return exportScope
      ? records.flatMap((r) => r.unitData.filter((u) => selected.has(u.unitId)).map((u) => ({ r, u })))
      : viewRows.flatMap((r) => unitsOf(r).map((u) => ({ r, u })));
  }
  /* one printed line = one asset in one place in one condition (so Quantity is meaningful) */
  function exportGroups(items) {
    const map = new Map();
    items.forEach(({ r, u }) => {
      const key = [r.id, u.building, u.room, u.condition].join('|');
      if (!map.has(key)) map.set(key, { r, building: u.building, room: u.room, condition: u.condition, units: [] });
      map.get(key).units.push(u);
    });
    return [...map.values()];
  }
  function groupByBuilding(groups) {
    const order = (b) => { const i = DB.buildings.indexOf(b); return i < 0 ? 999 : i; };
    const sorted = groups.slice().sort((a, b) =>
      order(a.building) - order(b.building) || String(a.building).localeCompare(b.building) ||
      String(a.room).localeCompare(String(b.room), undefined, { numeric: true }) ||
      a.r.name.localeCompare(b.r.name) || a.r.id.localeCompare(b.r.id));
    const out = new Map();
    sorted.forEach((g) => { if (!out.has(g.building)) out.set(g.building, []); out.get(g.building).push(g); });
    return [...out.entries()];
  }

  /* how each column prints (g = one printed line) */
  const PRINT_CELLS = {
    id: (g) => A.esc(g.r.id),
    name: (g) => A.esc(g.r.name),
    category: (g) => A.esc(g.r.category),
    qty: (g) => A.int(g.units.length),
    building: (g) => A.esc(g.building || 'Not assigned yet'),
    room: (g) => A.esc(g.room || '—'),
    teacher: (g) => A.esc(teacherOf(g.units[0]) || 'Unassigned'),
    dateAcquired: (g) => A.date(g.r.dateAcquired),
    unitValue: (g) => A.money(g.r.unitValue),
    totalValue: (g) => A.money(g.r.unitValue * g.units.length),
    fundSource: (g) => A.esc(g.r.fundSource),
    fundCode: (g) => A.esc(g.r.fundCode || '—'),
    condition: (g) => A.esc(g.condition),
    propertyNo: (g) => { const p = g.units.map((u) => u.propertyNo).filter(Boolean); return p.length ? A.esc(p.join(', ')) : '—'; },
    modifiedAt: (g) => A.date(g.r.modifiedAt)
  };
  const PRINT_ALIGN = { id: 'nw', qty: 'c nw', unitValue: 'n', totalValue: 'n' };   // nw = never wrap
  const PRINT_W = { id: 10, name: 18, category: 13, qty: 9, building: 11, room: 9, teacher: 12, dateAcquired: 9, unitValue: 9,
    totalValue: 10, fundSource: 9, fundCode: 6, condition: 12, propertyNo: 13, modifiedAt: 9 };
  const colWidth = (c, cols) => (96 * PRINT_W[c.k] / cols.reduce((n, x) => n + PRINT_W[x.k], 0)).toFixed(2) + '%';
  const sumQty = (groups) => groups.reduce((n, g) => n + g.units.length, 0);
  const sumValue = (groups) => groups.reduce((n, g) => n + g.r.unitValue * g.units.length, 0);

  function printRow(g, number, cols) {
    return `<tr><td class="c">${number}</td>${cols.map((c) => `<td class="${PRINT_ALIGN[c.k] || ''}">${PRINT_CELLS[c.k](g)}</td>`).join('')}</tr>`;
  }

  /* Total row: label spans the leading columns, quantity and total value line up under their columns */
  function printTotalRow(groups, cols) {
    const first = cols.findIndex((c) => c.k === 'qty' || c.k === 'totalValue');
    if (first < 0) return `<tr class="ps-total"><td colspan="${cols.length + 1}" class="r">TOTAL</td></tr>`;
    const rest = cols.slice(first).map((c) =>
      c.k === 'qty' ? `<td class="c">${A.int(sumQty(groups))}</td>`
        : c.k === 'totalValue' ? `<td class="n">${A.money(sumValue(groups))}</td>` : '<td></td>').join('');
    return `<tr class="ps-total"><td colspan="${first + 1}" class="r">TOTAL</td>${rest}</tr>`;
  }

  /* One section per building */
  function printBuildingSection(building, groups, cols) {
    const units = sumQty(groups);
    return `<section class="ps-sec">
      <h2>${building ? 'Location: ' + A.esc(building) : 'Not assigned to a room yet'} <span>· ${A.int(units)} unit${units === 1 ? '' : 's'}</span></h2>
      <table class="ps-table">
        <thead><tr><th class="c" style="width:4%">No.</th>${cols.map((c) => `<th class="${PRINT_ALIGN[c.k] || ''}" style="width:${colWidth(c, cols)}">${A.esc(c.l)}</th>`).join('')}</tr></thead>
        <tbody>${groups.map((g, i) => printRow(g, i + 1, cols)).join('')}${printTotalRow(groups, cols)}</tbody>
      </table>
    </section>`;
  }

  /* Summary by condition, certification and signatures */
  function printClosingSection(groups, stamp) {
    const rows = DB.conditions.map((cond) => {
      const gs = groups.filter((g) => g.condition === cond);
      return gs.length ? `<tr><td>${A.esc(cond)}</td><td class="c">${A.int(sumQty(gs))}</td><td class="n">${A.money(sumValue(gs))}</td></tr>` : '';
    }).join('');
    return `<section class="ps-close">
      <h2>Summary by condition</h2>
      <table class="ps-table ps-summary">
        <thead><tr><th>Condition</th><th class="c" style="width:22%">Units</th><th class="n" style="width:38%">Total value</th></tr></thead>
        <tbody>${rows}<tr class="ps-total"><td class="r">TOTAL</td><td class="c">${A.int(sumQty(groups))}</td><td class="n">${A.money(sumValue(groups))}</td></tr></tbody>
      </table>
      <p class="ps-cert">I certify that this report was generated from the school property records on ${stamp} and that the items listed are on record in the custody of this office.</p>
      <div class="ps-sign">
        <div><span class="role">Prepared by:</span><div class="who"><b>${A.esc(PREPARED_BY)}</b>${A.esc(PREPARED_ROLE)} · Signature over printed name<br>Date: ________________</div></div>
        <div><span class="role">Noted by:</span><div class="who"><b>&nbsp;</b>School Head<br>Date: ________________</div></div>
      </div>
      <div class="ps-foot">Generated by Assetly · ${stamp}</div>
    </section>`;
  }

  function activeFilters() {
    const f = [['Search', A.qs('#q').value.trim()], ['Building', A.qs('#fBuilding').value], ['Category', A.qs('#fCategory').value],
      ['Condition', A.qs('#fCondition').value], ['Fund source', A.qs('#fFund').value]].filter((x) => x[1]);
    return f.length ? f.map(([k, v]) => `${k}: ${v}`).join('; ') : 'None (all records)';
  }

  /* Builds the whole report. Runs before every print, so it is always up to date. */
  function buildPrintSheet() {
    let sheet = A.qs('#printSheet');
    if (!sheet) { sheet = document.createElement('div'); sheet.id = 'printSheet'; document.body.appendChild(sheet); }
    let style = A.qs('#psPageStyle');
    if (!style) { style = document.createElement('style'); style.id = 'psPageStyle'; document.head.appendChild(style); }
    style.textContent = PAGE_CSS;                       // landscape A4, only while printing from this page

    const picked = selectedCols();
    const groups = exportGroups(exportUnits());
    const stamp = A.dateTime(new Date().toISOString());
    /* the building is already the section heading, so its column is left out unless it is the only one picked */
    const cols = picked.filter((c) => c.k !== 'building').length ? picked.filter((c) => c.k !== 'building') : picked;
    sheet.className = [PAGE_BREAK_PER_BUILDING ? 'ps-paged' : '', picked.length >= DENSE_FROM ? 'ps-dense' : ''].join(' ').trim();
    sheet.innerHTML = `
      <header class="ps-head">
        <div class="ps-logo">${DEPED_LOGO ? `<img src="${A.esc(DEPED_LOGO)}" alt="">` : ''}</div>
        <div class="ps-title">
          <div class="gov">Republic of the Philippines<br><b>Department of Education</b><br>${A.esc(DIVISION_NAME)}</div>
          <div class="school">${A.esc(SCHOOL_NAME)}</div>
          <h1>${A.esc(FORM_TITLE)}</h1>
          <div class="sub">As of ${A.date(new Date().toISOString())}</div>
        </div>
        <div class="ps-logo">${SCHOOL_LOGO ? `<img src="${A.esc(SCHOOL_LOGO)}" alt="">` : ''}</div>
      </header>
      <p class="ps-account">School property on record at <b>${A.esc(SCHOOL_NAME)}</b>, in the custody of the Property Custodian, <b>${A.esc(PREPARED_BY)}</b>.</p>
      <div class="ps-meta">
        <div><b>Scope:</b> ${exportScope ? `Selected units (${A.int(sumQty(groups))})` : 'Current filtered list'} · <b>Filters:</b> ${A.esc(exportScope ? 'not applied to a selection' : activeFilters())}</div>
        <div><b>Date generated:</b> ${stamp}</div>
        <div><b>Total:</b> ${A.int(sumQty(groups))} unit${sumQty(groups) === 1 ? '' : 's'} · ${A.money(sumValue(groups))}</div>
      </div>
      ${groupByBuilding(groups).map(([b, gs]) => printBuildingSection(b, gs, cols)).join('')}
      ${printClosingSection(groups, stamp)}`;
  }

  /* ---------- export modal ---------- */
  A.qs('#exportBtn').addEventListener('click', () => openExport(0));
  function openExport(selectedCount) {
    exportScope = selectedCount;
    A.qs('#exportScope').textContent = selectedCount
      ? `Print ${selectedCount} selected unit${selectedCount > 1 ? 's' : ''}.`
      : 'Print the current filtered list as a formal property report.';
    updateExportSummary();
    A.open(exportModal);
  }
  function updateExportSummary() {
    const n = exportUnits().length, lines = exportGroups(exportUnits()).length, cols = A.qsa('#colGrid input:checked').length;
    A.qs('#exportSummary').innerHTML = `Printing <strong>${A.int(n)}</strong> unit${n === 1 ? '' : 's'} on <strong>${A.int(lines)}</strong> line${lines === 1 ? '' : 's'}, grouped by building, with <strong>${cols}</strong> column${cols === 1 ? '' : 's'}.`;
    A.qs('#exportGo').disabled = !n || !cols;
  }
  A.qs('#colAll').addEventListener('change', (e) => { A.qsa('#colGrid input').forEach((c) => (c.checked = e.target.checked)); updateExportSummary(); });
  A.qs('#colGrid').addEventListener('change', updateExportSummary);
  A.qs('#exportGo').addEventListener('click', () => {
    if (!exportUnits().length) { A.toast('Nothing to print. No items match.', 'bad'); return; }
    A.close(exportModal);
    buildPrintSheet();
    window.print();
  });
  window.addEventListener('beforeprint', buildPrintSheet);                       // also covers Ctrl+P
  window.addEventListener('afterprint', () => { exportScope = 0; const s = A.qs('#psPageStyle'); if (s) s.remove(); });

  renderKpis();
  apply();
})();
