/* room requests page: accept or reject teacher requests to take or release a room */
(function () {
  const A = window.Assetly, DB = window.DB;
  let rows = [];
  let page = 1;
  const perPage = 6;
  let current = null; // request being rejected

  const initials = (name) => name.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  const assetsIn = (b, r) => DB.assets.filter((a) => a.building === b && String(a.room) === String(r)).reduce((n, a) => n + a.qty, 0);

  /* KPIs are rebuilt after every decision so the numbers stay current */
  function renderKpis() {
    const list = DB.roomRequests;
    A.qs('#rrKpis').innerHTML = [
      { v: list.filter((r) => r.status === 'Pending').length, l: 'Pending review', ic: 'warn', icon: 'i-clock' },
      { v: list.filter((r) => r.kind === 'Request').length, l: 'Room requests', ic: 'brand', icon: 'i-plus' },
      { v: list.filter((r) => r.kind === 'Release').length, l: 'Releases', ic: 'info', icon: 'i-restore' },
      { v: list.filter((r) => r.status === 'Approved').length, l: 'Approved', ic: 'good', icon: 'i-check-circle' }
    ].map((k) => `<div class="kpi"><div><div class="v num">${A.int(k.v)}</div><div class="l">${k.l}</div></div><div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div></div>`).join('');
  }

  DB.buildings.forEach((b) => A.qs('#fBuilding').insertAdjacentHTML('beforeend', `<option>${A.esc(b)}</option>`));

  function apply() {
    const q = A.qs('#q').value.trim().toLowerCase(), fk = A.qs('#fKind').value, fs = A.qs('#fStatus').value, fb = A.qs('#fBuilding').value;
    rows = DB.roomRequests.filter((r) =>
      (!q || r.teacher.toLowerCase().includes(q) || r.room.toLowerCase().includes(q) || r.id.toLowerCase().includes(q)) &&
      (!fk || r.kind === fk) && (!fs || r.status === fs) && (!fb || r.building === fb));
    // pending first, then newest
    rows.sort((a, b) => (a.status === 'Pending' ? 0 : 1) - (b.status === 'Pending' ? 0 : 1) || b.submittedAt.localeCompare(a.submittedAt));
    page = 1;
    render();
  }

  function card(r) {
    const count = assetsIn(r.building, r.room);
    const holder = DB.teacherFor(r.building, r.room);
    const detail = r.kind === 'Request' ? ['Role', r.role] : ['Reason', r.releaseReason];
    const conflict = r.status === 'Pending' && r.kind === 'Request' && holder && holder !== r.teacher
      ? `<div class="note warn"><svg class="i"><use href="#i-alert"/></svg><div>Currently assigned to <strong>${A.esc(holder)}</strong>.</div></div>` : '';
    const rejected = r.status === 'Rejected' && r.reason
      ? `<div class="note bad"><svg class="i"><use href="#i-x-circle"/></svg><div><strong>Rejected.</strong> ${A.esc(r.reason)}</div></div>` : '';
    const actions = r.status === 'Pending'
      ? `<div class="req-actions">
           <button class="btn btn-sm btn-danger-soft" data-reject="${r.id}" type="button"><svg class="i"><use href="#i-x"/></svg> Reject</button>
           <button class="btn btn-sm btn-good" data-accept="${r.id}" type="button"><svg class="i"><use href="#i-check"/></svg> Accept</button>
         </div>` : '';
    return `<article class="req-card ${r.status.toLowerCase()}">
      <div class="req-top">
        <span class="req-id num">${r.id}</span><span class="req-sep"></span>
        <span class="req-kind">${A.typeTag(r.kind)}</span>
        <span class="req-status">${A.statusChip(r.status)}</span>
      </div>
      <h3 class="req-title">${A.esc(r.building)} · ${/^\d+$/.test(r.room) ? 'Room ' : ''}${A.esc(r.room)}</h3>
      <div class="req-meta">
        <div><small class="muted">${detail[0]}</small><br><strong>${A.esc(detail[1])}</strong></div>
        <div><small class="muted">Assets in room</small><br><strong class="num">${count ? A.int(count) + ' units' : 'None recorded'}</strong></div>
      </div>
      ${r.note ? `<p class="req-note">“${A.esc(r.note)}”</p>` : ''}
      ${conflict}${rejected}
      <div class="req-foot">
        <span class="avatar sm">${A.esc(initials(r.teacher))}</span>
        <div class="req-who"><strong>${A.esc(r.teacher)}</strong><small class="muted">${A.date(r.submittedAt)}</small></div>
        ${actions}
      </div>
    </article>`;
  }

  function render() {
    const slice = rows.slice((page - 1) * perPage, page * perPage);
    const grid = A.qs('#rrGrid');
    grid.innerHTML = slice.length
      ? slice.map(card).join('')
      : `<div class="empty" style="grid-column:1/-1"><svg class="i"><use href="#i-map-pin"/></svg><strong>No requests found</strong>Nothing matches your filters.</div>`;
    A.pager({ el: A.qs('#rrFoot'), total: rows.length, page, perPage, onPage: (p) => { page = p; render(); } });
  }

  const find = (id) => DB.roomRequests.find((x) => x.id === id);
  const where = (r) => `${r.building} · ${r.room}`;

  A.qs('#rrGrid').addEventListener('click', async (e) => {
    const acc = e.target.closest('[data-accept]'), rej = e.target.closest('[data-reject]');
    if (acc) {
      const r = find(acc.dataset.accept);
      const ok = await A.confirm({
        title: 'Accept this request?',
        text: r.kind === 'Request'
          ? `${r.teacher} will be assigned to ${where(r)}, become accountable for its assets, and be notified.`
          : `${r.teacher} will be released from ${where(r)}. The room becomes unassigned and ${r.teacher} is notified.`,
        okLabel: 'Confirm and accept', tone: 'good'
      });
      if (!ok) return;
      r.status = 'Approved';
      r.decidedAt = A.nowISO();
      A.toast(`Request ${r.id} accepted. ${r.teacher} will be notified.`);
      renderKpis(); apply();
    }
    if (rej) {
      current = find(rej.dataset.reject);
      A.qs('#rejSub').textContent = `${current.id} · ${current.teacher} · ${where(current)}`;
      A.qs('#rejReason').value = '';
      A.qs('#rejReason').closest('.field').classList.remove('is-invalid');
      A.open('rejectModal');
    }
  });

  A.qs('#rejConfirm').addEventListener('click', () => {
    const ta = A.qs('#rejReason');
    if (!ta.value.trim()) { ta.closest('.field').classList.add('is-invalid'); ta.focus(); return; }
    current.status = 'Rejected';
    current.reason = ta.value.trim();
    current.decidedAt = A.nowISO();
    A.close('rejectModal');
    A.toast(`Request ${current.id} rejected. ${current.teacher} will be notified.`);
    renderKpis(); apply();
  });

  ['#q', '#fKind', '#fStatus', '#fBuilding'].forEach((s) => A.qs(s).addEventListener('input', apply));
  renderKpis();
  apply();
})();