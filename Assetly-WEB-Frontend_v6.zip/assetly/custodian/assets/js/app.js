window.Assetly = (function () {
  const qs  = (sel, root = document) => root.querySelector(sel);
  const qsa = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  /* ---------- formatting ---------- */
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const money = (n, opts = {}) => {
    if (n === null || n === undefined || n === '') return '—';
    const v = Number(n);
    if (Number.isNaN(v)) return '—';
    return '₱' + v.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2, ...opts });
  };
  const int = (n) => Number(n || 0).toLocaleString('en-PH');

  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const parseDate = (iso) => (iso ? new Date(iso.length === 10 ? iso + 'T00:00:00' : iso) : null);
  const date = (iso) => { const d = parseDate(iso); return d ? `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}` : '—'; };
  const dateTime = (iso) => {
    const d = parseDate(iso); if (!d) return '—';
    let h = d.getHours(); const ampm = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12;
    return `${date(iso)} · ${h}:${String(d.getMinutes()).padStart(2, '0')} ${ampm}`;
  };
  const todayISO = () => new Date().toISOString().slice(0, 10);
  const nowISO = () => new Date().toISOString().slice(0, 19);
  const daysSince = (iso) => Math.floor((Date.now() - parseDate(iso).getTime()) / 86400000);

  /* ---------- status chips ---------- */
  const CONDITION_TONE = { 'Operational': 'good', 'Under maintenance': 'warn', 'In storage': 'neutral', 'For disposal': 'bad' };
  const STATUS_TONE = {
    'Pending': 'warn', 'Approved': 'good', 'Rejected': 'bad',
    'Acknowledged': 'info', 'In progress': 'warn', 'Resolved': 'good',
    'Logged': 'warn', 'Counted': 'info', 'Posted': 'good'
  };
  const chip = (label, tone) => `<span class="chip ${tone || 'neutral'}">${esc(label)}</span>`;
  const conditionChip = (c) => chip(c, CONDITION_TONE[c] || 'neutral');
  const statusChip = (s) => chip(s, STATUS_TONE[s] || 'neutral');
  const typeTag = (t) => `<span class="tag ${t === 'Delete' ? '' : 'brand'}">${esc(t)}</span>`;

  /* ---------- modals & drawers ---------- */
  function open(id) {
    const el = typeof id === 'string' ? qs('#' + id) : id;
    if (!el) return;
    el.hidden = false;
    document.body.style.overflow = 'hidden';
    const first = qs('input:not([type=hidden]):not([disabled]), select, textarea, button', el);
    if (first) setTimeout(() => first.focus(), 20);
  }
  function close(id) {
    const el = typeof id === 'string' ? qs('#' + id) : id;
    if (!el) return;
    el.hidden = true;
    if (!qsa('.modal-backdrop:not([hidden]), .drawer-backdrop:not([hidden])').length) document.body.style.overflow = '';
  }
  // close on backdrop click, on [data-close] buttons and on Escape
  document.addEventListener('click', (e) => {
    const closer = e.target.closest('[data-close]');
    if (closer) { close(closer.closest('.modal-backdrop, .drawer-backdrop')); return; }
    if (e.target.classList.contains('modal-backdrop') || e.target.classList.contains('drawer-backdrop')) {
      if (e.target.id !== 'confirmDialog') close(e.target);
    }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    const openEls = qsa('.modal-backdrop:not([hidden]), .drawer-backdrop:not([hidden])');
    if (openEls.length) close(openEls[openEls.length - 1]);
  });

  /* ---------- confirm dialog (returns a Promise<boolean>) ---------- */
  function confirm({ title = 'Are you sure?', text = '', okLabel = 'Confirm', cancelLabel = 'Go back', tone = 'warn' } = {}) {
    return new Promise((resolve) => {
      const dlg = qs('#confirmDialog'), ok = qs('#confirmOk'), cancel = qs('#confirmCancel'), icon = qs('#confirmIcon');
      qs('#confirmTitle').textContent = title;
      qs('#confirmText').textContent = text;
      ok.textContent = okLabel; cancel.textContent = cancelLabel;
      ok.className = 'btn ' + (tone === 'bad' ? 'btn-danger' : tone === 'good' ? 'btn-good' : 'btn-primary');
      icon.className = 'confirm-icon ' + (tone === 'bad' ? 'bad' : tone === 'good' ? 'good' : '');
      icon.innerHTML = `<svg class="i"><use href="#${tone === 'bad' ? 'i-alert' : 'i-help'}"/></svg>`;
      const done = (v) => { ok.onclick = cancel.onclick = null; close(dlg); resolve(v); };
      ok.onclick = () => done(true);
      cancel.onclick = () => done(false);
      open(dlg);
      ok.focus();
    });
  }

  /* ---------- toasts ---------- */
  function toast(message, tone = 'good', ms = 3200) {
    const stack = qs('#toastStack');
    const el = document.createElement('div');
    el.className = 'toast ' + tone;
    const icon = tone === 'bad' ? 'i-x-circle' : tone === 'info' ? 'i-info' : 'i-check-circle';
    el.innerHTML = `<svg class="i"><use href="#${icon}"/></svg><span>${esc(message)}</span>`;
    stack.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .2s'; setTimeout(() => el.remove(), 220); }, ms);
  }

  /* ---------- form validation ---------- */
  // marks required fields inside `form` and returns true when all are filled
  function validate(form) {
    let ok = true;
    qsa('[data-required]', form).forEach((input) => {
      const field = input.closest('.field');
      const empty = !String(input.value || '').trim() || (input.type === 'number' && Number(input.value) <= 0 && input.min !== undefined && Number(input.min) > 0);
      if (field) field.classList.toggle('is-invalid', empty);
      if (empty) ok = false;
    });
    return ok;
  }
  document.addEventListener('input', (e) => {
    const f = e.target.closest('.field.is-invalid');
    if (f && String(e.target.value).trim()) f.classList.remove('is-invalid');
  });

  /* ---------- table selection + bulk bar ---------- */
  // wires a header checkbox, row checkboxes and a bulk bar. Returns { selected(): string[], clear() }
  function selection({ table, bulkbar, countEl, onChange }) {
    const headCb = qs('thead input[type=checkbox]', table);
    const rowCbs = () => qsa('tbody input[type=checkbox]', table);
    const update = () => {
      const all = rowCbs(), chosen = all.filter((c) => c.checked);
      all.forEach((c) => c.closest('tr').classList.toggle('is-selected', c.checked));
      if (headCb) { headCb.checked = all.length > 0 && chosen.length === all.length; headCb.indeterminate = chosen.length > 0 && chosen.length < all.length; }
      if (bulkbar) bulkbar.classList.toggle('is-visible', chosen.length > 0);
      if (countEl) countEl.textContent = chosen.length;
      if (onChange) onChange(chosen.map((c) => c.value));
    };
    if (headCb) headCb.addEventListener('change', () => { rowCbs().forEach((c) => (c.checked = headCb.checked)); update(); });
    table.addEventListener('change', (e) => { if (e.target.matches('tbody input[type=checkbox]')) update(); });
    return { selected: () => rowCbs().filter((c) => c.checked).map((c) => c.value), clear: () => { rowCbs().forEach((c) => (c.checked = false)); update(); }, update };
  }

  /* ---------- sorting & paging ---------- */
  function sortBy(list, key, dir = 'asc') {
    const m = dir === 'asc' ? 1 : -1;
    return [...list].sort((a, b) => {
      const x = a[key], y = b[key];
      if (x == null) return 1; if (y == null) return -1;
      if (typeof x === 'number' && typeof y === 'number') return (x - y) * m;
      return String(x).localeCompare(String(y), undefined, { numeric: true, sensitivity: 'base' }) * m;
    });
  }
  function pager({ el, total, page, perPage, onPage }) {
    const pages = Math.max(1, Math.ceil(total / perPage));
    page = Math.min(Math.max(1, page), pages);
    const from = total ? (page - 1) * perPage + 1 : 0, to = Math.min(total, page * perPage);
    const btn = (label, p, cls = '', dis = false) => `<button type="button" class="${cls}" data-page="${p}" ${dis ? 'disabled' : ''}>${label}</button>`;
    let nums = '';
    const win = [...new Set([1, pages, page - 1, page, page + 1].filter((p) => p >= 1 && p <= pages))].sort((a, b) => a - b);
    win.forEach((p, i) => { if (i && p - win[i - 1] > 1) nums += '<span class="muted">…</span>'; nums += btn(p, p, p === page ? 'is-active' : ''); });
    el.innerHTML = `<span>Showing ${from}–${to} of ${total}</span>
      <div class="pager">${btn('<svg class="i i-sm"><use href="#i-chevron-left"/></svg>', page - 1, '', page === 1)}${nums}${btn('<svg class="i i-sm"><use href="#i-chevron-right"/></svg>', page + 1, '', page === pages)}</div>`;
    qsa('[data-page]', el).forEach((b) => b.addEventListener('click', () => onPage(Number(b.dataset.page))));
  }

  /* ---------- shell behaviour (sidebar, user menu) ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    const toggle = qs('#sidebarToggle'), scrim = qs('#sidebarScrim');
    if (toggle) toggle.addEventListener('click', () => document.body.classList.toggle('sidebar-open'));
    if (scrim) scrim.addEventListener('click', () => document.body.classList.remove('sidebar-open'));

    /* sidebar dropdown groups (Assets → All assets / Deliveries) */
    qsa('.nav-group').forEach((g) => {
      const t = qs('.nav-toggle', g);
      t.addEventListener('click', () => {
        const open = g.classList.toggle('is-open');
        t.setAttribute('aria-expanded', open);
      });
    });

    const um = qs('#userMenu');
    if (um) {
      const btn = qs('button', um);
      btn.addEventListener('click', (e) => { e.stopPropagation(); um.classList.toggle('is-open'); btn.setAttribute('aria-expanded', um.classList.contains('is-open')); });
      document.addEventListener('click', () => { um.classList.remove('is-open'); btn.setAttribute('aria-expanded', 'false'); });
    }
    /* the notification panel lives in notifications.js */

    /* ask before logging out */
    const logout = qs('.logout');
    if (logout) logout.addEventListener('click', async (e) => {
      e.preventDefault();
      const ok = await confirm({
        title: 'Log out of Assetly?',
        text: 'You will need to sign in again to continue.',
        okLabel: 'Log out', cancelLabel: 'Stay signed in', tone: 'warn'
      });
      if (ok) location.href = logout.href;
    });

    // K=keep radio cards in sync with their input.
    document.addEventListener('change', (e) => {
      if (e.target.matches('.radio-card input[type=radio]')) {
        qsa(`.radio-card input[name="${e.target.name}"]`).forEach((r) => r.closest('.radio-card').classList.toggle('is-checked', r.checked));
      }
    });
  });

  return { qs, qsa, esc, money, int, date, dateTime, todayISO, nowISO, daysSince, chip, conditionChip, statusChip, typeTag, open, close, confirm, toast, validate, selection, sortBy, pager, CONDITION_TONE, STATUS_TONE };
})();