/* update reports page: review, approve or reject teacher-submitted update requests */
(function () {
  const A = window.Assetly, DB = window.DB;
  let rows = [...DB.reports]; let page = 1; const perPage = 10;
  let current = null;

  const pending = DB.reports.filter((r) => r.status === 'Pending');
  A.qs('#repKpis').innerHTML = [
    { v: pending.length, l: 'Pending review', ic: 'warn', icon: 'i-file' },
    { v: DB.reports.filter((r) => r.type === 'Add').length, l: 'Add requests', ic: 'brand', icon: 'i-plus' },
    { v: DB.reports.filter((r) => r.type === 'Relocation').length, l: 'Relocations', ic: 'info', icon: 'i-truck' },
    { v: DB.reports.filter((r) => r.status === 'Approved').length, l: 'Approved', ic: 'good', icon: 'i-check-circle' }
  ].map((k) => `<div class="kpi"><div><div class="v num">${A.int(k.v)}</div><div class="l">${k.l}</div></div><div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div></div>`).join('');

  function apply() {
    const q = A.qs('#q').value.trim().toLowerCase(), ft = A.qs('#fType').value, fs = A.qs('#fStatus').value;
    rows = DB.reports.filter((r) =>
      (!q || r.assetName.toLowerCase().includes(q) || r.submittedBy.toLowerCase().includes(q) || r.id.toLowerCase().includes(q)) &&
      (!ft || r.type === ft) && (!fs || r.status === fs));
    rows.sort((a, b) => b.submittedAt.localeCompare(a.submittedAt));
    page = 1; render();
  }

  function render() {
    const slice = rows.slice((page - 1) * perPage, page * perPage);
    const body = A.qs('#repBody');
    if (!slice.length) { body.innerHTML = `<tr><td colspan="8"><div class="empty"><svg class="i"><use href="#i-file"/></svg><strong>No reports found</strong>Nothing matches your filters.</div></td></tr>`; }
    else body.innerHTML = slice.map((r) => `
      <tr>
        <td class="id num">${r.id}</td>
        <td class="cell-main">${A.esc(r.assetName)}<span class="cell-sub">${A.esc(r.category)}</span></td>
        <td>${A.typeTag(r.type)}</td>
        <td class="text-right num">${r.qty}</td>
        <td>${A.esc(r.submittedBy)}</td>
        <td class="num">${A.date(r.submittedAt)}</td>
        <td>${A.statusChip(r.status)}</td>
        <td class="actions"><button class="btn btn-sm ${r.status === 'Pending' ? 'btn-primary' : 'btn-secondary'}" data-open="${r.id}">${r.status === 'Pending' ? 'Review' : 'View'}</button></td>
      </tr>`).join('');
    A.pager({ el: A.qs('#repFoot'), total: rows.length, page, perPage, onPage: (p) => { page = p; render(); } });
  }

  A.qs('#repBody').addEventListener('click', (e) => { const b = e.target.closest('[data-open]'); if (b) openDrawer(b.dataset.open); });
  ['#q', '#fType', '#fStatus'].forEach((s) => A.qs(s).addEventListener('input', apply));

  function openDrawer(id) {
    const r = current = DB.reports.find((x) => x.id === id);
    A.qs('#repTitle').textContent = `${r.type} request`;
    A.qs('#repSub').textContent = `${r.id} · ${r.submittedBy}`;
    const loc = r.type === 'Relocation'
      ? `<div class="span-2"><dt>Move</dt><dd>${A.esc(r.building)} · ${A.esc(r.room)} &nbsp;→&nbsp; <strong style="color:var(--brand)">${A.esc(r.newBuilding)} · ${A.esc(r.newRoom)}</strong></dd></div>`
      : `<div><dt>Building</dt><dd>${A.esc(r.building)}</dd></div><div><dt>Room</dt><dd>${A.esc(r.room)}</dd></div>`;
    const matched = r.matchedAssetId
      ? `<div class="note info"><svg class="i"><use href="#i-check-circle"/></svg><div>Matched to existing asset <strong>${r.matchedAssetId}</strong> in the inventory.</div></div>`
      : `<div class="note warn"><svg class="i"><use href="#i-alert"/></svg><div>No matching asset on record. Approving an <strong>Add</strong> request will create a new asset.</div></div>`;
    A.qs('#repBodyDrawer').innerHTML = `
      <div class="meta-strip">
        <div><small class="muted">Report by</small><br><strong>${A.esc(r.submittedBy)}</strong></div>
        <div><small class="muted">Submitted</small><br><strong>${A.date(r.submittedAt)}</strong></div>
        <div><small class="muted">Status</small><br>${A.statusChip(r.status)}</div>
      </div>
      <dl class="dl">
        <div class="span-2"><dt>Asset</dt><dd>${A.esc(r.assetName)}</dd></div>
        <div><dt>Category</dt><dd>${A.esc(r.category)}</dd></div>
        <div><dt>Quantity</dt><dd class="num">${r.qty}</dd></div>
        ${loc}
        <div class="span-2"><dt>Update type</dt><dd>${A.typeTag(r.type)}</dd></div>
        <div class="span-2"><dt>Teacher's note</dt><dd style="font-weight:400">${A.esc(r.description)}</dd></div>
      </dl>
      ${r.status === 'Pending' ? matched : ''}
      ${r.status === 'Rejected' && r.reason ? `<div class="note bad"><svg class="i"><use href="#i-x-circle"/></svg><div><strong>Rejected.</strong> ${A.esc(r.reason)}</div></div>` : ''}
      ${r.status === 'Approved' ? `<div class="note good"><svg class="i"><use href="#i-check-circle"/></svg><div>Approved and applied to the inventory.</div></div>` : ''}`;

    const foot = A.qs('#repFootDrawer');
    if (r.status === 'Pending') {
      foot.innerHTML = `<button class="btn btn-secondary left" data-close type="button">Close</button>
        <button class="btn btn-danger-soft" id="rejectBtn" type="button"><svg class="i"><use href="#i-x"/></svg> Reject</button>
        <button class="btn btn-good" id="approveBtn" type="button"><svg class="i"><use href="#i-check"/></svg> Approve</button>`;
      A.qs('#approveBtn').addEventListener('click', async () => {
        const verb = { Add: 'create the asset', Relocation: 'move the asset', Delete: 'move the asset to trash', Other: 'apply the change' }[r.type];
        const ok = await A.confirm({ title: 'Approve this report?', text: `This will ${verb}, notify ${r.submittedBy}, and log the action.`, okLabel: 'Confirm and approve', tone: 'good' });
        if (ok) { A.close('repDrawer'); A.toast('Report approved and applied.'); }
      });
      A.qs('#rejectBtn').addEventListener('click', () => { A.qs('#rejReason').value = ''; A.qs('#rejReason').closest('.field').classList.remove('is-invalid'); A.open('rejectModal'); });
    } else {
      foot.innerHTML = `<button class="btn btn-secondary" data-close type="button">Close</button>`;
    }
    A.open('repDrawer');
  }

  A.qs('#rejConfirm').addEventListener('click', () => {
    const ta = A.qs('#rejReason');
    if (!ta.value.trim()) { ta.closest('.field').classList.add('is-invalid'); return; }
    A.close('rejectModal'); A.close('repDrawer');
    A.toast(`Report ${current.id} rejected. ${current.submittedBy} will be notified.`);
  });

  apply();
})();
