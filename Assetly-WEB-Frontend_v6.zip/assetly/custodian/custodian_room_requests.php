<?php
$pageTitle   = 'Room requests';
$pageSub     = 'Teachers ask to be assigned to a room or to release one. Accept or reject each request.';
$active      = 'rooms';
$pageScripts = ['room_requests.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <div class="kpi-row" style="flex:1" id="rrKpis"></div>
</div>

<section class="card">
  <div class="card-b" style="padding-bottom:0">
    <div class="toolbar">
      <div class="input-icon grow">
        <svg class="i"><use href="#i-search"/></svg>
        <input class="input" id="q" type="search" placeholder="Search by teacher, room or request ID">
      </div>
      <select class="select" id="fKind"><option value="">All types</option><option>Request</option><option>Release</option></select>
      <select class="select" id="fStatus"><option value="">All statuses</option><option>Pending</option><option>Approved</option><option>Rejected</option></select>
      <select class="select" id="fBuilding"><option value="">All buildings</option></select>
    </div>
  </div>
  <div class="card-b" style="padding-top:16px">
    <div class="req-grid" id="rrGrid"></div>
    <div class="table-foot" id="rrFoot" style="margin-top:16px"></div>
  </div>
</section>

<!-- reject reason modal -->
<div class="modal-backdrop" id="rejectModal" hidden>
  <div class="modal modal-sm" style="text-align:left;align-items:stretch" role="dialog" aria-modal="true" aria-labelledby="rejTitle">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
      <h3 id="rejTitle">Reason for rejection</h3>
      <button class="icon-btn sm" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <p class="muted" id="rejSub" style="font-size:12.5px;margin:0 0 12px"></p>
    <div class="field">
      <textarea class="textarea" id="rejReason" data-required placeholder="Explain why this request is being rejected. The teacher will see this."></textarea>
      <span class="error">A reason is required.</span>
    </div>
    <div class="modal-actions" style="justify-content:flex-end;margin-top:14px">
      <button class="btn btn-secondary" data-close type="button">Cancel</button>
      <button class="btn btn-danger" id="rejConfirm" type="button">Confirm rejection</button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
