<?php
$pageTitle   = 'Dashboard';
$pageSub     = 'What needs your attention across assets, update reports and defect tickets.';
$active      = 'dashboard';
$pageScripts = ['dashboard.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="grid grid-main dash">
  <!-- left column: KPIs, two charts side by side, activity log -->
  <div class="stack">
    <section class="kpi-row" id="kpiRow"></section>

    <section class="card">
      <div class="card-h">
        <div><h2>Assets by building</h2><p id="bldSub">Units per building, most to least.</p></div>
        <div class="bld-total" id="bldTotal"></div>
      </div>
      <div class="card-b"><div class="bld" id="bldChart"></div></div>
    </section>

    <div class="grid grid-2">
    <section class="card">
      <div class="card-h">
        <div><h2>Physical count</h2><p id="pcSub">Count progress by teacher.</p></div>
        <a class="link" href="custodian_physical_count.php">View <svg class="i i-sm"><use href="#i-arrow-right"/></svg></a>
      </div>
      <div class="card-b" id="pcPanel"></div>
    </section>
    <section class="card">
      <div class="card-h">
        <div><h2>Recent deliveries</h2><p>Expected versus actual assets received.</p></div>
        <a class="link" href="custodian_deliveries.php">View <svg class="i i-sm"><use href="#i-arrow-right"/></svg></a>
      </div>
      <div class="card-b dlvp" id="dlvPanel"></div>
    </section>
    </div>
  </div>

  <!-- right rail -->
  <aside class="stack">
    <section class="card">
      <div class="card-h"><div><h2>Needs your attention</h2><p>Pending items across your modules.</p></div></div>
      <div class="card-b"><div class="attn" id="attnList"></div></div>
    </section>

    <section class="card">
      <div class="card-h"><div><h2>AI recommendations</h2><p>Insights on assets that need action.</p></div></div>
      <div class="card-b">
        <div class="reco" id="recoList"></div>
        <div class="reco-foot">
          <svg class="i i-sm"><use href="#i-sparkles"/></svg>
          <span>AI-assisted. Double-check the details before acting; they may be incomplete.</span>
        </div>
      </div>
    </section>
  </aside>

  <!-- activity log: spans the full width under both columns -->
  <section class="card dash-activity">
    <div class="card-h">
      <div><h2>Activity log</h2><p>A quick overview of recorded actions.</p></div>
      <button class="btn btn-sm btn-secondary" id="activityAll" type="button">View all</button>
    </div>
    <div class="card-b">
      <div class="act-log" id="actCards"></div>
    </div>
  </section>
</div>

<!-- activity log: every recorded action -->
<div class="modal-backdrop" id="activityModal" hidden>
  <div class="modal modal-xl" role="dialog" aria-modal="true" aria-labelledby="activityTitle">
    <div class="modal-h">
      <div><h2 id="activityTitle">Activity log</h2><div class="sub" id="activitySub">Every recorded action, newest first.</div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="modal-b">
      <div class="act-scroll">
        <table class="table" id="activityAllTable">
          <thead><tr><th>When</th><th>Event</th><th>User</th><th>Details</th><th class="actions">View</th></tr></thead>
          <tbody></tbody>
        </table>
      </div>
    </div>
    <div class="modal-f">
      <button class="btn btn-secondary" data-close type="button">Close</button>
    </div>
  </div>
</div>

<!-- activity log: details of one action -->
<div class="drawer-backdrop" id="activityDrawer" hidden>
  <div class="drawer" role="dialog" aria-modal="true" aria-labelledby="actTitle">
    <div class="drawer-h">
      <div><h2 id="actTitle">Activity</h2><div class="sub" id="actSub"></div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="drawer-b" id="actBody"></div>
    <div class="drawer-f" id="actFoot"></div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>