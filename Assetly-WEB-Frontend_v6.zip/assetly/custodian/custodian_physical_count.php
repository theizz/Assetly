<?php
$pageTitle   = 'Physical count';
$pageSub     = 'Open a count period, follow up with teachers, then verify or return each submitted count.';
$active      = 'count';
$pageScripts = ['physical_count.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <div class="kpi-row" style="flex:1" id="pcKpis"></div>
  <div class="actions">
    <button class="btn btn-secondary" id="printBtn" type="button"><svg class="i"><use href="#i-printer"/></svg> Print summary</button>
    <button class="btn btn-primary" id="periodBtn" type="button"></button>
  </div>
</div>

<!-- current period -->
<section class="card">
  <div class="card-b">
    <div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:12px;align-items:flex-start">
      <div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <h2 style="margin:0;font-size:16px" id="periodName"></h2>
          <span id="periodChip"></span>
        </div>
        <p class="muted" style="margin:4px 0 0;font-size:12.5px" id="periodMeta"></p>
      </div>
      <div class="toolbar" style="gap:8px">
        <label class="sr-only" for="periodSel">Count period</label>
        <select class="select" id="periodSel" style="min-width:180px"></select>
      </div>
    </div>
    <div id="periodProgress" style="margin-top:14px"></div>
  </div>
</section>

<!-- submissions -->
<section class="card">
  <div class="card-b" style="padding-bottom:0">
    <div class="toolbar">
      <div class="input-icon grow">
        <svg class="i"><use href="#i-search"/></svg>
        <input class="input" id="q" type="search" placeholder="Search by teacher or room">
      </div>
      <select class="select" id="fStatus"><option value="">All statuses</option></select>
      <select class="select" id="fBuilding"><option value="">All buildings</option></select>
      <button class="btn btn-secondary" id="remindAll" type="button"><svg class="i"><use href="#i-bell"/></svg> Remind not submitted</button>
    </div>
  </div>
  <div class="card-b flush" style="margin-top:12px">
    <div class="table-wrap">
      <table class="table" id="pcTable">
        <thead><tr>
          <th>Teacher</th><th>Assigned rooms</th>
          <th class="text-right">On record</th><th class="text-right">Found</th><th class="text-right">Short</th><th class="text-right">Over</th>
          <th>Flags</th><th>Submitted</th><th>Status</th><th class="actions">Actions</th>
        </tr></thead>
        <tbody id="pcBody"></tbody>
      </table>
    </div>
    <div class="table-foot" id="pcFoot"></div>
  </div>
</section>

<!-- reconciliation -->
<section class="card">
  <div class="card-h"><div><h2>Reconciliation by building</h2><p>Verified and submitted counts compared with the records.</p></div></div>
  <div class="card-b flush" style="margin-top:8px">
    <div class="table-wrap">
      <table class="table compact">
        <thead><tr><th>Building</th><th class="text-right">Rooms counted</th><th class="text-right">On record</th><th class="text-right">Found</th><th class="text-right">Short</th><th class="text-right">Over</th><th style="width:28%">Match</th></tr></thead>
        <tbody id="reconBody"></tbody>
      </table>
    </div>
  </div>
</section>

<!-- review drawer -->
<div class="drawer-backdrop" id="pcDrawer" hidden>
  <div class="drawer wide" role="dialog" aria-modal="true" aria-labelledby="pcTitle">
    <div class="drawer-h">
      <div><h2 id="pcTitle">Count</h2><div class="sub" id="pcSub"></div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="drawer-b" id="pcDrawerBody"></div>
    <div class="drawer-f" id="pcDrawerFoot"></div>
  </div>
</div>

<!-- return for correction -->
<div class="modal-backdrop" id="returnModal" hidden>
  <form class="modal" id="returnForm" role="dialog" aria-modal="true" aria-labelledby="returnTitle" novalidate>
    <div class="modal-h">
      <div><h2 id="returnTitle">Return count for correction</h2><div class="sub" id="returnSub"></div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="modal-b">
      <div class="field">
        <label class="req" for="returnReason">What should the teacher fix?</label>
        <textarea class="textarea" id="returnReason" data-required placeholder="e.g. Recount Room 105 and explain the 2 missing sewing machines."></textarea>
        <span class="error">Tell the teacher what to correct.</span>
      </div>
      <p class="muted" style="font-size:12px;margin:0">The teacher is notified and can edit and resubmit before the due date.</p>
    </div>
    <div class="modal-f">
      <button class="btn btn-secondary" data-close type="button">Cancel</button>
      <button class="btn btn-danger" type="submit"><svg class="i"><use href="#i-restore"/></svg> Return to teacher</button>
    </div>
  </form>
</div>

<!-- open a new period -->
<div class="modal-backdrop" id="openModal" hidden>
  <form class="modal" id="openForm" role="dialog" aria-modal="true" aria-labelledby="openTitle" novalidate>
    <div class="modal-h">
      <div><h2 id="openTitle">Open a count period</h2><div class="sub">Every teacher with assigned rooms is asked to count and submit.</div></div>
      <button class="icon-btn" data-close type="button" aria-label="Close"><svg class="i"><use href="#i-x"/></svg></button>
    </div>
    <div class="modal-b">
      <div class="form-grid">
        <div class="field">
          <label class="req" for="o-period">Period</label>
          <select class="select" id="o-period" data-required></select>
          <span class="error">Choose a period.</span>
        </div>
        <div class="field">
          <label class="req" for="o-due">Due date</label>
          <input class="input" id="o-due" type="date" data-required>
          <span class="error">Set a due date.</span>
        </div>
        <div class="field span-2">
          <label for="o-instr">Instructions to teachers</label>
          <textarea class="textarea" id="o-instr"></textarea>
        </div>
      </div>
    </div>
    <div class="modal-f">
      <button class="btn btn-secondary" data-close type="button">Cancel</button>
      <button class="btn btn-primary" type="submit"><svg class="i"><use href="#i-clipboard"/></svg> Open period</button>
    </div>
  </form>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
