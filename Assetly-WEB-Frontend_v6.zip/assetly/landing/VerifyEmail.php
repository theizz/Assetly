<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Assetly - Verify email</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="stylesheet.css?v=<?php echo filemtime(__DIR__ . '/stylesheet.css'); ?>">
</head>

<body>

<!-- ICONS (ignore niyo lang to, for icon drawings yan) -->
<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="users" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c2.7 0 4.5 1.8 4.5 4.5"/></symbol>
  <symbol id="wrench" viewBox="0 0 24 24"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></symbol>
  <symbol id="check" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></symbol>
  <symbol id="shield" viewBox="0 0 24 24"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></symbol>
  <symbol id="chart" viewBox="0 0 24 24"><path d="M5 20v-6M11 20V9M17 20V4"/></symbol>
  <symbol id="layers" viewBox="0 0 24 24"><path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5"/></symbol>
  <symbol id="clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></symbol>
  <symbol id="eye" viewBox="0 0 24 24"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></symbol>
</svg>

<div class="page">

  <!-- ========== LEFT SIDE ========== -->
  <section class="left">
    <h1>
      Every school asset,<br>
      <span class="title">Assetly</span> <span class="records">records them.</span>
    </h1>
    <p class="subtitle">Management, reports and maintenance in one place.</p>

    <div class="stage-wrap">
      <div class="stage">

        <!-- orbit -->
        <div class="orbit">
          <div class="circle-big"></div>
          <div class="circle-small"></div>

          <div class="center"><img src="images/app-icon.png" alt="Assetly logo" width="64" height="64"></div>

          <div class="ring">
            <div class="dot d1"><span><svg class="i"><use href="#users"/></svg></span></div>
            <div class="dot d2"><span><svg class="i"><use href="#wrench"/></svg></span></div>
            <div class="dot d3"><span><svg class="i"><use href="#check"/></svg></span></div>
            <div class="dot d4"><span><svg class="i"><use href="#shield"/></svg></span></div>
            <div class="dot d5"><span><svg class="i"><use href="#chart"/></svg></span></div>
          </div>
        </div>

        <!-- card 1: total assets -->
        <div class="card card-total">
          <div class="card-head">
            <span class="icon-circle"><svg class="i"><use href="#layers"/></svg></span>
            Total Assets
          </div>
          <p class="big-number">1,025</p>
          <p class="small-text">Across 6 buildings</p>
        </div>

        <!-- card 2: reports reviewed -->
        <div class="card card-reports">
          <div class="card-head">
            <span class="icon-circle"><svg class="i"><use href="#check"/></svg></span>
            Reports reviewed
          </div>
          <div class="mini-box">
            <div class="mini-row">
              <span class="small-text">This week</span>
              <b>18 of 30</b>
            </div>
            <div class="bar"><div class="bar-fill"></div></div>
          </div>
        </div>

        <!-- card 3: recent activity -->
        <div class="card card-recent">
          <div class="card-head">
            <span class="icon-circle"><svg class="i"><use href="#clock"/></svg></span>
            Recent Activity
          </div>
          <div class="tabs">
            <span>Daily</span>
            <span class="active">Weekly</span>
            <span>Yearly</span>
          </div>
          <div class="row">
            <div>
              <p>Projector, Castelo room 202</p>
              <p class="small-text">October 21, 2026</p>
            </div>
            <span class="badge moved">Moved</span>
          </div>
          <div class="row">
            <div>
              <p>Teacher’s table</p>
              <p class="small-text">October 19, 2026</p>
            </div>
            <span class="badge defect">Defect</span>
          </div>
        </div>

        <!-- card 4: update successful -->
        <div class="card card-toast">
          <span class="icon-circle"><svg class="i"><use href="#check"/></svg></span>
          <div>
            <p class="toast-title">Update successful</p>
            <p class="small-text">Asus Monitor has change location</p>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ========== RIGHT SIDE ========== -->
  <section class="right">
    <div class="login-box verify-box">
      <h2>Check your email</h2>
      <p class="subtitle">We sent a 6-digit code to <b>name@school.edu</b>. Enter it below to verify your account.</p>
      <!-- for backend later !! show the real email address here -->
      <form method="post">
        <div class="otp">
          <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 1">
          <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 2">
          <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 3">
          <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 4">
          <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 5">
          <input type="text" inputmode="numeric" maxlength="1" aria-label="Digit 6">
        </div>
        <p class="expire"><svg class="i"><use href="#clock"/></svg> Code expires in <span id="expires">15:00</span></p>
        <button type="submit" class="btn btn-fill">Verify email</button>
      </form>
      <p class="resend" id="resend"></p>
      <hr class="line">
      <p class="links"><a href="#">Change email</a> <span>·</span> <a href="#">Back to log in</a></p>
    </div>
  </section>

</div>

<script>
  // 6 code boxes
  var boxes = document.querySelectorAll(".otp input");
  boxes[0].focus();

  // gives every box its behavior (box number i)
  function setupBox(i) {
    var box = boxes[i];

    // jumps to the next box after typing a number, ok? hell yeah
    box.oninput = function () {
      box.value = box.value.replace(/[^0-9]/g, "");   // numbers only
      if (box.value !== "" && i < 5) {
        boxes[i + 1].focus();
      }
    };

    // backspace on an empty box goes back to the previous box
    box.onkeydown = function (e) {
      if (e.key === "Backspace" && box.value === "" && i > 0) {
        boxes[i - 1].focus();
      }
    };
  }

  for (var i = 0; i < boxes.length; i++) {
    setupBox(i);
  }

  // pasting a full code fills all the boxes at once
  boxes[0].onpaste = function (e) {
    e.preventDefault();
    var code = e.clipboardData.getData("text").replace(/[^0-9]/g, "");
    for (var j = 0; j < code.length && j < 6; j++) {
      boxes[j].value = code[j];
    }
  };

  // timers
  var expiresIn = 15 * 60;   // the code lasts 15 minutes (counted in seconds)
  var resendIn = 30;         // wait 30 seconds before asking for a new code

  var expiresText = document.getElementById("expires");
  var resendText = document.getElementById("resend");

  // turns seconds into minutes:seconds  (example: 75 becomes 1:15)
  function showTime(seconds) {
    var minutes = Math.floor(seconds / 60);
    var rest = seconds % 60;
    if (rest < 10) {
      rest = "0" + rest;
    }
    return minutes + ":" + rest;
  }

  // shows "Resend code in 0:30", or the Resend link when the wait is over
  function updateResend() {
    if (resendIn > 0) {
      resendText.innerHTML = "Didn't get it? Resend in <b>" + showTime(resendIn) + "</b>";
    } else {
      resendText.innerHTML = "Didn't get it? <a href='#' id='again'>Resend code</a>";
      document.getElementById("again").onclick = resendCode;
    }
  }

  function resendCode(e) {
    e.preventDefault();
    // FOR BACKEND LATER !! ask the server to send a new code here
    expiresIn = 15 * 60;
    resendIn = 30;
    updateResend();
  }

  // runs every 1 second
  setInterval(function () {
    if (expiresIn > 0) {
      expiresIn = expiresIn - 1;
    }
    if (resendIn > 0) {
      resendIn = resendIn - 1;
    }
    expiresText.textContent = showTime(expiresIn);
    updateResend();
  }, 1000);

  updateResend();

  // front-end for now; stops the form from reloading the page
    // FOR BACKEND LATER !! remove this shi so the code is sent to the server
  document.querySelector("form").onsubmit = function (e) {
    e.preventDefault();
  };
</script>

</body>
</html>
