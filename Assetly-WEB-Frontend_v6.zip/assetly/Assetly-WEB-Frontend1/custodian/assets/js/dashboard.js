/* dashboard page: derives KPIs, attention list, deliveries, physical count and activity from window.DB */
(function () {
  const A = window.Assetly,
    DB = window.DB;

  const sumQty = (list, pred = () => true) =>
    list.reduce((n, a) => n + (pred(a) ? a.qty : 0), 0);
  const total = sumQty(DB.assets);
  const oper = sumQty(DB.assets, (a) => a.condition === "Operational");
  const maint = sumQty(DB.assets, (a) => a.condition === "Under maintenance");
  const storage = sumQty(DB.assets, (a) => a.condition === "In storage");

  /* KPIs */
  const openTickets = DB.tickets.filter((t) =>
    ["Pending", "Acknowledged", "In progress"].includes(t.status),
  ).length;
  const kpis = [
    {
      v: A.int(total),
      l: "Total assets",
      d: DB.assets.length + " records",
      ic: "brand",
      icon: "i-layers",
      cls: "kpi-total",
    },
    {
      v: A.int(oper),
      l: "Operational",
      d: (total ? Math.round((oper / total) * 100) : 0) + "% of assets",
      ic: "good",
      icon: "i-check-circle",
    },
    {
      v: A.int(maint),
      l: "Under maintenance",
      d: openTickets + " open tickets",
      ic: "warn",
      icon: "i-wrench",
    },
    {
      v: A.int(storage),
      l: "In storage",
      d: "Not yet issued",
      ic: "neutral",
      icon: "i-archive",
    },
  ];
  A.qs("#kpiRow").innerHTML = kpis
    .map(
      (k) => `
    <div class="kpi ${k.cls || ""}">
      <div><div class="v num">${k.v}</div><div class="l">${k.l}</div><div class="d">${k.d}</div></div>
      <div class="kpi-ic ${k.ic}"><svg class="i"><use href="#${k.icon}"/></svg></div>
    </div>`,
    )
    .join("");

  /* activity log: the card shows the latest 4; "View all" opens a dialog with every
     recorded action. The eye button on any row opens the details of that action. */
  const ACTIVITY_PREVIEW = 4;
  const events = [...DB.activity].sort((a, b) => b.at.localeCompare(a.at));

  /* icon + colour per kind of event */
  const evMeta = (name) =>
    /trash/i.test(name) ? { icon: "i-trash", tone: "bad" }
    : /approved/i.test(name) ? { icon: "i-check-circle", tone: "good" }
    : /import/i.test(name) ? { icon: "i-upload", tone: "info" }
    : /ticket/i.test(name) ? { icon: "i-wrench", tone: "warn" }
    : /report/i.test(name) ? { icon: "i-file", tone: "info" }
    : /updated|edit/i.test(name) ? { icon: "i-pencil", tone: "info" }
    : { icon: "i-clock", tone: "neutral" };

  const actRow = (e, i) => {
    const m = evMeta(e.event);
    return `
    <tr style="--r:${i}">
      <td class="muted" style="white-space:nowrap">${A.dateTime(e.at)}</td>
      <td class="cell-main"><span class="act-ev">${A.esc(e.event)}</span></td>
      <td>${A.esc(e.user)}</td>
      <td class="wrap muted">${A.esc(e.details)}</td>
      <td class="actions"><div class="row-actions"><button class="icon-btn sm" type="button" data-act="${i}" aria-label="View details: ${A.esc(e.event)}" title="View details"><svg class="i"><use href="#i-eye"/></svg></button></div></td>
    </tr>`;
  };

  const initials = (n) => String(n || "?").split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();
  /* log entry: dot on a vertical rail, event + details, then who and when. No box around it. */
  const actItem = (e, i) => {
    const m = evMeta(e.event);
    return `<div class="act-item ${m.tone}" style="--r:${i}" data-act="${i}" role="button" tabindex="0" aria-label="View details: ${A.esc(e.event)}">
      <span class="act-dot"></span>
      <div class="act-main"><strong>${A.esc(e.event)}</strong><span class="act-det">${A.esc(e.details)}</span></div>
      <div class="act-meta"><span>${A.esc(e.user)}</span><small>${A.dateTime(e.at)}</small></div>
    </div>`;
  };
  A.qs("#actCards").innerHTML = events.slice(0, ACTIVITY_PREVIEW).map(actItem).join("");
  A.qs("#activityAllTable tbody").innerHTML = events.map(actRow).join("");
  A.qs("#activitySub").textContent =
    `${events.length} recorded action${events.length === 1 ? "" : "s"}, newest first.`;

  const allBtn = A.qs("#activityAll");
  if (events.length <= ACTIVITY_PREVIEW) allBtn.hidden = true;
  allBtn.addEventListener("click", () => A.open("activityModal"));

  /* details of one action. Details are stored as "REF · summary" (e.g. "UR-0241 · Relocation: ..."),
     so the reference is split off and used to look up the linked record. With a real backend, send
     the record type and id with each activity row instead of parsing the text. */
  const roomLabel = (r) => (/^\d+$/.test(String(r)) ? "Room " + r : r);
  const where = (b, r) => `${A.esc(b)} · ${A.esc(roomLabel(r))}`;
  const field = (k, v, span) => `<div${span ? ' class="span-2"' : ""}><dt>${k}</dt><dd>${v}</dd></div>`;

  function linkedRecord(ref) {
    if (!ref) return null;
    if (ref.startsWith("UR-")) {
      const r = DB.reports.find((x) => x.id === ref);
      if (!r) return null;
      const move = r.type === "Relocation" && r.newBuilding
        ? field("Move", `${where(r.building, r.room)} &nbsp;→&nbsp; <strong style="color:var(--brand)">${where(r.newBuilding, r.newRoom)}</strong>`, true)
        : field("Location", where(r.building, r.room), true);
      return {
        title: "Update report " + r.id,
        html: field("Asset", A.esc(r.assetName), true) + field("Type", A.typeTag(r.type)) + field("Status", A.statusChip(r.status)) +
          field("Quantity", `<span class="num">${A.int(r.qty)}</span>`) + field("Submitted by", A.esc(r.submittedBy)) + move +
          (r.description ? field("Teacher's note", `<span style="font-weight:400">${A.esc(r.description)}</span>`, true) : ""),
        href: "custodian_update_reports.php", linkText: "Open update reports",
      };
    }
    if (ref.startsWith("DT-")) {
      const t = DB.tickets.find((x) => x.id === ref);
      if (!t) return null;
      return {
        title: "Defect ticket " + t.id,
        html: field("Asset", `${A.esc(t.assetName)} <span class="muted">(${A.esc(t.assetId)})</span>`, true) + field("Defect", A.esc(t.defectType)) +
          field("Status", A.statusChip(t.status)) + field("Reported by", A.esc(t.submittedBy)) + field("Location", where(t.building, t.room)) +
          (t.description ? field("Description", `<span style="font-weight:400">${A.esc(t.description)}</span>`, true) : ""),
        href: "custodian_defect_tickets.php", linkText: "Open defect tickets",
      };
    }
    if (ref.startsWith("AST-")) {
      const a = DB.assets.find((x) => x.id === ref || (x.units || []).includes(ref));
      if (!a) return null;
      return {
        title: "Asset " + ref,
        html: field("Asset", A.esc(a.name), true) + field("Category", A.esc(a.category)) + field("Condition", A.conditionChip(a.condition)) +
          field("Location", where(a.building, a.room)) + field("Fund source", A.esc(a.fundSource || "—")),
        href: "custodian_assets.php", linkText: "Open assets",
      };
    }
    return null;
  }

  /* events with no single linked record still point to the page where the result lives */
  const EVENT_LINKS = {
    "Assets moved to trash": ["custodian_trash.php", "Open trash"],
    "Assets imported": ["custodian_assets.php", "Open assets"],
  };

  function openActivity(i) {
    const e = events[i];
    const m = /^([A-Z]{2,3}-\d+)\s·\s(.*)$/.exec(e.details);
    const ref = m ? m[1] : null;
    const summary = m ? m[2] : e.details;
    const rec = linkedRecord(ref);
    const link = rec ? [rec.href, rec.linkText] : EVENT_LINKS[e.event];

    A.qs("#actTitle").textContent = e.event;
    A.qs("#actSub").textContent = (ref ? ref + " · " : "") + A.dateTime(e.at);
    A.qs("#actBody").innerHTML = `
      <div class="meta-strip">
        <div><small class="muted">Done by</small><br><strong>${A.esc(e.user)}</strong></div>
        <div><small class="muted">Date</small><br><strong>${A.date(e.at)}</strong></div>
        <div><small class="muted">Time</small><br><strong>${A.dateTime(e.at).split(" · ")[1]}</strong></div>
      </div>
      <dl class="dl">
        ${field("Action", A.esc(e.event))}
        ${field("Reference", ref ? `<span class="num">${A.esc(ref)}</span>` : "—")}
        ${field("Details", `<span style="font-weight:400">${A.esc(summary)}</span>`, true)}
      </dl>
      ${rec ? `<div><div class="section-title">${A.esc(rec.title)}</div><dl class="dl" style="margin-top:10px">${rec.html}</dl></div>` : ""}`;
    A.qs("#actFoot").innerHTML =
      `<button class="btn btn-secondary" data-close type="button">Close</button>` +
      (link ? `<a class="btn btn-primary" href="${A.esc(link[0])}">${A.esc(link[1])} <svg class="i"><use href="#i-arrow-right"/></svg></a>` : "");
    A.open("activityDrawer");
  }

  ["#actCards", "#activityAllTable"].forEach((sel) =>
    A.qs(sel).addEventListener("click", (ev) => {
      const b = ev.target.closest("[data-act]");
      if (b) openActivity(Number(b.dataset.act));
    }),
  );
  A.qs("#actCards").addEventListener("keydown", (ev) => {
    const b = ev.target.closest("[data-act]");
    if (b && (ev.key === "Enter" || ev.key === " ")) { ev.preventDefault(); openActivity(Number(b.dataset.act)); }
  });

  /* assets by building: one bar per building, most units first.
     Hover a bar to see how its units split by condition. */
  (function () {
    const host = A.qs("#bldChart");
    if (!host) return;
    const COND_COLOR = { "Operational": "#2e9e4a", "Under maintenance": "#e8a33a", "In storage": "#9aa0b8", "For disposal": "#d9475b" };
    /* every building in DB.buildings gets a bar (0 when it has no assets); an asset whose building is
       missing from that list is still counted instead of being dropped */
    const by = new Map(DB.buildings.map((b) => [b, { name: b, total: 0, cond: {} }]));
    DB.assets.forEach((a) => {
      if (!by.has(a.building)) by.set(a.building, { name: a.building, total: 0, cond: {} });
      const row = by.get(a.building);
      row.total += a.qty;
      row.cond[a.condition] = (row.cond[a.condition] || 0) + a.qty;
    });
    const rows = [...by.values()].sort((x, y) => y.total - x.total); /* stable: empty buildings keep the data.js order */
    if (!rows.length) {
      host.innerHTML = `<div class="empty"><svg class="i"><use href="#i-building"/></svg><strong>No buildings yet</strong>Buildings will appear here once they are set up.</div>`;
      return;
    }
    const grand = rows.reduce((n, r) => n + r.total, 0);
    const used = rows.filter((r) => r.total > 0).length;
    A.qs("#bldSub").textContent = `Units per building, most to least.`;
    A.qs("#bldTotal").innerHTML = `<strong class="num">${A.int(grand)}</strong> units · ${used} of ${rows.length} building${rows.length === 1 ? "" : "s"} with assets`;

    const short = (n) => n.replace(/\s+Building$/i, "");
    const cut = (t, n) => (t.length > n ? t.slice(0, n - 1) + "…" : t);
    const wrap = (name, n) => {
      const nm = short(name);
      if (nm.length <= n || !nm.includes(" ")) return [cut(nm, n)];
      const words = nm.split(" "); let l1 = words.shift();
      while (words.length && (l1 + " " + words[0]).length <= n) l1 += " " + words.shift();
      return words.length ? [cut(l1, n), cut(words.join(" "), n)] : [l1];
    };
    const niceStep = (v) => { const p = Math.pow(10, Math.floor(Math.log10(v))), f = v / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p; };
    const H = 160, M = { l: 38, r: 12, t: 18, b: 34 };
    let drawnW = 0, firstDraw = true;
    function draw() {
      const W = Math.max(320, host.clientWidth || 640);
      if (W === drawnW) return;
      drawnW = W;
      const iw = W - M.l - M.r, ih = H - M.t - M.b;
      const peak = Math.max(1, rows[0].total), step = niceStep(peak / 3), top = Math.ceil(peak / step) * step;
      const Y = (v) => M.t + ih - (ih * v) / top;
      const band = iw / rows.length, bw = Math.min(46, band * 0.58);
      const cx = (i) => M.l + band * i + band / 2;
      const maxChars = Math.max(4, Math.floor(band / 6.2));
      const ticks = Array.from({ length: Math.round(top / step) + 1 }, (_, i) => i * step);

      const grid = ticks.map((v) => `<line x1="${M.l}" x2="${W - M.r}" y1="${Y(v)}" y2="${Y(v)}" stroke="#d9dcec" stroke-dasharray="2 4"/><text x="${M.l - 8}" y="${Y(v) + 4}" text-anchor="end">${A.int(v)}</text>`).join("");
      const bars = rows.map((r, i) => {
        const h = r.total ? Math.max(3, ih * r.total / top) : 0, x = cx(i) - bw / 2, y = M.t + ih - h;
        const lines = wrap(r.name, maxChars);
        const path = h ? `<path d="M${x},${y + h} V${y + 5} Q${x},${y} ${x + 5},${y} H${x + bw - 5} Q${x + bw},${y} ${x + bw},${y + 5} V${y + h} Z" fill="url(#bld-g)"/>` : "";
        return `<g class="bld-bar${r.total ? "" : " zero"}" data-i="${i}" style="--i:${i}">${path}` +
          `<text class="v" x="${cx(i)}" y="${y - 5}" text-anchor="middle">${A.int(r.total)}</text>` +
          lines.map((ln, k) => `<text x="${cx(i)}" y="${M.t + ih + 14 + k * 12}" text-anchor="middle">${A.esc(ln)}</text>`).join("") + `</g>`;
      }).join("");
      const defs = `<linearGradient id="bld-g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4361e8"/><stop offset="1" stop-color="#7f95f2"/></linearGradient>`;
      const label = `Assets by building: ` + rows.map((r) => `${r.name} ${r.total}`).join(", ");
      host.innerHTML = `<svg class="${firstDraw ? "bld-anim" : ""}" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="${A.esc(label)}"><defs>${defs}</defs>${grid}${bars}<rect class="bld-hit" x="${M.l}" y="0" width="${iw}" height="${H}" fill="transparent"/></svg><div class="bld-tip" hidden></div>`;

      firstDraw = false;
      const svg = host.querySelector("svg"), hit = host.querySelector(".bld-hit"), tip = host.querySelector(".bld-tip");
      const focus = (i) => { svg.classList.toggle("is-hover", i !== null); host.querySelectorAll(".bld-bar").forEach((g) => g.classList.toggle("on", Number(g.dataset.i) === i)); };
      const show = (e) => {
        const bx = svg.getBoundingClientRect();
        const i = Math.min(rows.length - 1, Math.max(0, Math.floor((e.clientX - bx.left - M.l) / band)));
        const r = rows[i];
        focus(i);
        tip.innerHTML = r.total === 0
          ? `<strong>${A.esc(r.name)}</strong><div style="opacity:.75">No assets recorded</div>`
          : `<strong>${A.esc(r.name)}</strong><div class="row tot"><span>Total</span><b class="num">${A.int(r.total)} units</b></div>` +
          Object.entries(r.cond).sort((x, y) => y[1] - x[1]).map(([c, n]) => `<div class="row"><span><i style="background:${COND_COLOR[c] || "#9aa0b8"}"></i>${A.esc(c)}</span><b class="num">${A.int(n)}</b></div>`).join("");
        tip.hidden = false;
        const x = cx(i) + band / 2 + 8 + tip.offsetWidth > W ? cx(i) - band / 2 - 8 - tip.offsetWidth : cx(i) + band / 2 + 8;
        tip.style.left = Math.max(0, x) + "px";
        tip.style.top = Math.max(0, Math.min(M.t, H - tip.offsetHeight)) + "px";
      };
      hit.addEventListener("pointermove", show);
      hit.addEventListener("pointerdown", show);
      hit.addEventListener("pointerleave", () => { focus(null); tip.hidden = true; });
    }
    draw();
    if (window.ResizeObserver) new ResizeObserver(draw).observe(host);
  })();

  /* needs attention */
  const pendingReports = DB.reports.filter(
    (r) => r.status === "Pending",
  ).length;
  const pendingRooms = (DB.roomRequests || []).filter(
    (r) => r.status === "Pending",
  ).length;
  const attn = [
    {
      t: "Pending room requests",
      s: "Requested or released by teachers",
      n: pendingRooms,
      href: "custodian_room_requests.php",
      ic: "info",
      icon: "i-map-pin",
      hot: pendingRooms > 0,
    },
    {
      t: "Pending update reports",
      s: "Submitted by teachers",
      n: pendingReports,
      href: "custodian_update_reports.php",
      ic: "warn",
      icon: "i-file",
      hot: pendingReports > 0,
    },
    {
      t: "Open defect tickets",
      s: "Not yet resolved",
      n: openTickets,
      href: "custodian_defect_tickets.php",
      ic: "bad",
      icon: "i-wrench",
      hot: openTickets > 0,
    },
  ];
  A.qs("#attnList").innerHTML = attn
    .map(
      (a) => `
    <a href="${a.href}">
      <span class="attn-ic ${a.ic}"><svg class="i"><use href="#${a.icon}"/></svg></span>
      <span><span class="attn-t">${a.t}</span><br><span class="attn-s">${a.s}</span></span>
      <span class="n ${a.hot ? "hot" : ""}">${a.n}</span>
    </a>`,
    )
    .join("");

  /* AI recommendations */
  A.qs("#recoList").innerHTML = DB.recommendations
    .map(
      (r) => `
    <div class="reco-item">
      <div class="reco-top"><span class="priority ${r.level}">${A.esc(r.level[0].toUpperCase() + r.level.slice(1))}</span><a href="${A.esc(r.link)}">${A.esc(r.linkText)}</a></div>
      <p>${A.esc(r.title)}</p>
      <small class="muted">${A.esc(r.why)}</small>
    </div>`,
    )
    .join("");

  /* recent deliveries: latest one as a source → Property Office timeline, the next two as short rows */
  const dlvSorted = [...DB.deliveries].sort((a, b) => b.dateDelivered.localeCompare(a.dateDelivered));
  const unitsExp = (d) => d.items.reduce((n, i) => n + (i.expected || 0), 0);
  const unitsRec = (d) => d.items.reduce((n, i) => n + (i.received || 0), 0);
  const unitsDmg = (d) => d.items.reduce((n, i) => n + (i.damaged || 0), 0);
  if (!dlvSorted.length) {
    A.qs("#dlvPanel").innerHTML = `<div class="empty"><svg class="i"><use href="#i-truck"/></svg><strong>No deliveries yet</strong>Log a delivery when items arrive.</div>`;
  } else {
    const d = dlvSorted[0];
    const exp = unitsExp(d), rec = unitsRec(d), dmg = unitsDmg(d);
    const counted = d.status !== "Logged";
    const diff = rec - exp;
    const pct = counted && exp ? Math.min(100, Math.round((rec / exp) * 100)) : 0;
    const diffCls = diff < 0 ? "text-danger" : diff > 0 ? "text-warn" : "muted";
    const earlier = dlvSorted.slice(1, 3)
      .map((e) => {
        const c = e.status !== "Logged";
        return `<a class="dlvp-row" href="custodian_deliveries.php">
          <span><strong>${A.esc(e.ref)}</strong><small class="muted">${A.esc(e.source)} · ${A.date(e.dateDelivered)}</small></span>
          <span class="dlvp-qty num">${c ? A.int(unitsRec(e)) : "—"} <small class="muted">/ ${A.int(unitsExp(e))}</small></span>
          ${A.statusChip(e.status)}
        </a>`;
      })
      .join("");
    A.qs("#dlvPanel").innerHTML = `
      <div class="dlvc-head">
        <div style="min-width:0"><div class="dlvc-ref">${A.esc(d.ref)}</div><div class="dlvc-sub dlvp-src">${A.esc(d.source)} · ${A.date(d.dateDelivered)}</div></div>
        ${A.statusChip(d.status)}
      </div>
      <div class="dlvc-stops" style="margin-top:12px">
        <div class="dlvc-stop">
          <span class="dlvc-dot"><i></i></span>
          <div class="dlvc-body"><div class="dlvc-line"><span>Delivered (expected)</span><strong class="num">${A.int(exp)} units</strong></div></div>
        </div>
        <div class="dlvc-stop">
          <span class="dlvc-dot ${d.status === "Posted" ? "done" : "pin"}"><svg class="i"><use href="#${d.status === "Posted" ? "i-check" : "i-map-pin"}"/></svg></span>
          <div class="dlvc-body"><div class="dlvc-line"><span>Actual received</span><strong class="num">${counted ? A.int(rec) + " units" : "Not counted yet"}</strong></div></div>
        </div>
      </div>
      <div class="dlvp-bar" title="${pct}% of expected units received"><span style="--w:${pct}%"></span></div>
      <div class="dlvp-foot">
        <span>${counted ? `<span class="${diffCls}">${diff > 0 ? "+" : ""}${A.int(diff)}</span> variance` : "Not counted yet"}</span>
        <span class="muted">Damaged: ${counted ? A.int(dmg) : "—"}</span>
      </div>
      ${earlier ? `<div class="dlvp-list"><div class="section-title">Earlier</div>${earlier}</div>` : ""}`;
  }

  /* physical count: one ring per status, each ring scaled to all teachers in the open period.
     Draft and Not started are both "Not submitted" (what the Remind button targets). */
  (function () {
    const period = (DB.countPeriods || []).find((p) => p.status === "Open");
    const panel = A.qs("#pcPanel");
    if (!period) {
      A.qs("#pcSub").textContent = "No count period is open.";
      panel.innerHTML = `<div class="empty"><svg class="i"><use href="#i-clipboard"/></svg><strong>No open count period</strong>Open one from the Physical count page.</div>`;
      return;
    }
    const subs = DB.countSubmissions.filter((s) => s.periodId === period.id);
    const total = subs.length;
    const n = (...st) => subs.filter((s) => st.includes(s.status)).length;
    const parts = [
      { l: "Verified", v: n("Verified"), c1: "#2e9e4a", c2: "#7ad394", tone: "good" },
      { l: "Submitted", v: n("Submitted"), c1: "#4361e8", c2: "#7f95f2", tone: "info" },
      { l: "Returned", v: n("Returned"), c1: "#d9475b", c2: "#f08a98", tone: "bad" },
      { l: "Not submitted", v: n("Not started", "Draft"), c1: "#9aa0b8", c2: "#cdd1e2", tone: "neutral" },
    ];
    /* progress = teachers who already submitted (Submitted + Verified), same as the Physical count page */
    const doneCount = n("Submitted", "Verified");
    A.qs("#pcSub").textContent = `${period.period} · ${doneCount} of ${total} teachers submitted`;
    const R = 78, SW = 30, C = 110, GAP = 3, CIRC = 2 * Math.PI * R;
    const pct = (v) => (total ? Math.round((v / total) * 100) : 0);
    const used = parts.filter((p) => p.v).length;
    const gapDeg = used > 1 ? (GAP / CIRC) * 360 : 0;
    /* point on the ring at `deg` degrees clockwise from 12 o'clock */
    const pt = (deg) => {
      const r = ((deg - 90) * Math.PI) / 180;
      return [(C + R * Math.cos(r)).toFixed(2), (C + R * Math.sin(r)).toFixed(2)];
    };
    /* each status is its own arc so its gradient fits that arc; pathLength=100 lets CSS draw it in */
    const defs = parts
      .map((p, i) => `<linearGradient id="pcr-g${i}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${p.c1}"/><stop offset="1" stop-color="${p.c2}"/></linearGradient>`)
      .join("");
    let cum = 0, order = 0;
    const segs = parts
      .map((p, i) => {
        if (!p.v) return "";
        const d0 = (cum / total) * 360 + gapDeg / 2;
        const d1 = Math.min(Math.max(((cum + p.v) / total) * 360 - gapDeg / 2, d0 + 0.5), d0 + 359.99);
        cum += p.v;
        const [x0, y0] = pt(d0), [x1, y1] = pt(d1);
        return `<path class="pcr-seg" data-i="${i}" style="--d:${order++ * 140}ms" d="M${x0} ${y0} A${R} ${R} 0 ${d1 - d0 > 180 ? 1 : 0} 1 ${x1} ${y1}" fill="none" stroke="url(#pcr-g${i})" stroke-width="${SW}" pathLength="100"/>`;
      })
      .join("");
    panel.innerHTML = `
      <div class="pcr-wrap">
        <div class="pcr">
          <svg viewBox="0 0 220 220" role="img" aria-label="Physical count status by teacher">
            <defs>${defs}</defs>
            <circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="#eceffb" stroke-width="${SW}"/>
            <circle class="pcr-orbit" cx="${C}" cy="${C}" r="${R - SW / 2 - 8}" fill="none" stroke="#d6dbf0" stroke-width="1.5" stroke-dasharray="2 6" stroke-linecap="round"/>
            ${segs}
          </svg>
          <div class="pcr-center"><strong class="num">${pct(doneCount)}%</strong><span>${A.esc(period.period)}</span></div>
          <div class="pcr-tip" hidden></div>
        </div>
        <div class="pcr-list">
          ${parts.map((p, i) => `<a class="pcr-row" data-i="${i}" style="--i:${i}" href="custodian_physical_count.php">
            <span class="pcr-sw" style="background:linear-gradient(135deg,${p.c1},${p.c2})"></span>
            <span class="pcr-l"><span>${p.l}</span><small>${pct(p.v)}%</small><span class="pcr-bar"><i style="--w:${pct(p.v)}%;background:linear-gradient(90deg,${p.c1},${p.c2})"></i></span></span>
            <strong class="num">${p.v}</strong>
          </a>`).join("")}
        </div>
      </div>`;

    /* count the centre percentage up from 0 (skipped when the user prefers reduced motion) */
    const big = A.qs(".pcr-center strong", panel), target = pct(doneCount);
    if (target > 0 && !(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches)) {
      const t0 = performance.now(), dur = 1000;
      big.textContent = "0%";
      const tick = (t) => {
        const k = Math.min(1, (t - t0) / dur);
        big.textContent = Math.round(target * (1 - Math.pow(1 - k, 3))) + "%";
        if (k < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }

    /* hover: tooltip on a donut segment; the matching segment and legend row stay highlighted, the rest dim */
    const box = A.qs(".pcr", panel), tip = A.qs(".pcr-tip", panel);
    const focus = (i) => {
      box.classList.toggle("is-hover", i !== null);
      A.qsa(".pcr-seg", panel).forEach((g) => g.classList.toggle("on", Number(g.dataset.i) === i));
      A.qsa(".pcr-row", panel).forEach((r) => r.classList.toggle("on", Number(r.dataset.i) === i));
    };
    A.qsa(".pcr-seg", panel).forEach((g) => {
      const i = Number(g.dataset.i), p = parts[i];
      g.addEventListener("mouseenter", () => {
        focus(i);
        tip.innerHTML = `<strong>${p.l}</strong>: ${p.v} of ${total} teacher${total === 1 ? "" : "s"} (${pct(p.v)}%)`;
        tip.hidden = false;
      });
      g.addEventListener("mousemove", (e) => {
        const b = box.getBoundingClientRect();
        const x = Math.min(Math.max(e.clientX - b.left + 12, 0), b.width - tip.offsetWidth);
        tip.style.left = x + "px";
        tip.style.top = Math.max(e.clientY - b.top - tip.offsetHeight - 10, 0) + "px";
      });
      g.addEventListener("mouseleave", () => { focus(null); tip.hidden = true; });
    });
    A.qsa(".pcr-row", panel).forEach((r) => {
      r.addEventListener("mouseenter", () => focus(Number(r.dataset.i)));
      r.addEventListener("mouseleave", () => focus(null));
    });
  })();
})();