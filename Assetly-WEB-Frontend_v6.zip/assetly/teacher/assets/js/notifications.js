/* Teacher notification panel: a bell at the top right of every page, same panel as the custodian's.
   Items are built from window.TDB: answers to your room requests, update reports and defect tickets,
   plus the physical count (open, returned, awaiting verification).
   Read state is kept in localStorage for this mock-up (T.store); with a real backend, load the list
   from the server and send "mark read" back to it.
   Load AFTER app.js and data.js (see footer.php). */
(function () {
  const T = window.T, D = window.TDB;
  if (!T || !D) return;
  const { qs, esc, date, daysUntil, store } = T;

  /* ---------- icons: add the two this panel needs if the page's sprite does not have them ---------- */
  const NEED = {
    "i-bell": '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
    "i-check-circle": '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
  };
  const missing = Object.keys(NEED).filter((id) => !document.getElementById(id));
  if (missing.length) {
    document.body.insertAdjacentHTML(
      "afterbegin",
      `<svg aria-hidden="true" style="position:absolute;width:0;height:0;overflow:hidden">${missing
        .map((id) => `<symbol id="${id}" viewBox="0 0 24 24">${NEED[id]}</symbol>`)
        .join("")}</svg>`,
    );
  }

  /* ---------- bell: use #notifBtn if the header already has one, otherwise add it ---------- */
  let btn = qs("#notifBtn");
  if (!btn) {
    const main = qs(".main") || document.body;
    const host = document.createElement("div");
    host.className = "notif-host";
    host.innerHTML = `<button class="icon-btn" id="notifBtn" type="button" aria-label="Notifications"><svg class="i"><use href="#i-bell"/></svg></button>`;
    main.prepend(host);
    btn = qs("#notifBtn", host);
  }

  /* ---------- items ---------- */
  const NOW = T.TODAY; /* demo date from app.js; use new Date() in production */
  const RECENT_DAYS = 14; /* older answers are listed, but already marked as read */
  const roomLabel = (r) => (/^\d+$/.test(String(r)) ? "Room " + r : r);
  const lastAt = (r) => (r.history && r.history.length ? r.history[r.history.length - 1].at : r.submittedAt);
  const items = [];

  /* room requests the custodian answered */
  (store.get("roomRequests") || D.roomRequests)
    .filter((q) => q.status === "Approved" || q.status === "Rejected")
    .forEach((q) => {
      const ok = q.status === "Approved";
      const noun = q.kind === "Release" ? "Room release" : "Room request";
      items.push({
        id: "rm:" + q.id, at: q.answeredAt || q.submittedAt, tone: ok ? "good" : "bad", icon: "i-map",
        href: "teacher_my_assets.php",
        title: `${noun} ${ok ? "approved" : "rejected"}`,
        text: `${q.building} · ${roomLabel(q.room)}`,
      });
    });

  /* update reports the custodian reviewed */
  D.reports
    .filter((r) => r.status === "Approved" || r.status === "Rejected")
    .forEach((r) => {
      const ok = r.status === "Approved";
      items.push({
        id: "ur:" + r.id, at: lastAt(r), tone: ok ? "good" : "bad", icon: ok ? "i-file-check" : "i-ban",
        href: `teacher_my_reports.php?tab=updates&id=${r.id}`,
        title: `Update report ${ok ? "approved" : "rejected"}`,
        text: `${r.type}: ${r.assetName}`,
      });
    });

  /* defect tickets that moved past Pending */
  const TICKET = {
    Acknowledged: { tone: "info", icon: "i-wrench", title: "Defect ticket acknowledged" },
    "In progress": { tone: "info", icon: "i-wrench", title: "Defect ticket in progress" },
    Resolved: { tone: "good", icon: "i-check", title: "Defect ticket resolved" },
    Rejected: { tone: "bad", icon: "i-ban", title: "Defect ticket rejected" },
  };
  D.tickets
    .filter((t) => TICKET[t.status])
    .forEach((t) => {
      const m = TICKET[t.status];
      items.push({
        id: "dt:" + t.id + ":" + t.status, at: lastAt(t), tone: m.tone, icon: m.icon,
        href: `teacher_my_reports.php?tab=tickets&id=${t.id}`,
        title: m.title, text: `${t.defectType} · ${t.assetName}`,
      });
    });

  /* physical count */
  const P = D.countPeriod, saved = store.get("count." + P.id), cs = saved ? saved.status : "Not started";
  const left = daysUntil(P.dueAt);
  if (cs === "Returned") {
    items.push({ id: "pc:returned:" + P.id, at: saved.submittedAt || P.opensAt, tone: "bad", icon: "i-clipboard", href: "teacher_physical_count.php",
      title: "Count returned by the custodian", text: `${P.period}: fix the marked items and submit again` });
  } else if (cs === "Verified") {
    items.push({ id: "pc:verified:" + P.id, at: saved.submittedAt || P.opensAt, tone: "good", icon: "i-clipboard", href: "teacher_physical_count.php",
      title: "Your count was verified", text: `${P.period} physical count`, done: true });
  } else if (cs === "Submitted") {
    items.push({ id: "pc:sent:" + P.id, at: saved.submittedAt || P.opensAt, tone: "info", icon: "i-clipboard", href: "teacher_physical_count.php",
      title: "Count sent to the custodian", text: `${P.period}: waiting for verification`, done: true });
  } else {
    items.push({ id: "pc:open:" + P.id, at: P.opensAt + "T08:00:00", tone: left <= 7 ? "bad" : "warn", icon: "i-clipboard", href: "teacher_physical_count.php",
      title: `${P.period} physical count is open`, text: `Due ${date(P.dueAt)} · ${left} day${left === 1 ? "" : "s"} left`, always: true });
  }

  /* anything older than RECENT_DAYS is shown, but not counted as unread */
  const ageDays = (iso) => (NOW - new Date(iso.length === 10 ? iso + "T00:00:00" : iso)) / 86400000;
  items.forEach((n) => { if (!n.always && ageDays(n.at) > RECENT_DAYS) n.done = true; });
  items.sort((a, b) => String(b.at || "").localeCompare(String(a.at || "")));
  items.splice(14);

  /* ---------- read state ---------- */
  const KEY = "notifRead";
  const seen = new Set(store.get(KEY) || []);
  const persist = () => store.set(KEY, [...seen]);
  const isRead = (n) => n.done || seen.has(n.id);
  const unread = () => items.filter((n) => !isRead(n)).length;

  /* "2h ago" for the last week, a plain date after that */
  const ago = (iso) => {
    if (!iso) return "";
    const d = new Date(iso.length === 10 ? iso + "T00:00:00" : iso);
    const mins = Math.round((NOW - d) / 60000);
    if (mins >= 0 && mins < 1) return "Just now";
    if (mins >= 0 && mins < 60) return mins + "m ago";
    if (mins >= 0 && mins < 1440) return Math.floor(mins / 60) + "h ago";
    if (mins >= 0 && mins < 10080) return Math.floor(mins / 1440) + "d ago";
    return date(iso);
  };

  /* ---------- panel ---------- */
  const host = btn.parentElement;
  const panel = document.createElement("div");
  panel.className = "notif-panel";
  panel.id = "notifPanel";
  panel.hidden = true;
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-label", "Notifications");
  host.appendChild(panel);
  btn.setAttribute("aria-haspopup", "dialog");
  btn.setAttribute("aria-expanded", "false");
  btn.setAttribute("aria-controls", "notifPanel");

  let tab = "all";

  function updateBadge() {
    const n = unread();
    let b = qs(".badge-dot", btn);
    if (!n) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement("span"); b.className = "badge-dot"; btn.appendChild(b); }
    b.textContent = n > 9 ? "9+" : n;
  }

  function render() {
    const n = unread();
    const list = tab === "unread" ? items.filter((x) => !isRead(x)) : items;
    panel.innerHTML = `
      <div class="notif-h">
        <div><h2>Notifications</h2><p>${n ? `${n} new update${n === 1 ? "" : "s"} for you` : "You're all caught up"}</p></div>
        <button class="notif-link" id="notifMarkAll" type="button" ${n ? "" : "disabled"}>Mark all as read</button>
      </div>
      <div class="notif-tabs" role="tablist">
        <button role="tab" type="button" data-tab="all" aria-selected="${tab === "all"}" class="${tab === "all" ? "is-on" : ""}">All</button>
        <button role="tab" type="button" data-tab="unread" aria-selected="${tab === "unread"}" class="${tab === "unread" ? "is-on" : ""}">Unread${n ? ` <b>${n}</b>` : ""}</button>
      </div>
      <div class="notif-list">
        ${list.length ? list.map((x, i) => `
          <a class="notif-item${isRead(x) ? "" : " is-unread"}" style="--i:${i}" href="${esc(x.href)}" data-id="${esc(x.id)}">
            <span class="notif-ic ${x.tone}"><svg class="i"><use href="#${x.icon}"/></svg></span>
            <span class="notif-body">
              <span class="notif-t">${esc(x.title)}</span>
              <span class="notif-s">${esc(x.text)}</span>
              <span class="notif-time">${esc(ago(x.at))}</span>
            </span>
            <span class="notif-dot" aria-label="${isRead(x) ? "" : "Unread"}"></span>
          </a>`).join("") : `
          <div class="notif-empty"><svg class="i"><use href="#i-check-circle"/></svg><strong>${tab === "unread" ? "Nothing unread" : "No notifications"}</strong><span>Answers to your reports, tickets and room requests will show up here.</span></div>`}
      </div>`;
    updateBadge();
  }

  function setOpen(open) {
    panel.hidden = !open;
    btn.setAttribute("aria-expanded", String(open));
    if (open) render();
  }

  btn.addEventListener("click", (e) => { e.stopPropagation(); setOpen(panel.hidden); });
  /* use the event path, not e.target: switching tabs re-renders the panel, so by the time this runs the
     clicked button is no longer in the DOM and panel.contains(e.target) would wrongly say "outside" */
  document.addEventListener("click", (e) => {
    const path = e.composedPath ? e.composedPath() : [];
    const inside = path.includes(panel) || path.includes(btn);
    if (!panel.hidden && !inside) setOpen(false);
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !panel.hidden) { setOpen(false); btn.focus(); }
  });

  panel.addEventListener("click", (e) => {
    const t = e.target.closest("[data-tab]");
    if (t) { tab = t.dataset.tab; render(); return; }
    if (e.target.closest("#notifMarkAll")) {
      items.forEach((x) => seen.add(x.id));
      persist(); render();
      T.toast("All notifications marked as read.");
      return;
    }
    const it = e.target.closest(".notif-item");
    if (it) { seen.add(it.dataset.id); persist(); } /* then follow the link */
  });

  updateBadge();
  if (unread()) {
    btn.classList.add("is-ring");
    setTimeout(() => btn.classList.remove("is-ring"), 1600);
  }
})();
