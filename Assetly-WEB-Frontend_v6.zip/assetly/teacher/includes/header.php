<?php

/**
 * shared head, icon sprite and sidebar for the Teacher interface.
 *
 * set before including:
 *   $pageTitle   string  browser tab title.
 *   $active      string  sidebar key: home | assets | count | update | defect | reports
 *   $pageScripts array   page JS files in assets/js/ (loaded by footer.php).
 *
 * replace the hard-coded user block with values from your session later.
 */
$pageTitle    = $pageTitle    ?? 'Assetly';
$active       = $active       ?? '';
$pageScripts  = $pageScripts  ?? [];
$userName     = $userName     ?? 'Jose Mari Chan';
$userRole     = $userRole     ?? 'Teacher';
$userInitials = $userInitials ?? 'JC';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle) ?> · Assetly</title>
  <link rel="icon" type="image/png" href="assets/img/assetly-icon.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/teacher.css">
</head>

<body data-page="<?= htmlspecialchars($active) ?>">

  <!-- icon sprite. use with: <svg class="i"><use href="#i-name"/></svg> -->
  <svg xmlns="http://www.w3.org/2000/svg" style="display:none">
    <symbol id="i-home" viewBox="0 0 24 24">
      <path d="M3 10.5 12 3l9 7.5" />
      <path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5" />
    </symbol>
    <symbol id="i-plus-square" viewBox="0 0 24 24">
      <rect x="3" y="3" width="18" height="18" rx="3" />
      <path d="M12 8v8M8 12h8" />
    </symbol>
    <symbol id="i-alert" viewBox="0 0 24 24">
      <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
      <path d="M12 9v4" />
      <path d="M12 17h.01" />
    </symbol>
    <symbol id="i-file" viewBox="0 0 24 24">
      <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
      <path d="M14 2v4a2 2 0 0 0 2 2h4" />
      <path d="M16 13H8" />
      <path d="M16 17H8" />
    </symbol>
    <symbol id="i-file-check" viewBox="0 0 24 24">
      <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
      <path d="M14 2v4a2 2 0 0 0 2 2h4" />
      <path d="m9 15 2 2 4-4" />
    </symbol>
    <symbol id="i-ticket" viewBox="0 0 24 24">
      <path d="M2 9a3 3 0 0 0 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 0 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z" />
      <path d="M13 5v2M13 17v2M13 11v2" />
    </symbol>
    <symbol id="i-package" viewBox="0 0 24 24">
      <path d="m7.5 4.27 9 5.15" />
      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
      <path d="m3.3 7 8.7 5 8.7-5" />
      <path d="M12 22V12" />
    </symbol>
    <symbol id="i-clipboard" viewBox="0 0 24 24">
      <rect width="8" height="4" x="8" y="2" rx="1" />
      <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
      <path d="m9 14 2 2 4-4" />
    </symbol>
    <symbol id="i-wrench" viewBox="0 0 24 24">
      <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
    </symbol>
    <symbol id="i-clock" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </symbol>
    <symbol id="i-check" viewBox="0 0 24 24">
      <path d="M20 6 9 17l-5-5" />
    </symbol>
    <symbol id="i-ban" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="9" />
      <path d="m5.7 5.7 12.6 12.6" />
    </symbol>
    <symbol id="i-eye" viewBox="0 0 24 24">
      <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z" />
      <circle cx="12" cy="12" r="3" />
    </symbol>
    <symbol id="i-plus" viewBox="0 0 24 24">
      <path d="M5 12h14M12 5v14" />
    </symbol>
    <symbol id="i-camera" viewBox="0 0 24 24">
      <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3Z" />
      <circle cx="12" cy="13" r="3" />
    </symbol>
    <symbol id="i-chevron-right" viewBox="0 0 24 24">
      <path d="m9 18 6-6-6-6" />
    </symbol>
    <symbol id="i-logout" viewBox="0 0 24 24">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
      <path d="m16 17 5-5-5-5" />
      <path d="M21 12H9" />
    </symbol>
    <symbol id="i-menu" viewBox="0 0 24 24">
      <path d="M4 6h16M4 12h16M4 18h16" />
    </symbol>
    <symbol id="i-search" viewBox="0 0 24 24">
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </symbol>
    <symbol id="i-calendar" viewBox="0 0 24 24">
      <rect width="18" height="18" x="3" y="4" rx="2" />
      <path d="M16 2v4M8 2v4M3 10h18" />
    </symbol>
    <symbol id="i-map" viewBox="0 0 24 24">
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
      <circle cx="12" cy="10" r="3" />
    </symbol>
    <symbol id="i-x" viewBox="0 0 24 24">
      <path d="M18 6 6 18M6 6l12 12" />
    </symbol>
    <symbol id="i-info" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <path d="M12 16v-4M12 8h.01" />
    </symbol>
    <symbol id="i-save" viewBox="0 0 24 24">
      <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
      <path d="M17 21v-8H7v8M7 3v5h8" />
    </symbol>
    <symbol id="i-send" viewBox="0 0 24 24">
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </symbol>
    <symbol id="i-printer" viewBox="0 0 24 24">
      <path d="M6 9V2h12v7" />
      <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" />
      <rect width="12" height="8" x="6" y="14" rx="1" />
    </symbol>
    <symbol id="i-layers" viewBox="0 0 24 24">
      <path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5" />
    </symbol>
  </svg>

  <div class="app">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <div class="scrim" id="scrim"></div>

    <main class="main">
      <div class="mobile-bar">
        <button class="icon-btn" id="navToggle" type="button" aria-label="Open navigation"><svg class="i">
            <use href="#i-menu" />
          </svg></button>
        <a class="brand" href="teacher_home.php"><img src="assets/img/assetly-logo.png" alt="" width="26" height="26"><span>Assetly</span></a>
      </div>
      <div class="content">