<?php

/**
 * teacher sidebar. the first four items follow the UI/UX design; "My assets"
 * and "Physical count" in-add for accountability and the semi-annual count
 * placeholders pa lang yung 'count' badges; feed real values from the backend laterr.
 */
$nav = [
  ['key' => 'home',    'href' => 'teacher_home.php',           'icon' => 'i-home',        'label' => 'Home'],
  ['key' => 'assets',  'href' => 'teacher_my_assets.php',      'icon' => 'i-package',     'label' => 'My assets'],
  ['key' => 'count',   'href' => 'teacher_physical_count.php', 'icon' => 'i-clipboard',   'label' => 'Physical count', 'count' => 1],
  ['key' => 'update',  'href' => 'teacher_report_update.php',  'icon' => 'i-plus-square', 'label' => 'Report update'],
  ['key' => 'defect',  'href' => 'teacher_report_defect.php',  'icon' => 'i-alert',       'label' => 'Report defect'],
  ['key' => 'reports', 'href' => 'teacher_my_reports.php',     'icon' => 'i-file',        'label' => 'My reports'],
];
?>
<aside class="sidebar" id="sidebar">
  <a class="brand" href="teacher_home.php" aria-label="Assetly home">
    <img src="assets/img/assetly-logo.png" alt="" width="30" height="30">
    <span>Assetly</span>
  </a>

  <nav class="nav" aria-label="Main">
    <?php foreach ($nav as $item): ?>
      <a class="<?= $active === $item['key'] ? 'is-active' : '' ?>" href="<?= $item['href'] ?>" <?= $active === $item['key'] ? ' aria-current="page"' : '' ?>>
        <svg class="i">
          <use href="#<?= $item['icon'] ?>" />
        </svg>
        <span><?= $item['label'] ?></span>
        <?php if (!empty($item['count'])): ?><span class="count" aria-label="<?= (int)$item['count'] ?> open"><?= (int)$item['count'] ?></span><?php endif; ?>
      </a>
    <?php endforeach; ?>
  </nav>

  <div class="side-foot">
    <div class="me">
      <span class="avatar"><?= htmlspecialchars($userInitials) ?></span>
      <span><strong><?= htmlspecialchars($userName) ?></strong><small><?= htmlspecialchars($userRole) ?></small></span>
    </div>
    <a class="logout" href="logout.php"><svg class="i">
        <use href="#i-logout" />
      </svg> Log out</a>
  </div>
</aside>