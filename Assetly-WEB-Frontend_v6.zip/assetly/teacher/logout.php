<?php
// placeholder - wire to session teardown, then redirect to the landing Login page.
// session_start(); session_destroy(); header('Location: ../landing/Login.php'); exit;
echo 'Logged out (placeholder).';
