<?php
$pageTitle   = 'My assets';
$active      = 'assets';
$pageScripts = ['my_assets.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <h1>My assets</h1>
  <p>Items in the rooms assigned to you. You are accountable for these during the physical count.</p>
</div>

<div class="stack">
  <div class="grid-4" id="kpis"></div>

  <!-- assigned rooms: the rooms you are accountable for, and your requests to the custodian -->
  <section class="card" id="roomsCard">
    <div class="card-h">
      <div>
        <h2>My assigned rooms</h2>
        <p class="hint" style="margin:2px 0 0">School year <span id="syText"></span>. You are accountable for the assets in these rooms. Only the Property Custodian can approve changes.</p>
      </div>
      <button class="btn btn-primary" type="button" id="requestRoom"><svg class="i"><use href="#i-plus"/></svg> Request a room</button>
    </div>
    <div class="card-b">
      <div class="room-grid" id="roomGrid"></div>
      <div id="reqWrap" style="margin-top:22px" hidden>
        <div class="label" style="margin-bottom:6px">My room requests</div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Request</th><th>Room</th><th>Role / reason</th><th>Date sent</th><th>Status</th></tr></thead>
            <tbody id="reqBody"></tbody>
          </table>
        </div>
      </div>
    </div>
  </section>

  <section class="card">
    <div class="card-b" style="padding-bottom:6px">
      <div class="toolbar">
        <div class="search grow">
          <svg class="i"><use href="#i-search"/></svg>
          <input class="input" id="q" type="search" placeholder="Search by asset name, ID or property number" aria-label="Search assets">
        </div>
        <select class="select select-sm" id="fRoom" aria-label="Filter by room"><option value="">All my rooms</option></select>
        <select class="select select-sm" id="fCond" aria-label="Filter by condition"><option value="">All conditions</option></select>
      </div>
    </div>
    <div class="card-b" style="padding-top:8px">
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Asset</th><th>Category</th><th class="text-right">Qty</th><th>Location</th><th>Condition</th><th>Open reports</th><th class="text-right">Actions</th></tr></thead>
          <tbody id="body"></tbody>
        </table>
      </div>
      <p class="hint" style="margin:14px 0 0">Something here is wrong or missing? Use <b>Report update</b>. Broken? Use <b>Report defect</b>. Your list changes only after the custodian approves a report.</p>
    </div>
  </section>
</div>

<!-- request a room / request release -->
<div class="modal-backdrop" id="roomModal" hidden>
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="roomModalTitle">
    <div class="modal-h">
      <span class="ic"><svg class="i"><use href="#i-map"/></svg></span>
      <div><h2 id="roomModalTitle">Request a room</h2><p id="roomModalSub"></p></div>
    </div>
    <form id="roomForm" novalidate>
      <div class="form-grid">
        <div class="field">
          <label class="req" for="rm-building">Building:</label>
          <select class="select" id="rm-building" data-required><option value="">Select building</option></select>
          <span class="error">Choose a building.</span>
        </div>
        <div class="field">
          <label class="req" for="rm-room">Room:</label>
          <input class="input" id="rm-room" placeholder="Enter room number" data-required>
          <span class="error">Enter the room.</span>
        </div>
        <!-- request: what is your role in this room -->
        <div class="field span-2" id="roleField">
          <label class="req" for="rm-role">Your role in this room:</label>
          <select class="select" id="rm-role" data-required><option value="">Select role</option></select>
          <span class="error">Choose your role.</span>
        </div>
        <!-- release: why are you giving it up -->
        <div class="field span-2" id="reasonField" hidden>
          <label class="req" for="rm-reason">Reason for release:</label>
          <select class="select" id="rm-reason" data-required><option value="">Select reason</option></select>
          <span class="error">Choose a reason.</span>
        </div>
        <div class="field span-2">
          <label for="rm-note">Note to the custodian:</label>
          <textarea class="textarea" id="rm-note" placeholder="Optional"></textarea>
        </div>
      </div>
      <p class="modal-note" id="roomHint"></p>
      <div class="modal-f">
        <button class="btn btn-ghost" type="button" data-close>Cancel</button>
        <button class="btn btn-primary btn-lg" type="submit">Send request</button>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
