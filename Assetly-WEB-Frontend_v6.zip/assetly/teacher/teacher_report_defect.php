<?php
$pageTitle   = 'Report defect';
$active      = 'defect';
$pageScripts = ['report_defect.js'];
include __DIR__ . '/includes/header.php';
?>

<div class="page-head">
  <h1>Report Defect</h1>
  <p>Report an asset defect to Property Custodian.</p>
</div>

<div class="form-layout">
  <form class="card card-b" id="defectForm" novalidate style="padding:28px 30px 24px">
    <div class="form-grid">
      <div class="field span-2">
        <label class="req" for="d-name">Asset name:</label>
        <input class="input" id="d-name" placeholder="Enter asset name" data-required autocomplete="off">
        <span class="error">Enter the asset name.</span>
      </div>
      <div class="field">
        <label class="req" for="d-category">Category:</label>
        <select class="select" id="d-category" data-required><option value="">Select category</option></select>
        <span class="error">Choose a category.</span>
      </div>
      <div class="field">
        <label class="req" for="d-qty">Quantity:</label>
        <input class="input" id="d-qty" type="number" min="1" step="1" placeholder="Enter quantity" data-required>
        <span class="error">Enter how many are affected.</span>
      </div>
      <div class="field">
        <label class="req" for="d-building">Building:</label>
        <select class="select" id="d-building" data-required><option value="">Select building</option></select>
        <span class="error">Choose a building.</span>
      </div>
      <div class="field">
        <label for="d-room">Room:</label>
        <input class="input" id="d-room" placeholder="Enter room number">
      </div>
      <div class="field span-2">
        <label class="req" for="d-type">Defect type:</label>
        <input class="input" id="d-type" list="defectTypeList" placeholder="Enter the defect of the asset" data-required autocomplete="off">
        <datalist id="defectTypeList"></datalist>
        <span class="error">Enter the defect.</span>
      </div>
      <div class="field">
        <label for="d-person">Person responsible for the damage:</label>
        <input class="input" id="d-person" placeholder="Enter the full name">
        <span class="hint">Leave blank if unknown.</span>
      </div>
      <div class="field">
        <label class="req" for="d-role">Role of the person responsible:</label>
        <select class="select" id="d-role" data-required><option value="">Select role</option></select>
        <span class="error">Choose a role, or "Unknown".</span>
      </div>
      <div class="field span-2">
        <label class="req" for="d-desc">Description:</label>
        <textarea class="textarea" id="d-desc" placeholder="Describe the defect of the asset..." data-required></textarea>
        <span class="error">Describe the defect.</span>
      </div>
    </div>
    <div class="form-actions">
      <a class="btn btn-outline" href="teacher_home.php">Cancel</a>
      <button class="btn btn-primary btn-lg" type="submit">Submit report defect</button>
    </div>
  </form>

  <aside>
    <div class="card photo-card">
      <!-- both photos required for a defect report -->
      <div class="field upload" id="idBox">
        <span class="label req">School ID photo:</span>
        <label class="dropzone" id="dzId">
          <input type="file" accept="image/*" aria-label="Upload a photo of your school ID">
          <span class="dz-inner"><svg class="i i-lg" style="color:var(--navy)"><use href="#i-camera"/></svg><span>Drop your school ID photo here or <b>browse</b></span></span>
        </label>
        <button class="btn btn-ghost btn-sm remove" type="button" hidden><svg class="i"><use href="#i-x"/></svg> Remove photo</button>
        <span class="error">Upload a photo of your school ID.</span>
      </div>
      <div class="field upload" id="defectBox">
        <span class="label req">Photo of the defect:</span>
        <label class="dropzone" id="dzDefect">
          <input type="file" accept="image/*" aria-label="Upload a photo of the defective asset">
          <span class="dz-inner"><svg class="i i-lg" style="color:var(--navy)"><use href="#i-camera"/></svg><span>Drop the photo of the defect here or <b>browse</b></span></span>
        </label>
        <button class="btn btn-ghost btn-sm remove" type="button" hidden><svg class="i"><use href="#i-x"/></svg> Remove photo</button>
        <span class="error">Upload a photo showing the defect.</span>
      </div>
    </div>
    <div class="card next">
      <h3>What happens next</h3>
      <ol>
        <li><strong>Saved as pending</strong><small>Your report is recorded</small></li>
        <li><strong>Custodian notified</strong><small>They review your report</small></li>
        <li><strong>Track report defect</strong><small>After acknowledgement of Custodian, you can track the progress of your report</small></li>
      </ol>
    </div>
  </aside>
</div>

<div class="modal-backdrop" id="reviewModal" hidden>
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="reviewTitle">
    <div class="modal-h">
      <span class="ic"><svg class="i"><use href="#i-check"/></svg></span>
      <div><h2 id="reviewTitle">Review your defect report</h2><p>Please check your answers before submitting.</p></div>
    </div>
    <dl class="review" id="reviewBody"></dl>
    <p class="modal-note">The custodian will be notified.</p>
    <div class="modal-f">
      <button class="btn btn-ghost" type="button" id="reviewCancel">Cancel</button>
      <button class="btn btn-outline-brand" type="button" data-close>Edit answers</button>
      <button class="btn btn-primary btn-lg" type="button" id="reviewConfirm">Confirm and submit</button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
