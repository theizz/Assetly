<?php

/**
 * closes the layout, mounts the toast stack and loads shared + page scripts.
 */
?>
</div><!-- /.content -->
</main>
</div><!-- /.app -->

<div class="toast-stack" id="toastStack" aria-live="polite"></div>

<script src="assets/js/data.js"></script>
<script src="assets/js/app.js"></script>
<?php foreach ($pageScripts as $script): ?>
  <script src="assets/js/<?= htmlspecialchars($script) ?>"></script>
<?php endforeach; ?>
</body>

</html>