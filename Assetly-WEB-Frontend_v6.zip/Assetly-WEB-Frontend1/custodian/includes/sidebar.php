<?php
/**
 * Sidebar navigation. Expects $active to be set by the including page.
 * Badge counts are placeholders; replace them with counts from the backend.
 *
 * An item with 'children' renders as a collapsible dropdown group. The group
 * starts open when the active page is the parent or one of its children.
 */
$nav = [
  ['key' => 'dashboard',  'href' => 'custodian_dashboard.php',      'icon' => 'i-dashboard', 'label' => 'Dashboard'],
  ['key' => 'assets',     'href' => 'custodian_assets.php',         'icon' => 'i-package',   'label' => 'Assets', 'badge' => 5,
    'children' => [
      ['key' => 'assets',     'href' => 'custodian_assets.php',     'icon' => 'i-layers', 'label' => 'All assets'],
      ['key' => 'deliveries', 'href' => 'custodian_deliveries.php', 'icon' => 'i-truck',  'label' => 'Deliveries', 'badge' => 2],
      ['key' => 'count',      'href' => 'custodian_physical_count.php', 'icon' => 'i-clipboard', 'label' => 'Physical count', 'badge' => 3],
    ]],
  ['key' => 'reports',    'href' => 'custodian_update_reports.php', 'icon' => 'i-file',      'label' => 'Update reports', 'badge' => 3],
  ['key' => 'rooms',      'href' => 'custodian_room_requests.php',  'icon' => 'i-map-pin',    'label' => 'Room requests', 'badge' => 4],
  ['key' => 'tickets',    'href' => 'custodian_defect_tickets.php', 'icon' => 'i-wrench',    'label' => 'Defect tickets', 'badge' => 2],
  ['key' => 'trash',      'href' => 'custodian_trash.php',          'icon' => 'i-trash',     'label' => 'Trash'],
];
?>
<aside class="sidebar" id="sidebar">
  <a class="brand" href="custodian_dashboard.php" aria-label="Assetly home">
    <img class="brand-mark" src="assets/img/assetly-logo.png" alt="" width="30" height="30">
    <span class="brand-name">Assetly</span>
  </a>

  <nav class="nav" aria-label="Main">
    <?php foreach ($nav as $item): ?>
      <?php if (!empty($item['children'])):
        $childKeys = array_column($item['children'], 'key');
        $groupActive = in_array($active, $childKeys, true);
        $groupId = 'nav-group-' . $item['key']; ?>
        <div class="nav-group<?= $groupActive ? ' is-open' : '' ?>">
          <button class="nav-item nav-toggle<?= $groupActive ? ' is-current' : '' ?>" type="button"
                  aria-expanded="<?= $groupActive ? 'true' : 'false' ?>" aria-controls="<?= $groupId ?>">
            <svg class="i"><use href="#<?= $item['icon'] ?>"/></svg>
            <span><?= $item['label'] ?></span>
            <?php if (!empty($item['badge'])): ?><span class="nav-badge"><?= (int)$item['badge'] ?></span><?php endif; ?>
            <svg class="i i-sm nav-caret"><use href="#i-chevron"/></svg>
          </button>
          <div class="nav-sub" id="<?= $groupId ?>">
            <?php foreach ($item['children'] as $child): ?>
              <a class="nav-item<?= $active === $child['key'] ? ' is-active' : '' ?>"
                 href="<?= $child['href'] ?>"
                 <?= $active === $child['key'] ? 'aria-current="page"' : '' ?>>
                <svg class="i"><use href="#<?= $child['icon'] ?>"/></svg>
                <span><?= $child['label'] ?></span>
                <?php if (!empty($child['badge'])): ?><span class="nav-badge"><?= (int)$child['badge'] ?></span><?php endif; ?>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
      <?php else: ?>
        <a class="nav-item<?= $active === $item['key'] ? ' is-active' : '' ?>"
           href="<?= $item['href'] ?>"
           <?= $active === $item['key'] ? 'aria-current="page"' : '' ?>>
          <svg class="i"><use href="#<?= $item['icon'] ?>"/></svg>
          <span><?= $item['label'] ?></span>
          <?php if (!empty($item['badge'])): ?><span class="nav-badge"><?= (int)$item['badge'] ?></span><?php endif; ?>
        </a>
      <?php endif; ?>
    <?php endforeach; ?>
  </nav>

  <!-- Same footer as the Teacher interface: who is signed in + log out -->
  <div class="sidebar-foot">
    <div class="me" title="<?= htmlspecialchars($schoolName ?? 'Lagro High School') ?>">
      <span class="avatar"><?= htmlspecialchars($userInitials ?? 'PC') ?></span>
      <span><strong><?= htmlspecialchars($userName ?? 'Property Custodian') ?></strong><small><?= htmlspecialchars($userRole ?? 'Property Custodian') ?></small></span>
    </div>
    <a class="logout" href="logout.php"><svg class="i"><use href="#i-logout"/></svg> Log out</a>
  </div>
</aside>
<div class="sidebar-scrim" id="sidebarScrim"></div>
